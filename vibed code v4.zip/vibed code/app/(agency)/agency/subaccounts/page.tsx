import Link from 'next/link';
import { revalidatePath } from 'next/navigation';
import { requireAgencyRole } from '@/lib/auth/rbac';
import { createSubaccount } from '@/server/actions/subaccounts';
import { createServerClient } from '@/lib/supabase/server';
import { SubaccountMode, SupportedLocale } from '@/types/subaccount';

export async function generateMetadata() {
  return {
    title: 'Sub-Account Management Directory',
  };
}

export default async function AgencySubaccountsPage() {
  // 1. Verify Agency Level Role and get session
  const session = await requireAgencyRole();
  const agencyId = session.agencyId || 'default-agency';

  const supabase = await createServerClient();

  // 2. Fetch Subaccounts and Assigned Members Count
  const { data: subaccountsData, error } = await supabase
    .from('subaccounts')
    .select(`
      *,
      subaccount_members (
        id
      )
    `)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Failed to query subaccounts:', error.message);
  }

  const subaccounts = subaccountsData || [];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight">
          Sub-Account Tenant Directory
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Deploy, configure, and manage isolated client or brand subaccounts across your agency network.
        </p>
      </div>

      {/* Provision New Sub-Account Form */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
        <div>
          <h2 className="text-sm font-bold text-foreground">Provision New Sub-Account</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Initializes an isolated database container with default sales pipelines, theme tokens, and routing.
          </p>
        </div>

        <form
          action={async (formData: FormData) => {
            'use server';
            const name = (formData.get('name') as string)?.trim();
            const slug = (formData.get('slug') as string)?.trim();
            const mode = (formData.get('mode') as SubaccountMode) || 'COD';
            const currency = (formData.get('currency') as string) || 'USD';
            const defaultLocale = (formData.get('defaultLocale') as SupportedLocale) || 'en';
            const primaryColor = (formData.get('primaryColor') as string) || '#2563eb';

            if (name && slug) {
              await createSubaccount({
                agencyId,
                name,
                slug,
                mode,
                currency,
                defaultLocale,
                supportedLocales: ['en', 'ar', 'fr'],
                theme: {
                  primaryColor,
                  borderRadius: 'md',
                  fontFamily: 'sans',
                },
              });

              revalidatePath('/agency/subaccounts', 'page');
            }
          }}
          className="space-y-4 text-xs"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Sub-Account Name *
              </label>
              <input
                type="text"
                name="name"
                required
                placeholder="e.g. Atlas Cosmetics"
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Slug (URL Identifier) *
              </label>
              <input
                type="text"
                name="slug"
                required
                placeholder="atlas-cosmetics"
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Operational Mode *
              </label>
              <select
                name="mode"
                className="w-full px-3 py-2 bg-background border border-input rounded-md font-medium focus:outline-none text-xs"
              >
                <option value="COD">COD (Cash on Delivery)</option>
                <option value="ONLINE">ONLINE (Prepaid Cart)</option>
                <option value="HYBRID">HYBRID (Both)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Storefront Currency
              </label>
              <select
                name="currency"
                className="w-full px-3 py-2 bg-background border border-input rounded-md font-mono focus:outline-none text-xs"
              >
                <option value="USD">USD ($)</option>
                <option value="MAD">MAD (DH)</option>
                <option value="EUR">EUR (€)</option>
                <option value="SAR">SAR (ر.س)</option>
                <option value="AED">AED (د.إ)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Default Language
              </label>
              <select
                name="defaultLocale"
                className="w-full px-3 py-2 bg-background border border-input rounded-md font-medium focus:outline-none text-xs"
              >
                <option value="en">English (en)</option>
                <option value="ar">Arabic (العربية)</option>
                <option value="fr">French (fr)</option>
                <option value="es">Spanish (es)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Brand Accent Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  name="primaryColor"
                  defaultValue="#2563eb"
                  className="w-8 h-8 rounded border border-input cursor-pointer"
                />
                <span className="font-mono text-muted-foreground text-[11px]">Primary theme token</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-5 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-all shadow-sm"
            >
              + Deploy Sub-Account
            </button>
          </div>
        </form>
      </div>

      {/* Directory Table */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-border bg-muted/30 uppercase font-semibold text-muted-foreground tracking-wider">
              <th className="py-3 px-4">Sub-Account</th>
              <th className="py-3 px-4">Slug Identifier</th>
              <th className="py-3 px-4">Mode</th>
              <th className="py-3 px-4">Default Locale</th>
              <th className="py-3 px-4">Currency</th>
              <th className="py-3 px-4">Operators</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {subaccounts.length > 0 ? (
              subaccounts.map((tenant) => {
                const membersCount = tenant.subaccount_members?.length || 0;
                const defaultLocale = tenant.default_locale || 'en';

                return (
                  <tr key={tenant.id} className="hover:bg-muted/30 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-md bg-primary/10 text-primary font-bold flex items-center justify-center text-xs">
                          {tenant.name.charAt(0)}
                        </div>
                        <span className="font-semibold text-foreground">{tenant.name}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono text-muted-foreground">
                      /{tenant.slug}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          tenant.mode === 'COD'
                            ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                            : tenant.mode === 'ONLINE'
                            ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20'
                            : 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                        }`}
                      >
                        {tenant.mode}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 uppercase font-mono text-muted-foreground">
                      {tenant.default_locale}
                    </td>

                    <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                      {tenant.currency}
                    </td>

                    <td className="py-3.5 px-4 font-mono text-muted-foreground">
                      {membersCount} team member{membersCount !== 1 ? 's' : ''}
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <Link
                        href={`/${tenant.slug}/${defaultLocale}/admin`}
                        className="px-2.5 py-1 bg-primary text-primary-foreground font-semibold rounded text-[11px] hover:bg-primary/90 transition-colors shadow-sm inline-block"
                      >
                        Launch Console ↗
                      </Link>

                      <Link
                        href={`/${tenant.slug}/${defaultLocale}`}
                        target="_blank"
                        className="text-[11px] text-muted-foreground hover:text-foreground hover:underline font-medium inline-block"
                      >
                        Store
                      </Link>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={7} className="py-12 text-center text-muted-foreground text-xs italic">
                  No subaccounts found in agency network.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
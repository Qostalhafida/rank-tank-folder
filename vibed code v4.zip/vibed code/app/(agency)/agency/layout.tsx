import React from 'react';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { requireAgencyRole } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';

interface AgencyLayoutProps {
  children: React.ReactNode;
}

const AGENCY_NAV_ITEMS = [
  { label: 'Agency Overview', href: '/agency', icon: '📈' },
  { label: 'Sub-Accounts', href: '/agency/subaccounts', icon: '🏢' },
  { label: 'Global Team & RBAC', href: '/agency/team', icon: '🛡️' },
];

export default async function AgencyLayout({ children }: AgencyLayoutProps) {
  // 1. Enforce Agency-Level Access Guard
  let session;
  try {
    session = await requireAgencyRole(['AGENCY_SUPER_ADMIN', 'AGENCY_ADMIN', 'AGENCY_ACCOUNT_MANAGER']);
  } catch {
    redirect('/login');
  }

  const isSuperAdmin = session.role === 'AGENCY_SUPER_ADMIN';

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col md:flex-row font-sans text-foreground">
      {/* Agency Navigation Sidebar */}
      <aside className="w-full md:w-64 bg-card border-r border-border shrink-0 flex flex-col justify-between">
        <div>
          {/* Agency Brand Header */}
          <div className="p-5 border-b border-border space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground font-black flex items-center justify-center text-sm shadow-sm">
                A
              </div>
              <div>
                <h1 className="text-sm font-bold text-foreground tracking-tight">
                  Master Agency
                </h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-primary/10 text-primary font-bold uppercase tracking-wider">
                  Super-Admin
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="p-3 space-y-1">
            {AGENCY_NAV_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              >
                <span className="text-base">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>
        </div>

        {/* Agency Operator Profile & Sign Out */}
        <div className="p-4 border-t border-border bg-muted/30 flex items-center justify-between">
          <div className="min-w-0 pr-2">
            <p className="text-xs font-semibold text-foreground truncate">
              {session.email}
            </p>
            <p className="text-[10px] font-mono text-muted-foreground uppercase">
              {isSuperAdmin ? 'Super Admin' : 'Agency Manager'}
            </p>
          </div>

          <form
            action={async () => {
              'use server';
              const supabase = await createServerClient();
              await supabase.auth.signOut();
              redirect('/login');
            }}
          >
            <button
              type="submit"
              title="Sign Out"
              className="text-xs text-muted-foreground hover:text-destructive p-1.5 rounded hover:bg-muted transition-colors"
            >
              ⏻
            </button>
          </form>
        </div>
      </aside>

      {/* Main Agency Workspace Container */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <div className="flex-1 p-6 md:p-8 max-w-7xl w-full mx-auto">{children}</div>
      </main>
    </div>
  );
}
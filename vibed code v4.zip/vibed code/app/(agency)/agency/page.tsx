import Link from 'next/link';
import { requireAgencyRole } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';

export async function generateMetadata() {
  return {
    title: 'Cross-Tenant Analytics & Global Agency Metrics',
  };
}

export default async function AgencyOverviewPage() {
  // 1. Verify Agency Level Role
  await requireAgencyRole();
  const supabase = await createServerClient();

  // 2. Fetch Cross-Tenant Metrics Concurrently
  const [subaccountsRes, ordersRes, contactsRes] = await Promise.all([
    // All subaccounts under platform
    supabase
      .from('subaccounts')
      .select('id, name, slug, mode, currency, default_locale, created_at')
      .order('created_at', { ascending: false }),

    // All global platform orders
    supabase
      .from('orders')
      .select('id, subaccount_id, order_number, total_amount, status, payment_method, created_at')
      .neq('status', 'CANCELLED'),

    // Total contact volume
    supabase
      .from('contacts')
      .select('id', { count: 'exact', head: true }),
  ]);

  const subaccounts = subaccountsRes.data || [];
  const orders = ordersRes.data || [];
  const totalContacts = contactsRes.count || 0;

  // 3. Compute Aggregates
  const totalPlatformRevenue = orders.reduce(
    (sum, o) => sum + (o.total_amount || 0),
    0
  );

  const totalOrdersCount = orders.length;

  // Group performance by subaccount
  const tenantPerformanceMap: Record<
    string,
    { ordersCount: number; revenue: number }
  > = {};

  orders.forEach((o) => {
    if (!tenantPerformanceMap[o.subaccount_id]) {
      tenantPerformanceMap[o.subaccount_id] = { ordersCount: 0, revenue: 0 };
    }
    tenantPerformanceMap[o.subaccount_id].ordersCount += 1;
    tenantPerformanceMap[o.subaccount_id].revenue += o.total_amount || 0;
  });

  const formatPrice = (amount: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amount);

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight">
            Cross-Subaccount Overview
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Aggregated gross merchandise value (GMV), customer acquisition, and tenant rankings.
          </p>
        </div>

        <Link
          href="/agency/subaccounts"
          className="px-4 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-sm self-start sm:self-auto"
        >
          + Provision New Sub-Account
        </Link>
      </div>

      {/* Primary Global KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Platform GMV */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Platform Gross Revenue
            </span>
            <span className="text-emerald-500 font-bold">● Network</span>
          </div>
          <div className="text-2xl font-black font-mono text-foreground">
            {formatPrice(totalPlatformRevenue)}
          </div>
          <p className="text-[11px] text-muted-foreground">Across all registered tenants</p>
        </div>

        {/* Total Managed Subaccounts */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Active Sub-Accounts
            </span>
            <span className="text-blue-500 font-bold">🏢 Tenants</span>
          </div>
          <div className="text-2xl font-black font-mono text-foreground">
            {subaccounts.length}
          </div>
          <p className="text-[11px] text-muted-foreground">Multi-tenant e-commerce stores</p>
        </div>

        {/* Total Platform Orders */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Global Orders Processed
            </span>
            <span className="text-amber-500 font-bold">📦 Fulfillment</span>
          </div>
          <div className="text-2xl font-black font-mono text-foreground">
            {totalOrdersCount}
          </div>
          <p className="text-[11px] text-muted-foreground">COD and Prepaid transactions</p>
        </div>

        {/* Global CRM Contacts */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Total Customer Audience
            </span>
            <span className="text-purple-500 font-bold">👥 Profiles</span>
          </div>
          <div className="text-2xl font-black font-mono text-foreground">
            {totalContacts}
          </div>
          <p className="text-[11px] text-muted-foreground">Unified customer records in CRM</p>
        </div>
      </div>

      {/* Subaccounts Performance Directory */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
        <div className="p-5 border-b border-border flex justify-between items-center">
          <div>
            <h2 className="text-sm font-bold text-foreground">Sub-Account Performance Rankings</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Comparative volume, operational mode, and direct administrative jumps.
            </p>
          </div>
          <Link
            href="/agency/subaccounts"
            className="text-xs text-primary font-medium hover:underline"
          >
            Manage Directory →
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-border bg-muted/30 uppercase font-semibold text-muted-foreground tracking-wider">
                <th className="py-3 px-4">Sub-Account</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4">Default Currency</th>
                <th className="py-3 px-4 text-center">Orders</th>
                <th className="py-3 px-4 text-right">Revenue</th>
                <th className="py-3 px-4 text-right">Quick Access</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {subaccounts.length > 0 ? (
                subaccounts.map((tenant) => {
                  const stats = tenantPerformanceMap[tenant.id] || {
                    ordersCount: 0,
                    revenue: 0,
                  };
                  const defaultLocale = tenant.default_locale || 'en';

                  return (
                    <tr key={tenant.id} className="hover:bg-muted/30 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-md bg-primary/10 text-primary font-bold flex items-center justify-center text-xs">
                            {tenant.name.charAt(0)}
                          </div>
                          <div>
                            <span className="font-semibold text-foreground block">
                              {tenant.name}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono">
                              /{tenant.slug}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            tenant.mode === 'COD'
                              ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                              : tenant.mode === 'ONLINE'
                              ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20'
                              : 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                          }`}
                        >
                          {tenant.mode}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                        {tenant.currency}
                      </td>

                      <td className="py-3.5 px-4 text-center font-mono font-medium text-foreground">
                        {stats.ordersCount}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-bold text-foreground">
                        {formatPrice(stats.revenue)}
                      </td>

                      <td className="py-3.5 px-4 text-right space-x-2">
                        <Link
                          href={`/${tenant.slug}/${defaultLocale}/admin`}
                          className="px-2.5 py-1 bg-muted border border-border text-foreground hover:bg-muted/80 rounded font-medium text-[11px] transition-colors"
                        >
                          Admin Console ↗
                        </Link>
                        <Link
                          href={`/${tenant.slug}/${defaultLocale}`}
                          target="_blank"
                          className="text-[11px] text-primary hover:underline font-medium"
                        >
                          Storefront
                        </Link>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-muted-foreground text-xs italic">
                    No subaccounts deployed yet. Click Provision New Sub-Account to create your first tenant.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
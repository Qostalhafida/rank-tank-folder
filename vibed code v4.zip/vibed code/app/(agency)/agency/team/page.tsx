import { revalidatePath } from 'next/navigation';
import { requireAgencyRole } from '@/lib/auth/rbac';
import { createAdminClient } from '@/lib/supabase/admin';
import { AgencyRole } from '@/types/rbac';

export async function generateMetadata() {
  return {
    title: 'Global Agency Team & Permissions',
  };
}

const AGENCY_ROLES: { role: AgencyRole; label: string; desc: string }[] = [
  {
    role: 'AGENCY_SUPER_ADMIN',
    label: 'Agency Super-Admin',
    desc: 'Unrestricted master access across all sub-accounts, billing, and infrastructure configurations.',
  },
  {
    role: 'AGENCY_ADMIN',
    label: 'Agency Administrator',
    desc: 'Can provision and configure all sub-accounts, workflows, products, and pipelines.',
  },
  {
    role: 'AGENCY_ACCOUNT_MANAGER',
    label: 'Account Manager',
    desc: 'Access to cross-tenant CRM contacts, order fulfillments, and scheduling analytics.',
  },
];

export default async function AgencyTeamPage() {
  // 1. Verify Agency Level Role (Super Admin access required to manage global team)
  const session = await requireAgencyRole(['AGENCY_SUPER_ADMIN', 'AGENCY_ADMIN']);
  const agencyId = session.agencyId || 'default-agency';
  const isSuperAdmin = session.role === 'AGENCY_SUPER_ADMIN';

  const supabase = createAdminClient();

  // 2. Fetch Global Agency Members
  const { data: agencyMembersData } = await supabase
    .from('agency_members')
    .select('id, agency_id, user_id, role, created_at')
    .eq('agency_id', agencyId)
    .order('created_at', { ascending: true });

  const { data: usersData } = await supabase.auth.admin.listUsers();
  const allUsers = usersData?.users || [];

  const members = (agencyMembersData || []).map((m) => {
    const user = allUsers.find((u) => u.id === m.user_id);
    return {
      id: m.id,
      userId: m.user_id,
      role: m.role as AgencyRole,
      createdAt: m.created_at,
      email: user?.email || 'Unknown User',
    };
  });

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight">
          Global Agency Team & Permissions
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Manage master operators with multi-tenant oversight across all client subaccounts.
        </p>
      </div>

      {/* Assign Agency Operator Form (Super-Admin Only) */}
      {isSuperAdmin && (
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
          <div>
            <h2 className="text-sm font-bold text-foreground">Add Global Agency Operator</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Assign high-level administrative credentials across all platform sub-accounts.
            </p>
          </div>

          <form
            action={async (formData: FormData) => {
              'use server';
              const email = (formData.get('email') as string)?.trim();
              const role = formData.get('role') as AgencyRole;

              if (email && role) {
                const adminClient = createAdminClient();
                const { data: userLookup } = await adminClient.auth.admin.listUsers();
                const target = userLookup?.users.find(
                  (u) => u.email?.toLowerCase() === email.toLowerCase()
                );

                if (target) {
                  await adminClient.from('agency_members').upsert(
                    {
                      agency_id: agencyId,
                      user_id: target.id,
                      role,
                    },
                    { onConflict: 'agency_id,user_id' }
                  );

                  revalidatePath('/agency/team', 'page');
                }
              }
            }}
            className="flex flex-col sm:flex-row gap-3 text-xs"
          >
            <input
              type="email"
              name="email"
              required
              placeholder="operator@masteragency.com"
              className="flex-1 px-3.5 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs"
            />

            <select
              name="role"
              required
              className="px-3 py-2 bg-background border border-input rounded-md font-medium focus:outline-none text-xs"
            >
              <option value="AGENCY_ADMIN">Agency Administrator</option>
              <option value="AGENCY_ACCOUNT_MANAGER">Account Manager</option>
              <option value="AGENCY_SUPER_ADMIN">Agency Super-Admin</option>
            </select>

            <button
              type="submit"
              className="px-5 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-all shadow-sm shrink-0"
            >
              + Grant Agency Access
            </button>
          </form>
        </div>
      )}

      {/* Agency Members Directory Table */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden overflow-x-auto">
        <div className="p-4 border-b border-border">
          <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
            Active Agency Members ({members.length})
          </h2>
        </div>

        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-border bg-muted/30 uppercase font-semibold text-muted-foreground tracking-wider">
              <th className="py-3 px-4">Operator</th>
              <th className="py-3 px-4">Global Role</th>
              <th className="py-3 px-4">Date Added</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {members.map((member) => {
              const isSuper = member.role === 'AGENCY_SUPER_ADMIN';

              return (
                <tr key={member.id} className="hover:bg-muted/30 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center text-xs">
                        {member.email.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <span className="font-semibold text-foreground block">
                          {member.email}
                        </span>
                        <span className="text-[10px] text-muted-foreground font-mono">
                          ID: {member.userId.slice(0, 8)}...
                        </span>
                      </div>
                    </div>
                  </td>

                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isSuper
                          ? 'bg-purple-500/10 text-purple-600 border border-purple-500/20'
                          : member.role === 'AGENCY_ADMIN'
                          ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {member.role.replace('AGENCY_', '')}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 font-mono text-muted-foreground">
                    {new Date(member.createdAt).toLocaleDateString()}
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    {isSuperAdmin && !isSuper ? (
                      <form
                        action={async () => {
                          'use server';
                          const adminClient = createAdminClient();
                          await adminClient
                            .from('agency_members')
                            .delete()
                            .eq('id', member.id);
                          revalidatePath('/agency/team', 'page');
                        }}
                      >
                        <button
                          type="submit"
                          className="text-xs text-destructive hover:underline font-medium"
                        >
                          Revoke Access
                        </button>
                      </form>
                    ) : (
                      <span className="text-[10px] text-muted-foreground italic">Protected</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Role Definitions Breakdown Cards */}
      <div className="p-6 bg-card border border-border rounded-xl space-y-4 text-xs text-muted-foreground">
        <h3 className="font-bold text-foreground uppercase tracking-wider text-xs">
          Agency Permission Hierarchies
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {AGENCY_ROLES.map((r) => (
            <div
              key={r.role}
              className="p-4 bg-muted/20 border border-border rounded-lg space-y-1.5"
            >
              <h4 className="font-bold text-foreground text-xs">{r.label}</h4>
              <p className="text-[11px] leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
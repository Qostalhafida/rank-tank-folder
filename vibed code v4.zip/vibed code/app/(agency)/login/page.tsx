'use client';

import React, { useState, useTransition } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function AgencyLoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const returnUrl = searchParams.get('returnUrl') || '/agency';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim() || !password) {
      setErrorMessage('Please enter both email and password.');
      return;
    }

    startTransition(async () => {
      const supabase = createClient();

      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (error || !data.user) {
        setErrorMessage(error?.message || 'Authentication failed. Please verify credentials.');
        return;
      }

      // Check if user is linked to an agency
      const { data: memberRecord } = await supabase
        .from('agency_members')
        .select('role')
        .eq('user_id', data.user.id)
        .maybeSingle();

      if (!memberRecord) {
        // Not an agency user; sign out and report error
        await supabase.auth.signOut();
        setErrorMessage('Access restricted: Account does not possess master agency administrative rights.');
        return;
      }

      router.push(returnUrl);
      router.refresh();
    });
  };

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col justify-center items-center p-4 sm:p-6 font-sans">
      <div className="w-full max-w-md bg-card border border-border rounded-2xl shadow-xl p-8 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground font-black text-xl flex items-center justify-center mx-auto shadow-md">
            A
          </div>
          <h1 className="text-xl font-bold text-foreground tracking-tight">
            Master Agency Portal
          </h1>
          <p className="text-xs text-muted-foreground">
            Sign in with administrative credentials to manage tenants and infrastructure.
          </p>
        </div>

        {errorMessage && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 text-destructive text-xs rounded-lg">
            {errorMessage}
          </div>
        )}

        {/* Authentication Form */}
        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">
              Agency Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@platform.com"
              className="w-full px-3.5 py-2.5 bg-background border border-input rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-primary/40 text-foreground"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3.5 py-2.5 bg-background border border-input rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-primary/40 text-foreground"
            />
          </div>

          <button
            type="submit"
            disabled={isPending}
            className="w-full py-3 px-4 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isPending ? (
              <span className="animate-spin">⟳ Authenticating...</span>
            ) : (
              <span>Sign In to Agency Console →</span>
            )}
          </button>
        </form>

        <div className="pt-2 border-t border-border text-center">
          <p className="text-[11px] text-muted-foreground">
            Protected by multi-tenant cryptographic session tokens.
          </p>
        </div>
      </div>
    </div>
  );
}
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createServerClient } from '@/lib/supabase/server';

interface AdminDashboardPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'KPI Analytics & Dashboard',
  };
}

export default async function AdminDashboardPage({ params }: AdminDashboardPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const supabase = await createServerClient();

  // 2. Fetch KPI Rollups concurrently
  const [ordersRes, contactsRes, opportunitiesRes, recentOrdersRes, recentLeadsRes] =
    await Promise.all([
      supabase
        .from('orders')
        .select('total_amount, status, payment_status, payment_method')
        .eq('subaccount_id', tenant.id),

      supabase
        .from('contacts')
        .select('id, lifetime_value', { count: 'exact' })
        .eq('subaccount_id', tenant.id),

      supabase
        .from('opportunities')
        .select('value, status')
        .eq('subaccount_id', tenant.id)
        .eq('status', 'OPEN'),

      supabase
        .from('orders')
        .select('id, order_number, total_amount, status, payment_method, created_at, shipping_address')
        .eq('subaccount_id', tenant.id)
        .order('created_at', { ascending: false })
        .limit(5),

      supabase
        .from('contacts')
        .select('id, first_name, last_name, phone, created_at')
        .eq('subaccount_id', tenant.id)
        .eq('orders_count', 0)
        .order('created_at', { ascending: false })
        .limit(5),
    ]);

  const orders = ordersRes.data || [];
  const contactsCount = contactsRes.count || 0;
  const openOpportunities = opportunitiesRes.data || [];
  const recentOrders = recentOrdersRes.data || [];
  const recentLeads = recentLeadsRes.data || [];

  // 3. Compute High-Performance Rollups
  const totalRevenue = orders
    .filter((o) => o.status !== 'CANCELLED' && o.status !== 'RETURNED')
    .reduce((sum, o) => sum + (o.total_amount || 0), 0);

  const pendingCodOrders = orders.filter(
    (o) => o.payment_method === 'COD' && o.status === 'PENDING'
  );

  const pendingCodRevenue = pendingCodOrders.reduce(
    (sum, o) => sum + (o.total_amount || 0),
    0
  );

  const pipelineValue = openOpportunities.reduce(
    (sum, deal) => sum + (deal.value || 0),
    0
  );

  const formatPrice = (amount: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(amount);

  return (
    <div className="space-y-8">
      {/* Dashboard Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight">
            Dashboard Overview
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Realtime performance metrics and fulfillment rollups for {tenant.name}.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href={`/${subaccountSlug}/${locale}/admin/orders`}
            className="px-3.5 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-md hover:bg-primary/90 transition-colors shadow-sm"
          >
            + Process Orders
          </Link>
        </div>
      </div>

      {/* Primary KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Net Revenue */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Total Revenue
            </span>
            <span className="text-emerald-500 font-bold">● Live</span>
          </div>
          <div className="text-2xl font-black font-mono text-foreground">
            {formatPrice(totalRevenue)}
          </div>
          <p className="text-[11px] text-muted-foreground">
            From {orders.length} total registered orders
          </p>
        </div>

        {/* Pending COD Collection */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Pending COD Cash
            </span>
            <span className="text-amber-500 font-bold">⚡ Unconfirmed</span>
          </div>
          <div className="text-2xl font-black font-mono text-amber-600">
            {formatPrice(pendingCodRevenue)}
          </div>
          <p className="text-[11px] text-muted-foreground">
            {pendingCodOrders.length} orders awaiting courier dispatch
          </p>
        </div>

        {/* Pipeline Value */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Open Pipeline Value
            </span>
            <span className="text-blue-500 font-bold">📋 Deals</span>
          </div>
          <div className="text-2xl font-black font-mono text-primary">
            {formatPrice(pipelineValue)}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Across {openOpportunities.length} active opportunities
          </p>
        </div>

        {/* Total CRM Contacts */}
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-semibold uppercase tracking-wider text-[10px]">
              Total CRM Contacts
            </span>
            <span className="text-purple-500 font-bold">👥 Audience</span>
          </div>
          <div className="text-2xl font-black font-mono text-foreground">
            {contactsCount}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Active customer profiles and leads
          </p>
        </div>
      </div>

      {/* Grid: Recent Orders & High-Intent Abandoned Leads */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Recent Orders List */}
        <div className="lg:col-span-7 bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-border">
            <h2 className="text-sm font-bold text-foreground">Recent Orders</h2>
            <Link
              href={`/${subaccountSlug}/${locale}/admin/orders`}
              className="text-xs text-primary font-medium hover:underline"
            >
              View All Orders →
            </Link>
          </div>

          <div className="divide-y divide-border/60">
            {recentOrders.length > 0 ? (
              recentOrders.map((order) => {
                const customer = order.shipping_address as Record<string, any> | null;
                const customerName = customer
                  ? `${customer.firstName ?? ''} ${customer.lastName ?? ''}`.trim()
                  : 'Customer';

                return (
                  <div
                    key={order.id}
                    className="py-3 flex items-center justify-between text-xs hover:bg-muted/30 transition-colors rounded px-2"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-foreground">
                          #{order.order_number}
                        </span>
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase ${
                            order.status === 'CONFIRMED' || order.status === 'DELIVERED'
                              ? 'bg-emerald-500/10 text-emerald-600'
                              : order.status === 'PENDING'
                              ? 'bg-amber-500/10 text-amber-600'
                              : 'bg-muted text-muted-foreground'
                          }`}
                        >
                          {order.status}
                        </span>
                      </div>
                      <p className="text-muted-foreground">
                        {customerName} • {new Date(order.created_at).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-bold text-foreground block">
                        {formatPrice(order.total_amount)}
                      </span>
                      <span className="text-[10px] font-mono uppercase text-muted-foreground">
                        {order.payment_method}
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-8 text-center text-xs text-muted-foreground italic">
                No orders recorded yet.
              </div>
            )}
          </div>
        </div>

        {/* Abandoned Form Leads */}
        <div className="lg:col-span-5 bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-border">
            <div className="flex items-center gap-2">
              <span className="text-base">🧲</span>
              <h2 className="text-sm font-bold text-foreground">Abandoned Form Leads</h2>
            </div>
            <Link
              href={`/${subaccountSlug}/${locale}/admin/leads`}
              className="text-xs text-primary font-medium hover:underline"
            >
              Recover Leads →
            </Link>
          </div>

          <div className="divide-y divide-border/60">
            {recentLeads.length > 0 ? (
              recentLeads.map((lead) => {
                const name =
                  `${lead.first_name ?? ''} ${lead.last_name ?? ''}`.trim() ||
                  'Incomplete Prospect';

                return (
                  <div
                    key={lead.id}
                    className="py-3 flex items-center justify-between text-xs hover:bg-muted/30 transition-colors rounded px-2"
                  >
                    <div>
                      <p className="font-semibold text-foreground">{name}</p>
                      <p className="font-mono text-xs text-muted-foreground">
                        {lead.phone || 'No phone recorded'}
                      </p>
                    </div>

                    {lead.phone && (
                      <a
                        href={`https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="py-1 px-2.5 bg-emerald-600 text-white rounded text-[11px] font-semibold hover:bg-emerald-700 transition-colors shadow-sm"
                      >
                        WhatsApp
                      </a>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="py-8 text-center text-xs text-muted-foreground italic">
                No abandoned leads recorded.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
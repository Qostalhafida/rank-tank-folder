import React from 'react';
import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { getSessionContext } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';

interface SubaccountAdminLayoutProps {
  children: React.ReactNode;
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

interface NavItem {
  label: string;
  path: string;
  icon: string;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Overview', path: '', icon: '📊' },
  { label: 'Contacts CRM', path: '/contacts', icon: '👥' },
  { label: 'Pipelines', path: '/pipelines', icon: '📋' },
  { label: 'Orders & COD', path: '/orders', icon: '📦' },
  { label: 'Abandoned Leads', path: '/leads', icon: '🧲' },
  { label: 'Funnels', path: '/funnels', icon: '⚡' },
  { label: 'Products', path: '/products', icon: '🏷️' },
  { label: 'Workflows', path: '/workflows', icon: '🔄' },
  { label: 'Calendars', path: '/calendars', icon: '📅' },
  { label: 'Digital Assets', path: '/digital', icon: '💾' },
  { label: 'Print Waybills', path: '/print/waybills', icon: '🖨️' },
  { label: 'Settings', path: '/settings', icon: '⚙️' },
];

export default async function SubaccountAdminLayout({
  children,
  params,
}: SubaccountAdminLayoutProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Enforce Authentication & RBAC Guard
  let session;
  try {
    session = await getSessionContext(tenant.id);
  } catch {
    redirect(`/${subaccountSlug}/${locale}/login`);
  }

  const isAgencyUser = session.role.startsWith('AGENCY_');

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col md:flex-row font-sans">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-card border-r border-border shrink-0 flex flex-col justify-between">
        <div>
          {/* Tenant Switcher & Header */}
          <div className="p-4 border-b border-border space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground font-bold flex items-center justify-center text-sm shrink-0">
                  {tenant.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <h2 className="text-xs font-bold text-foreground truncate">
                    {tenant.name}
                  </h2>
                  <span className="text-[10px] font-mono text-muted-foreground uppercase">
                    {tenant.mode} Mode
                  </span>
                </div>
              </div>

              {isAgencyUser && (
                <Link
                  href="/agency/subaccounts"
                  title="Switch to Agency Super-Admin"
                  className="p-1.5 rounded-md hover:bg-muted text-muted-foreground text-xs"
                >
                  ⇄
                </Link>
              )}
            </div>

            {/* Quick Public Storefront Link */}
            <Link
              href={`/${subaccountSlug}/${locale}`}
              target="_blank"
              className="w-full py-1.5 px-2 bg-muted text-foreground text-[11px] font-medium rounded flex items-center justify-between hover:bg-muted/80 transition-colors"
            >
              <span>View Public Storefront</span>
              <span>↗</span>
            </Link>
          </div>

          {/* Navigation Items */}
          <nav className="p-2 space-y-0.5 overflow-y-auto max-h-[calc(100vh-160px)]">
            {NAV_ITEMS.map((item) => {
              const fullHref = `/${subaccountSlug}/${locale}/admin${item.path}`;

              return (
                <Link
                  key={item.path}
                  href={fullHref}
                  className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
                >
                  <span className="text-sm shrink-0">{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* User Session Footer */}
        <div className="p-4 border-t border-border bg-muted/20 flex items-center justify-between">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-foreground truncate">
              {session.email}
            </p>
            <p className="text-[10px] font-mono text-muted-foreground uppercase">
              {session.role.replace('SUBACCOUNT_', '').replace('AGENCY_', '')}
            </p>
          </div>

          <form
            action={async () => {
              'use server';
              const supabase = await createServerClient();
              await supabase.auth.signOut();
              redirect(`/${subaccountSlug}/${locale}/login`);
            }}
          >
            <button
              type="submit"
              title="Sign Out"
              className="text-xs text-muted-foreground hover:text-destructive p-1 rounded hover:bg-muted"
            >
              ⏻
            </button>
          </form>
        </div>
      </aside>

      {/* Main Admin Workspace */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <div className="flex-1 p-6 md:p-8 max-w-7xl w-full mx-auto">{children}</div>
      </main>
    </div>
  );
}
import { Inngest } from 'inngest';
import { serve } from 'inngest/next';
import { createAdminClient } from '@/lib/supabase/admin';
import { dispatchWebhook } from '@/lib/webhooks/dispatch';
import { WorkflowCanvasNode } from '@/types/workflows';

export const inngest = new Inngest({
  id: 'my-ecommerce-platform',
  eventKey: process.env.INNGEST_EVENT_KEY,
});

/**
 * 1. Background Automation Workflow Engine
 * Listens for workflow execution events, traverses graph nodes, handles step delays, and executes actions.
 */
export const runWorkflowExecution = inngest.createFunction(
  { id: 'execute-workflow-engine', concurrency: 10 },
  { event: 'workflow.execute' },
  async ({ event, step }) => {
    const { workflowId, subaccountId, triggerType, payload } = event.data as {
      workflowId: string;
      subaccountId: string;
      triggerType: string;
      payload: Record<string, any>;
    };

    const supabase = createAdminClient();

    // Fetch active workflow configuration
    const workflow = await step.run('fetch-workflow-definition', async () => {
      const { data, error } = await supabase
        .from('workflows')
        .select('*')
        .eq('id', workflowId)
        .eq('subaccount_id', subaccountId)
        .eq('is_active', true)
        .single();

      if (error || !data) {
        throw new Error(`Workflow not found or inactive: ${error?.message}`);
      }
      return data;
    });

    const nodes = (workflow.nodes as unknown as WorkflowCanvasNode[]) || [];

    // Traverse nodes sequentially
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];

      // Handle Delays / Wait Timers
      if (node.type === 'DELAY' && node.data.delayConfig) {
        const { amount, unit } = node.data.delayConfig;
        const sleepDuration = `${amount}${unit.charAt(0)}` as `${number}${'s' | 'm' | 'h' | 'd'}`;
        await step.sleep(`delay-node-${node.id}`, sleepDuration);
        continue;
      }

      // Handle Actions
      if (node.type === 'ACTION' && node.data.actionType) {
        await step.run(`execute-action-${node.id}`, async () => {
          switch (node.data.actionType) {
            case 'ADD_TAG': {
              const tagId = node.data.configPayload?.tagId as string;
              const contactId = payload.contactId as string;
              if (tagId && contactId) {
                await supabase.from('contact_tags').upsert(
                  {
                    subaccount_id: subaccountId,
                    contact_id: contactId,
                    tag_id: tagId,
                  },
                  { onConflict: 'contact_id,tag_id', ignoreDuplicates: true }
                );
              }
              break;
            }

            case 'MOVE_PIPELINE_STAGE': {
              const opportunityId = payload.opportunityId as string;
              const targetStageId = node.data.configPayload?.targetStageId as string;
              if (opportunityId && targetStageId) {
                await supabase
                  .from('opportunities')
                  .update({ stage_id: targetStageId, updated_at: new Date().toISOString() })
                  .eq('id', opportunityId)
                  .eq('subaccount_id', subaccountId);
              }
              break;
            }

            case 'DISPATCH_WEBHOOK': {
              const webhookUrl = node.data.configPayload?.webhookUrl as string;
              const webhookSecret = (node.data.configPayload?.webhookSecret as string) || 'default-secret';
              if (webhookUrl) {
                await dispatchWebhook({
                  url: webhookUrl,
                  secret: webhookSecret,
                  subaccountId,
                  event: triggerType,
                  data: payload,
                });
              }
              break;
            }

            default:
              break;
          }

          return { executedNodeId: node.id, action: node.data.actionType };
        });
      }
    }

    return { completed: true, workflowId };
  }
);

/**
 * 2. Automated Abandoned Lead Recovery Job
 * Waits 30 minutes after partial checkout capture. If no completed order is recorded, dispatches recovery event.
 */
export const handleAbandonedLeadRecovery = inngest.createFunction(
  { id: 'abandoned-lead-recovery-handler' },
  { event: 'lead.captured' },
  async ({ event, step }) => {
    const { subaccountId, leadContactId } = event.data as {
      subaccountId: string;
      leadContactId: string;
    };

    // Wait 30 minutes for customer to finish checkout
    await step.sleep('wait-for-checkout-completion', '30m');

    await step.run('check-conversion-and-notify', async () => {
      const supabase = createAdminClient();

      const { data: contact } = await supabase
        .from('contacts')
        .select('orders_count, phone, email, first_name')
        .eq('id', leadContactId)
        .eq('subaccount_id', subaccountId)
        .single();

      // If contact never finalized an order (orders_count === 0), trigger outbound n8n recovery event
      if (contact && contact.orders_count === 0) {
        await inngest.send({
          name: 'webhook.dispatch',
          data: {
            subaccountId,
            event: 'LEAD_ABANDONED_RECOVERY',
            data: {
              contactId: leadContactId,
              firstName: contact.first_name,
              phone: contact.phone,
              email: contact.email,
            },
          },
        });
      }
    });

    return { evaluatedLeadId: leadContactId };
  }
);

export const { GET, POST, PUT } = serve({
  client: inngest,
  functions: [runWorkflowExecution, handleAbandonedLeadRecovery],
});
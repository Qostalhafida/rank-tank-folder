import { createHash } from 'crypto';
import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';

interface TrackingUserData {
  email?: string;
  phone?: string;
  firstName?: string;
  lastName?: string;
  city?: string;
  country?: string;
  fbp?: string;
  fbc?: string;
  ttclid?: string;
}

interface CapiRequestBody {
  subaccountId: string;
  eventName: 'PageView' | 'ViewContent' | 'AddToCart' | 'InitiateCheckout' | 'Purchase' | 'Lead';
  eventId: string;
  eventSourceUrl: string;
  userData?: TrackingUserData;
  customData?: {
    currency?: string;
    value?: number;
    contentName?: string;
    contentIds?: string[];
    orderId?: string;
  };
}

function hashSha256(value: string | undefined): string | undefined {
  if (!value) return undefined;
  return createHash('sha256')
    .update(value.trim().toLowerCase())
    .digest('hex');
}

export async function POST(req: Request) {
  try {
    const headersList = await headers();
    const clientIp = headersList.get('x-forwarded-for')?.split(',')[0].trim() ||
      headersList.get('x-real-ip') ||
      '';
    const clientUserAgent = headersList.get('user-agent') || '';

    const body: CapiRequestBody = await req.json();
    const { subaccountId, eventName, eventId, eventSourceUrl, userData, customData } = body;

    if (!subaccountId || !eventName || !eventId) {
      return NextResponse.json(
        { error: 'Missing required tracking parameters: subaccountId, eventName, eventId' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // 1. Fetch Tenant Pixel Configurations
    const { data: subaccount, error: tenantErr } = await supabase
      .from('subaccounts')
      .select('theme')
      .eq('id', subaccountId)
      .single();

    if (tenantErr || !subaccount) {
      return NextResponse.json({ error: 'Tenant subaccount not found' }, { status: 404 });
    }

    const pixelsConfig = (subaccount.theme as Record<string, any>)?.pixels as
      | {
          metaPixelId?: string;
          metaAccessToken?: string;
          tiktokPixelId?: string;
          tiktokAccessToken?: string;
        }
      | undefined;

    const results: Record<string, unknown> = {};
    const trackingPromises: Promise<any>[] = [];

    const unixTimestamp = Math.floor(Date.now() / 1000);

    // 2. Meta Conversions API (CAPI) Dispatch
    if (pixelsConfig?.metaPixelId && pixelsConfig?.metaAccessToken) {
      const metaPayload = {
        data: [
          {
            event_name: eventName,
            event_time: unixTimestamp,
            event_id: eventId,
            event_source_url: eventSourceUrl,
            action_source: 'website',
            user_data: {
              em: hashSha256(userData?.email),
              ph: hashSha256(userData?.phone),
              fn: hashSha256(userData?.firstName),
              ln: hashSha256(userData?.lastName),
              ct: hashSha256(userData?.city),
              country: hashSha256(userData?.country),
              client_ip_address: clientIp,
              client_user_agent: clientUserAgent,
              fbp: userData?.fbp,
              fbc: userData?.fbc,
            },
            custom_data: {
              currency: customData?.currency || 'USD',
              value: customData?.value,
              content_name: customData?.contentName,
              content_ids: customData?.contentIds,
              order_id: customData?.orderId,
            },
          },
        ],
      };

      const metaUrl = `https://graph.facebook.com/v19.0/${pixelsConfig.metaPixelId}/events?access_token=${pixelsConfig.metaAccessToken}`;

      trackingPromises.push(
        fetch(metaUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(metaPayload),
        })
          .then((res) => res.json())
          .then((data) => {
            results.meta = { success: !data.error, response: data };
          })
          .catch((err) => {
            results.meta = { success: false, error: err.message };
          })
      );
    }

    // 3. TikTok Events API Dispatch
    if (pixelsConfig?.tiktokPixelId && pixelsConfig?.tiktokAccessToken) {
      const tiktokPayload = {
        pixel_code: pixelsConfig.tiktokPixelId,
        event: eventName,
        event_id: eventId,
        timestamp: new Date().toISOString(),
        context: {
          page: { url: eventSourceUrl },
          user: {
            phone: hashSha256(userData?.phone),
            email: hashSha256(userData?.email),
            ttclid: userData?.ttclid,
          },
          ip: clientIp,
          user_agent: clientUserAgent,
        },
        properties: {
          currency: customData?.currency || 'USD',
          value: customData?.value,
          contents: customData?.contentIds?.map((id) => ({
            content_id: id,
            content_name: customData?.contentName,
          })),
        },
      };

      const tiktokUrl = 'https://business-api.tiktok.com/open_api/v1.3/event/track/';

      trackingPromises.push(
        fetch(tiktokUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Access-Token': pixelsConfig.tiktokAccessToken,
          },
          body: JSON.stringify(tiktokPayload),
        })
          .then((res) => res.json())
          .then((data) => {
            results.tiktok = { success: data.code === 0, response: data };
          })
          .catch((err) => {
            results.tiktok = { success: false, error: err.message };
          })
      );
    }

    await Promise.allSettled(trackingPromises);

    return NextResponse.json({
      dispatched: true,
      eventId,
      platforms: results,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Server-side CAPI tracking failed';
    console.error(`CAPI execution error: ${errorMsg}`);
    return NextResponse.json({ error: errorMsg }, { status: 500 });
  }
}
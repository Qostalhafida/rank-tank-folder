import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  createSignedVaultUrl,
  InvalidTokenError,
  verifyDownloadToken,
} from '@/lib/storage/tokens';

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params;

  if (!token) {
    return NextResponse.json({ error: 'Download token is required' }, { status: 400 });
  }

  try {
    // 1. Verify token signature, validity, and limits
    const payload = verifyDownloadToken(token);
    const supabase = createAdminClient();

    // 2. Fetch digital asset metadata
    const { data: asset, error: assetErr } = await supabase
      .from('digital_assets')
      .select('*')
      .eq('id', payload.asset_id)
      .eq('subaccount_id', payload.subaccount_id)
      .single();

    if (assetErr || !asset) {
      return NextResponse.json({ error: 'Digital asset not found' }, { status: 404 });
    }

    // 3. Verify order status has not been cancelled or refunded
    const { data: order, error: orderErr } = await supabase
      .from('orders')
      .select('status, payment_status')
      .eq('id', payload.order_id)
      .single();

    if (orderErr || !order) {
      return NextResponse.json({ error: 'Associated order not found' }, { status: 404 });
    }

    if (order.status === 'CANCELLED' || order.payment_status === 'REFUNDED') {
      return NextResponse.json(
        { error: 'Order has been cancelled or refunded. Access revoked.' },
        { status: 403 }
      );
    }

    // 4. Generate short-lived signed URL to the private Supabase storage bucket
    const signedVaultUrl = await createSignedVaultUrl(asset.storage_path, 60);

    // 5. Fetch stream from private storage
    const storageResponse = await fetch(signedVaultUrl);
    if (!storageResponse.ok || !storageResponse.body) {
      return NextResponse.json(
        { error: 'Unable to stream file from secure vault' },
        { status: 502 }
      );
    }

    // 6. Record download event
    await supabase
      .from('digital_downloads')
      .insert({
        subaccount_id: payload.subaccount_id,
        asset_id: payload.asset_id,
        order_id: payload.order_id,
        contact_id: payload.contact_id,
        downloaded_at: new Date().toISOString(),
      })
      .catch((err) => console.warn('Failed to record download log:', err));

    // 7. Stream file to client with attachment headers
    const sanitizedFilename = encodeURIComponent(asset.file_name);
    const headers = new Headers();
    headers.set('Content-Type', asset.mime_type || 'application/octet-stream');
    headers.set(
      'Content-Disposition',
      `attachment; filename="${asset.file_name}"; filename*=UTF-8''${sanitizedFilename}`
    );

    if (asset.file_size_bytes) {
      headers.set('Content-Length', asset.file_size_bytes.toString());
    }

    return new Response(storageResponse.body, {
      status: 200,
      headers,
    });
  } catch (err: unknown) {
    if (err instanceof InvalidTokenError) {
      return NextResponse.json({ error: err.message }, { status: 403 });
    }

    const message = err instanceof Error ? err.message : 'Download streaming failed';
    console.error(`Asset streaming error: ${message}`);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
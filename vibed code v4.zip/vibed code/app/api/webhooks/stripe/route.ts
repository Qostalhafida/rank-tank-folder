import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { createAdminClient } from '@/lib/supabase/admin';
import { IdempotencyLedger } from '@/lib/idempotency/ledger';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || '';

export async function POST(req: Request) {
  const body = await req.text();
  const headersList = await headers();
  const signature = headersList.get('stripe-signature');

  if (!signature || !STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json(
      { error: 'Missing stripe signature or webhook secret configuration' },
      { status: 400 }
    );
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(body, signature, STRIPE_WEBHOOK_SECRET);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Invalid signature';
    console.error(`Stripe Webhook Signature Verification Failed: ${message}`);
    return NextResponse.json({ error: `Webhook Error: ${message}` }, { status: 400 });
  }

  const idempotencyKey = `stripe_evt_${event.id}`;

  try {
    const result = await IdempotencyLedger.execute(
      idempotencyKey,
      async () => {
        const supabase = createAdminClient();

        switch (event.type) {
          case 'checkout.session.completed': {
            const session = event.data.object as Stripe.Checkout.Session;
            const subaccountId = session.metadata?.subaccountId;
            const orderId = session.metadata?.orderId;

            if (orderId && subaccountId) {
              // 1. Mark Order as Confirmed and Paid
              const { data: updatedOrder, error: orderErr } = await supabase
                .from('orders')
                .update({
                  status: 'CONFIRMED',
                  payment_status: 'PAID',
                  payment_method: 'STRIPE',
                  updated_at: new Date().toISOString(),
                })
                .eq('id', orderId)
                .eq('subaccount_id', subaccountId)
                .select('contact_id, total_amount')
                .single();

              if (orderErr) {
                throw new Error(`Failed to update order status: ${orderErr.message}`);
              }

              // 2. Increment Contact Lifetime Value
              if (updatedOrder?.contact_id) {
                const { data: contact } = await supabase
                  .from('contacts')
                  .select('lifetime_value, orders_count')
                  .eq('id', updatedOrder.contact_id)
                  .single();

                if (contact) {
                  await supabase
                    .from('contacts')
                    .update({
                      lifetime_value: contact.lifetime_value + updatedOrder.total_amount,
                      orders_count: contact.orders_count + 1,
                      updated_at: new Date().toISOString(),
                    })
                    .eq('id', updatedOrder.contact_id);
                }
              }

              // 3. Dispense digital license keys if applicable
              const { data: orderItems } = await supabase
                .from('order_items')
                .select('product_id')
                .eq('order_id', orderId);

              if (orderItems && orderItems.length > 0) {
                for (const item of orderItems) {
                  // Find available license key for this product
                  const { data: keyRecord } = await supabase
                    .from('digital_assets')
                    .select('id')
                    .eq('product_id', item.product_id)
                    .eq('asset_type', 'LICENSE_KEY')
                    .limit(1)
                    .maybeSingle();

                  if (keyRecord) {
                    // Update key pool status
                    await supabase
                      .from('license_keys')
                      .update({
                        status: 'ASSIGNED',
                        order_id: orderId,
                        contact_id: updatedOrder?.contact_id ?? null,
                        assigned_at: new Date().toISOString(),
                      })
                      .eq('product_id', item.product_id)
                      .eq('status', 'AVAILABLE')
                      .limit(1);
                  }
                }
              }
            }
            break;
          }

          case 'payment_intent.payment_failed': {
            const paymentIntent = event.data.object as Stripe.PaymentIntent;
            const subaccountId = paymentIntent.metadata?.subaccountId;
            const orderId = paymentIntent.metadata?.orderId;

            if (orderId && subaccountId) {
              await supabase
                .from('orders')
                .update({
                  status: 'CANCELLED',
                  payment_status: 'UNPAID',
                  updated_at: new Date().toISOString(),
                })
                .eq('id', orderId)
                .eq('subaccount_id', subaccountId);
            }
            break;
          }

          case 'charge.refunded': {
            const charge = event.data.object as Stripe.Charge;
            const orderId = charge.metadata?.orderId;
            const subaccountId = charge.metadata?.subaccountId;

            if (orderId && subaccountId) {
              await supabase
                .from('orders')
                .update({
                  payment_status: 'REFUNDED',
                  status: 'RETURNED',
                  updated_at: new Date().toISOString(),
                })
                .eq('id', orderId)
                .eq('subaccount_id', subaccountId);
            }
            break;
          }

          default:
            // Unhandled events are acknowledged without error
            break;
        }

        return { processed: true, eventId: event.id };
      },
      {
        lockTtlSeconds: 180,
        retentionSeconds: 86400 * 7, // 7 days retention for webhook deduplication
      }
    );

    return NextResponse.json(result);
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Webhook execution failed';
    console.error(`Stripe Webhook Processing Error [${event.id}]:`, errorMsg);
    return NextResponse.json({ error: errorMsg }, { status: 500 });
  }
}
import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { dispatchWebhook } from '@/lib/webhooks/dispatch';

interface OutboundWebhookPayload {
  subaccountId: string;
  event: string;
  data: Record<string, unknown>;
}

export async function POST(req: Request) {
  // 1. Authorize internal caller
  const internalSecret = req.headers.get('x-internal-secret');
  const expectedSecret = process.env.INTERNAL_SERVICE_KEY;

  if (!expectedSecret || internalSecret !== expectedSecret) {
    return NextResponse.json({ error: 'Unauthorized internal call' }, { status: 401 });
  }

  let body: OutboundWebhookPayload;

  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 });
  }

  const { subaccountId, event, data } = body;

  if (!subaccountId || !event || !data) {
    return NextResponse.json(
      { error: 'Missing required fields: subaccountId, event, or data' },
      { status: 400 }
    );
  }

  try {
    const supabase = createAdminClient();

    // 2. Fetch configured outbound integrations for this subaccount
    const { data: subaccount, error } = await supabase
      .from('subaccounts')
      .select('theme')
      .eq('id', subaccountId)
      .single();

    if (error || !subaccount) {
      return NextResponse.json({ error: 'Subaccount not found' }, { status: 404 });
    }

    // Integrations metadata saved in tenant configuration
    const integrations = (subaccount.theme as Record<string, any>)?.integrations?.webhooks as
      | { url: string; secret: string; events: string[]; isActive: boolean }[]
      | undefined;

    if (!integrations || integrations.length === 0) {
      return NextResponse.json({ message: 'No active webhooks configured for tenant' });
    }

    // 3. Filter matching target endpoints
    const matchingEndpoints = integrations.filter(
      (hook) =>
        hook.isActive &&
        (hook.events.includes('*') || hook.events.includes(event))
    );

    if (matchingEndpoints.length === 0) {
      return NextResponse.json({ message: `No active subscribers for event: ${event}` });
    }

    // 4. Dispatch HMAC-signed events concurrently
    const dispatchPromises = matchingEndpoints.map((hook) =>
      dispatchWebhook({
        url: hook.url,
        secret: hook.secret,
        subaccountId,
        event,
        data,
      })
    );

    const results = await Promise.allSettled(dispatchPromises);

    const summary = results.map((res, index) => ({
      url: matchingEndpoints[index].url,
      status: res.status === 'fulfilled' ? res.value : { success: false, error: res.reason },
    }));

    return NextResponse.json({
      dispatchedCount: summary.length,
      deliveries: summary,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Dispatch failure';
    console.error(`Outbound webhook dispatcher error: ${errorMsg}`);
    return NextResponse.json({ error: errorMsg }, { status: 500 });
  }
}
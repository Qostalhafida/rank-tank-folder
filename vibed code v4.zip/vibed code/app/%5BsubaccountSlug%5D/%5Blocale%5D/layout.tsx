import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import {
  generateTenantThemeStyles,
  getLocaleDirection,
} from '@/lib/theme/tenant-theme';
import { SupportedLocale } from '@/types/subaccount';

interface TenantLocaleLayoutProps {
  children: React.ReactNode;
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

const VALID_LOCALES: SupportedLocale[] = ['en', 'ar', 'fr', 'es', 'pt', 'it'];

export async function generateMetadata({
  params,
}: {
  params: Promise<{ subaccountSlug: string; locale: string }>;
}) {
  const { subaccountSlug } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');

  if (!subaccountRes.success || !subaccountRes.data) {
    return { title: 'Storefront Not Found' };
  }

  const tenant = subaccountRes.data;
  return {
    title: {
      default: tenant.name,
      template: `%s | ${tenant.name}`,
    },
    icons: tenant.theme?.brandFaviconUrl
      ? [{ rel: 'icon', url: tenant.theme.brandFaviconUrl }]
      : undefined,
  };
}

export default async function TenantLocaleLayout({
  children,
  params,
}: TenantLocaleLayoutProps) {
  const { subaccountSlug, locale } = await params;

  if (!VALID_LOCALES.includes(locale as SupportedLocale)) {
    notFound();
  }

  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');

  if (!subaccountRes.success || !subaccountRes.data) {
    notFound();
  }

  const tenant = subaccountRes.data;
  const direction = getLocaleDirection(locale);
  const themeStyles = generateTenantThemeStyles(tenant.theme);

  return (
    <div
      lang={locale}
      dir={direction}
      className={`min-h-screen bg-background text-foreground font-${
        tenant.theme?.fontFamily || 'sans'
      } ${direction === 'rtl' ? 'rtl' : 'ltr'}`}
    >
      {/* Injects dynamic CSS variables scoped to tenant brand identity */}
      <style
        id="tenant-theme-variables"
        dangerouslySetInnerHTML={{ __html: themeStyles }}
      />
      {children}
    </div>
  );
}
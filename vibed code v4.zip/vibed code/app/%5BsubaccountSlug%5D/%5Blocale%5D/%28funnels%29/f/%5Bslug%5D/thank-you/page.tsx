import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createAdminClient } from '@/lib/supabase/admin';
import { MultilingualText } from '@/types/database';

interface FunnelThankYouPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    slug: string;
  }>;
  searchParams: Promise<{
    order?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Order Confirmed - Thank You',
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function FunnelThankYouPage({
  params,
  searchParams,
}: FunnelThankYouPageProps) {
  const { subaccountSlug, locale, slug } = await params;
  const { order: orderQuery } = await searchParams;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const supabase = createAdminClient();

  // 2. Fetch Order and Line Items
  let order = null;
  let orderItems: any[] = [];

  if (orderQuery) {
    const { data: o } = await supabase
      .from('orders')
      .select('*')
      .eq('subaccount_id', tenant.id)
      .or(`order_number.eq.${orderQuery},id.eq.${orderQuery}`)
      .maybeSingle();

    if (o) {
      order = o;
      const { data: items } = await supabase
        .from('order_items')
        .select('*')
        .eq('order_id', o.id);
      orderItems = items || [];
    }
  }

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
    }).format(val);

  const shippingAddress = order?.shipping_address as Record<string, any> | null;
  const isCod = order?.payment_method === 'COD';

  return (
    <div className="w-full min-h-screen bg-muted/10 py-12 px-4 sm:px-6 flex items-center justify-center">
      <div className="w-full max-w-2xl bg-card border border-border rounded-2xl p-6 sm:p-10 shadow-xl space-y-8 text-center">
        {/* Success Icon & Heading */}
        <div className="space-y-3">
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 rounded-full flex items-center justify-center text-3xl mx-auto shadow-sm">
            ✓
          </div>
          <span className="inline-block px-3 py-1 bg-emerald-500/10 text-emerald-600 text-xs font-bold uppercase rounded-full tracking-wider">
            Order Successfully Placed
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
            Thank You for Your Order!
          </h1>
          {order && (
            <p className="text-sm font-mono text-muted-foreground">
              Order Reference:{' '}
              <span className="font-bold text-foreground">#{order.order_number}</span>
            </p>
          )}
        </div>

        {/* Delivery Process Banner */}
        <div className="p-4 bg-muted/30 border border-border rounded-xl text-left space-y-2">
          <h3 className="text-xs font-bold text-foreground uppercase tracking-wider flex items-center gap-1.5">
            <span>📦</span> What Happens Next?
          </h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {isCod
              ? 'Our fulfillment team will contact you via phone or WhatsApp shortly to verify your delivery address. Please ensure your phone is accessible.'
              : 'Your payment was received. Our warehouse is preparing your package for immediate courier pickup.'}
          </p>
        </div>

        {/* Order Receipt Details */}
        {order && (
          <div className="border border-border rounded-xl p-5 text-left space-y-4">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider border-b border-border pb-2">
              Receipt Summary
            </h3>

            {/* Line items list */}
            <div className="divide-y divide-border/60">
              {orderItems.map((item) => {
                const titleText =
                  typeof item.product_title === 'string'
                    ? item.product_title
                    : (item.product_title as MultilingualText)?.[locale] ||
                      (item.product_title as MultilingualText)?.en ||
                      'Product';

                return (
                  <div key={item.id} className="py-2.5 flex justify-between items-center text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-foreground">
                        x{item.quantity}
                      </span>
                      <span className="text-foreground font-medium">{titleText}</span>
                    </div>
                    <span className="font-mono font-bold text-foreground">
                      {formatPrice(item.total_price)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Financial totals */}
            <div className="pt-3 border-t border-border space-y-1.5 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono text-foreground font-medium">
                  {formatPrice(order.subtotal)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span className="font-medium text-emerald-600 uppercase text-[11px]">
                  {order.shipping_cost > 0 ? formatPrice(order.shipping_cost) : 'Free'}
                </span>
              </div>
              <div className="flex justify-between text-sm font-bold text-foreground pt-2 border-t border-border">
                <span>Total Payable {isCod ? '(Cash on Delivery)' : ''}</span>
                <span className="font-mono text-primary text-base">
                  {formatPrice(order.total_amount)}
                </span>
              </div>
            </div>

            {/* Destination Address */}
            {shippingAddress && (
              <div className="pt-3 border-t border-border text-xs text-muted-foreground">
                <span className="block font-semibold text-foreground mb-1">
                  Recipient & Destination:
                </span>
                <p className="text-foreground">
                  {shippingAddress.firstName} {shippingAddress.lastName} •{' '}
                  <span className="font-mono">{shippingAddress.phone}</span>
                </p>
                <p>
                  {shippingAddress.addressLine1}
                  {shippingAddress.city ? `, ${shippingAddress.city}` : ''}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          {order && (
            <Link
              href={`/${subaccountSlug}/${locale}/track?order=${encodeURIComponent(
                order.order_number
              )}`}
              className="py-2.5 px-5 bg-card border border-border text-xs font-semibold rounded-lg hover:bg-muted/50 transition-colors shadow-sm"
            >
              Track Order Status
            </Link>
          )}

          <Link
            href={`/${subaccountSlug}/${locale}`}
            className="py-2.5 px-5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-primary/90 transition-all shadow-sm"
          >
            Return to Store
          </Link>
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { getFunnelBySlug } from '@/server/actions/funnels';

interface FunnelLayoutProps {
  children: React.ReactNode;
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    slug: string;
  }>;
}

export default async function FunnelDistractionFreeLayout({
  children,
  params,
}: FunnelLayoutProps) {
  const { subaccountSlug, slug } = await params;

  // 1. Validate Tenant Subaccount Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Validate Funnel Exists and Is Active
  const funnelRes = await getFunnelBySlug(subaccountSlug, slug);
  if (!funnelRes.success || !funnelRes.data) notFound();

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground antialiased selection:bg-primary/20 selection:text-primary">
      {/* Minimal Top Brand Bar (Distraction-free: No exit links or navigation menus) */}
      <header className="border-b border-border/40 bg-card/60 backdrop-blur-sm py-3 px-4 sticky top-0 z-30">
        <div className="container mx-auto max-w-4xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            {tenant.theme?.brandLogoUrl ? (
              <img
                src={tenant.theme.brandLogoUrl}
                alt={tenant.name}
                className="h-7 w-auto object-contain"
              />
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-primary text-primary-foreground font-black text-xs flex items-center justify-center">
                  {tenant.name.charAt(0)}
                </div>
                <span className="font-bold text-xs tracking-tight text-foreground">
                  {tenant.name}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 text-[11px] font-medium text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="hidden sm:inline">256-Bit SSL Encrypted & Verified Order</span>
          </div>
        </div>
      </header>

      {/* Funnel Step Viewport (Landing -> Upsell -> Downsell -> Thank You) */}
      <main className="flex-1 flex flex-col">{children}</main>

      {/* Discrete Compliance Footer */}
      <footer className="py-6 border-t border-border/50 text-center text-[11px] text-muted-foreground bg-muted/10 space-y-1">
        <div className="flex justify-center items-center gap-3 text-xs mb-1">
          <span>🔒 Insured Delivery</span>
          <span>•</span>
          <span>💵 Cash on Delivery Verified</span>
          <span>•</span>
          <span>📦 Direct Warehouse Dispatch</span>
        </div>
        <p>© {new Date().getFullYear()} {tenant.name}. All rights reserved.</p>
      </footer>
    </div>
  );
}
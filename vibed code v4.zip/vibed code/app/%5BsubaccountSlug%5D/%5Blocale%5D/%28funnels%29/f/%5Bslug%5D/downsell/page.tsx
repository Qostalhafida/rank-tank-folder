import { notFound, redirect } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { getFunnelBySlug } from '@/server/actions/funnels';
import { createAdminClient } from '@/lib/supabase/admin';
import { PostPurchaseUpsellCard } from '@/components/funnels/PostPurchaseUpsellCard';
import { MultilingualText } from '@/types/database';

interface FunnelDownsellPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    slug: string;
  }>;
  searchParams: Promise<{
    order?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Special Downsell Offer',
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function FunnelDownsellPage({
  params,
  searchParams,
}: FunnelDownsellPageProps) {
  const { subaccountSlug, locale, slug } = await params;
  const { order: orderQuery } = await searchParams;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // Fallback if no order parameter is attached
  if (!orderQuery) {
    redirect(`/${subaccountSlug}/${locale}/f/${slug}/thank-you`);
  }

  // 2. Fetch Funnel Definition and Locate Downsell Step
  const funnelRes = await getFunnelBySlug(subaccountSlug, slug);
  if (!funnelRes.success || !funnelRes.data) notFound();
  const funnel = funnelRes.data;

  const downsellStep = funnel.steps.find((s) => s.step_type === 'DOWNSELL');
  const thankYouUrl = `/${subaccountSlug}/${locale}/f/${slug}/thank-you?order=${encodeURIComponent(
    orderQuery
  )}`;

  // If no downsell step is configured in this funnel sequence, proceed directly to receipt
  if (!downsellStep) {
    redirect(thankYouUrl);
  }

  // 3. Resolve Customer Order
  const supabase = createAdminClient();
  const { data: orderRecord, error: orderErr } = await supabase
    .from('orders')
    .select('id, order_number')
    .eq('subaccount_id', tenant.id)
    .or(`order_number.eq.${orderQuery},id.eq.${orderQuery}`)
    .maybeSingle();

  if (orderErr || !orderRecord) {
    redirect(thankYouUrl);
  }

  // 4. Resolve Linked Downsell Product
  const stepSettings = (downsellStep.settings as Record<string, any>) || {};
  let downsellProduct = null;

  if (stepSettings.productId) {
    const { data: p } = await supabase
      .from('products')
      .select('*')
      .eq('id', stepSettings.productId)
      .eq('subaccount_id', tenant.id)
      .maybeSingle();
    downsellProduct = p;
  }

  // Fallback: Pick an alternative product from catalog
  if (!downsellProduct) {
    const { data: fallbackProduct } = await supabase
      .from('products')
      .select('*')
      .eq('subaccount_id', tenant.id)
      .eq('is_active', true)
      .limit(1)
      .maybeSingle();
    downsellProduct = fallbackProduct;
  }

  if (!downsellProduct) {
    redirect(thankYouUrl);
  }

  // Highly discounted downsell pricing (e.g. 50% discount to secure secondary conversion)
  const discountedPrice =
    typeof stepSettings.discountedPrice === 'number'
      ? stepSettings.discountedPrice
      : Math.round(downsellProduct.price * 0.5);

  return (
    <div className="w-full min-h-screen bg-muted/20 flex items-center justify-center py-12 px-4 sm:px-6">
      <div className="w-full max-w-xl space-y-4">
        {/* Downsell Header Notice */}
        <div className="text-center space-y-1">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            Final Opportunity
          </span>
          <h1 className="text-xl font-extrabold text-foreground">
            We Understand! How About This Smaller Alternative?
          </h1>
          <p className="text-xs text-muted-foreground">
            Get this essential starter add-on with free combined shipping added to Order #{orderRecord.order_number}.
          </p>
        </div>

        <PostPurchaseUpsellCard
          orderId={orderRecord.id}
          orderNumber={orderRecord.order_number}
          subaccountId={tenant.id}
          subaccountSlug={subaccountSlug}
          locale={locale}
          currency={tenant.currency || 'USD'}
          product={{
            id: downsellProduct.id,
            title: downsellProduct.title as MultilingualText,
            description: downsellProduct.description as MultilingualText,
            price: discountedPrice,
            compareAtPrice: downsellProduct.price,
            image: downsellProduct.images?.[0],
          }}
          nextStepUrl={thankYouUrl}
          downsellUrl={thankYouUrl} // If declined, finalize flow
        />
      </div>
    </div>
  );
}
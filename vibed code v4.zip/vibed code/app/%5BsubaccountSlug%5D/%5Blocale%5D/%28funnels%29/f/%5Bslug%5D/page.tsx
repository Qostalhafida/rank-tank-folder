import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { getFunnelBySlug } from '@/server/actions/funnels';
import { createAdminClient } from '@/lib/supabase/admin';
import { CodCheckoutForm } from '@/components/storefront/CodCheckoutForm';
import { MultilingualText } from '@/types/database';

interface FunnelLandingPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    slug: string;
  }>;
}

export async function generateMetadata({ params }: FunnelLandingPageProps) {
  const { subaccountSlug, slug } = await params;
  const funnelRes = await getFunnelBySlug(subaccountSlug, slug);

  if (!funnelRes.success || !funnelRes.data) {
    return { title: 'Special Offer' };
  }

  return {
    title: funnelRes.data.name,
    robots: {
      index: true,
      follow: true,
    },
  };
}

export default async function FunnelLandingPage({ params }: FunnelLandingPageProps) {
  const { subaccountSlug, locale, slug } = await params;

  // 1. Resolve Subaccount Tenant
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Fetch Funnel with Sequence Steps
  const funnelRes = await getFunnelBySlug(subaccountSlug, slug);
  if (!funnelRes.success || !funnelRes.data) notFound();
  const funnel = funnelRes.data;

  // 3. Resolve Product linked to this Funnel Step
  const landingStep = funnel.steps.find(
    (s) => s.step_type === 'LANDING' || s.step_type === 'CHECKOUT'
  );

  const stepSettings = (landingStep?.settings as Record<string, any>) || {};
  const linkedProductId = stepSettings.productId;

  const supabase = createAdminClient();
  let product = null;

  if (linkedProductId) {
    const { data: p } = await supabase
      .from('products')
      .select('*')
      .eq('id', linkedProductId)
      .eq('subaccount_id', tenant.id)
      .maybeSingle();
    product = p;
  }

  // Fallback: If no explicit product assigned, grab top active product
  if (!product) {
    const { data: fallbackProduct } = await supabase
      .from('products')
      .select('*')
      .eq('subaccount_id', tenant.id)
      .eq('is_active', true)
      .limit(1)
      .maybeSingle();
    product = fallbackProduct;
  }

  if (!product) notFound();

  // 4. Determine Post-Purchase Next Step (Upsell vs Direct Thank You)
  const hasUpsell = funnel.steps.some((s) => s.step_type === 'UPSELL');
  const successRedirectBase = hasUpsell
    ? `/${subaccountSlug}/${locale}/f/${slug}/upsell`
    : `/${subaccountSlug}/${locale}/f/${slug}/thank-you`;

  const localizedTitle =
    product.title[locale] || product.title.en || 'Exclusive Bundle Offer';
  const localizedDescription =
    product.description?.[locale] || product.description?.en || '';

  return (
    <div className="w-full min-h-screen bg-muted/10 py-8 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Funnel Urgency Header */}
        <div className="text-center space-y-2">
          <span className="inline-block px-3 py-1 bg-red-500/10 text-red-600 border border-red-500/20 rounded-full text-xs font-bold uppercase tracking-wider animate-pulse">
            🔥 Limited Time Flash Offer • Free Express Delivery
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-foreground tracking-tight leading-tight">
            {stepSettings.headline || localizedTitle}
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground max-w-xl mx-auto">
            {stepSettings.subheadline || 'Order now and pay only in cash when your parcel is delivered to your doorstep.'}
          </p>
        </div>

        {/* Media Showcase */}
        {product.images && product.images.length > 0 && (
          <div className="max-w-md mx-auto aspect-square bg-card border border-border rounded-2xl overflow-hidden shadow-lg">
            <img
              src={product.images[0]}
              alt={localizedTitle}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto text-center py-2">
          <div className="p-3 bg-card border border-border rounded-xl">
            <span className="text-xl block mb-1">🚚</span>
            <h4 className="text-xs font-bold text-foreground">Free Shipping</h4>
            <p className="text-[11px] text-muted-foreground mt-0.5">Direct to your home or office</p>
          </div>
          <div className="p-3 bg-card border border-border rounded-xl">
            <span className="text-xl block mb-1">💵</span>
            <h4 className="text-xs font-bold text-foreground">Cash On Delivery</h4>
            <p className="text-[11px] text-muted-foreground mt-0.5">100% Risk-free payment</p>
          </div>
          <div className="p-3 bg-card border border-border rounded-xl">
            <span className="text-xl block mb-1">⭐️</span>
            <h4 className="text-xs font-bold text-foreground">Premium Quality</h4>
            <p className="text-[11px] text-muted-foreground mt-0.5">Guaranteed satisfaction</p>
          </div>
        </div>

        {/* Product Details Markdown Copy */}
        {localizedDescription && (
          <div className="max-w-2xl mx-auto bg-card border border-border p-6 rounded-xl shadow-sm">
            <h3 className="text-sm font-bold text-foreground uppercase tracking-wider mb-2">
              Product Overview
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
              {localizedDescription}
            </p>
          </div>
        )}

        {/* Direct COD Checkout Form Section */}
        <div id="checkout-form-section" className="scroll-mt-6">
          <CodCheckoutForm
            subaccountId={tenant.id}
            subaccountSlug={subaccountSlug}
            locale={locale}
            currency={tenant.currency || 'USD'}
            funnelSlug={slug}
            product={{
              id: product.id,
              title: product.title,
              price: product.price,
              image: product.images?.[0],
            }}
            onSuccessRedirectUrl={successRedirectBase}
          />
        </div>
      </div>
    </div>
  );
}
import { notFound, redirect } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { getFunnelBySlug } from '@/server/actions/funnels';
import { createAdminClient } from '@/lib/supabase/admin';
import { PostPurchaseUpsellCard } from '@/components/funnels/PostPurchaseUpsellCard';
import { MultilingualText } from '@/types/database';

interface FunnelUpsellPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    slug: string;
  }>;
  searchParams: Promise<{
    order?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Exclusive Post-Purchase Offer',
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function FunnelUpsellPage({
  params,
  searchParams,
}: FunnelUpsellPageProps) {
  const { subaccountSlug, locale, slug } = await params;
  const { order: orderQuery } = await searchParams;

  // 1. Resolve Subaccount Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // If no order identifier provided, skip directly to thank you page
  if (!orderQuery) {
    redirect(`/${subaccountSlug}/${locale}/f/${slug}/thank-you`);
  }

  // 2. Fetch Funnel and Identify Upsell & Downsell Steps
  const funnelRes = await getFunnelBySlug(subaccountSlug, slug);
  if (!funnelRes.success || !funnelRes.data) notFound();
  const funnel = funnelRes.data;

  const upsellStep = funnel.steps.find((s) => s.step_type === 'UPSELL');
  if (!upsellStep) {
    // If funnel has no upsell step configured, proceed directly to thank you
    redirect(`/${subaccountSlug}/${locale}/f/${slug}/thank-you?order=${encodeURIComponent(orderQuery)}`);
  }

  const hasDownsell = funnel.steps.some((s) => s.step_type === 'DOWNSELL');
  const downsellUrl = hasDownsell
    ? `/${subaccountSlug}/${locale}/f/${slug}/downsell?order=${encodeURIComponent(orderQuery)}`
    : undefined;
  const thankYouUrl = `/${subaccountSlug}/${locale}/f/${slug}/thank-you?order=${encodeURIComponent(orderQuery)}`;

  // 3. Resolve Customer Order
  const supabase = createAdminClient();
  const { data: orderRecord, error: orderErr } = await supabase
    .from('orders')
    .select('id, order_number')
    .eq('subaccount_id', tenant.id)
    .or(`order_number.eq.${orderQuery},id.eq.${orderQuery}`)
    .maybeSingle();

  if (orderErr || !orderRecord) {
    redirect(`/${subaccountSlug}/${locale}/f/${slug}/thank-you`);
  }

  // 4. Resolve Linked Upsell Product
  const stepSettings = (upsellStep.settings as Record<string, any>) || {};
  let upsellProduct = null;

  if (stepSettings.productId) {
    const { data: p } = await supabase
      .from('products')
      .select('*')
      .eq('id', stepSettings.productId)
      .eq('subaccount_id', tenant.id)
      .maybeSingle();
    upsellProduct = p;
  }

  // Fallback: Pick another product from the subaccount catalog
  if (!upsellProduct) {
    const { data: fallbackProduct } = await supabase
      .from('products')
      .select('*')
      .eq('subaccount_id', tenant.id)
      .eq('is_active', true)
      .limit(1)
      .maybeSingle();
    upsellProduct = fallbackProduct;
  }

  if (!upsellProduct) {
    redirect(thankYouUrl);
  }

  // Allow custom discounted price override configured in the upsell step
  const discountedPrice =
    typeof stepSettings.discountedPrice === 'number'
      ? stepSettings.discountedPrice
      : Math.round(upsellProduct.price * 0.7); // Default 30% discount

  return (
    <div className="w-full min-h-screen bg-muted/20 flex items-center justify-center py-12 px-4 sm:px-6">
      <PostPurchaseUpsellCard
        orderId={orderRecord.id}
        orderNumber={orderRecord.order_number}
        subaccountId={tenant.id}
        subaccountSlug={subaccountSlug}
        locale={locale}
        currency={tenant.currency || 'USD'}
        product={{
          id: upsellProduct.id,
          title: upsellProduct.title as MultilingualText,
          description: upsellProduct.description as MultilingualText,
          price: discountedPrice,
          compareAtPrice: upsellProduct.price,
          image: upsellProduct.images?.[0],
        }}
        nextStepUrl={thankYouUrl}
        downsellUrl={downsellUrl}
      />
    </div>
  );
}
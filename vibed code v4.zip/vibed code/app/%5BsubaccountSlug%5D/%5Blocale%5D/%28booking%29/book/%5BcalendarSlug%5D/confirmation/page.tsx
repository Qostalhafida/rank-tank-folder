'use client';

import React, { use, useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { Appointment } from '@/types/booking';

interface BookingConfirmationPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    calendarSlug: string;
  }>;
  searchParams: Promise<{
    id?: string;
  }>;
}

export default function BookingConfirmationPage({
  params,
  searchParams,
}: BookingConfirmationPageProps) {
  const { subaccountSlug, locale, calendarSlug } = use(params);
  const { id: appointmentId } = use(searchParams);

  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [calendarName, setCalendarName] = useState('Consultation');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!appointmentId) {
      setLoading(false);
      return;
    }

    const supabase = createClient();
    supabase
      .from('appointments')
      .select(`
        *,
        contacts (
          first_name,
          last_name,
          email,
          phone
        ),
        calendars (
          name
        )
      `)
      .eq('id', appointmentId)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setAppointment({
            ...data,
            contact: data.contacts ?? null,
          } as unknown as Appointment);

          if ((data.calendars as any)?.name) {
            setCalendarName((data.calendars as any).name);
          }
        }
        setLoading(false);
      });
  }, [appointmentId]);

  const handleDownloadIcs = () => {
    // 1. Check if cached ICS payload was set in sessionStorage
    const cachedIcs = sessionStorage.getItem('last_ics');
    let icsData = cachedIcs;

    // 2. Fallback basic RFC 5545 generator if accessed directly
    if (!icsData && appointment) {
      const dtStart = appointment.start_time.replace(/[-:]/g, '').replace(/\.\d{3}/, '');
      const dtEnd = appointment.end_time.replace(/[-:]/g, '').replace(/\.\d{3}/, '');

      icsData = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//MultiTenant Platform//EN',
        'BEGIN:VEVENT',
        `UID:${appointment.id}@platform`,
        `DTSTART:${dtStart}`,
        `DTEND:${dtEnd}`,
        `SUMMARY:${calendarName}`,
        'DESCRIPTION:Scheduled Consultation',
        'STATUS:CONFIRMED',
        'END:VEVENT',
        'END:VCALENDAR',
      ].join('\r\n');
    }

    if (!icsData) return;

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `appointment-${appointmentId || 'booking'}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-sm text-muted-foreground">
        <span className="animate-spin mr-2">⟳</span> Loading booking details...
      </div>
    );
  }

  const startDate = appointment ? new Date(appointment.start_time) : new Date();
  const endDate = appointment ? new Date(appointment.end_time) : new Date();

  return (
    <div className="min-h-screen bg-muted/10 py-12 px-4 sm:px-6 flex items-center justify-center">
      <div className="w-full max-w-xl bg-card border border-border rounded-2xl p-6 sm:p-10 shadow-xl space-y-6 text-center">
        {/* Confirmed Icon */}
        <div className="w-16 h-16 bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 rounded-full flex items-center justify-center text-3xl mx-auto shadow-sm">
          ✓
        </div>

        <div className="space-y-1">
          <span className="inline-block px-3 py-1 bg-emerald-500/10 text-emerald-600 text-xs font-bold uppercase rounded-full tracking-wider">
            Booking Confirmed
          </span>
          <h1 className="text-2xl font-bold text-foreground">You are all set!</h1>
          <p className="text-xs text-muted-foreground">
            A calendar invitation and confirmation notice have been sent to your email.
          </p>
        </div>

        {/* Appointment Card */}
        <div className="p-5 bg-muted/30 border border-border rounded-xl text-left space-y-4 font-sans">
          <div className="border-b border-border/80 pb-3">
            <h3 className="font-bold text-sm text-foreground">{calendarName}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              With {appointment?.contact?.first_name} {appointment?.contact?.last_name}
            </p>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center gap-2 text-foreground font-medium">
              <span className="text-base">📅</span>
              <span>
                {startDate.toLocaleDateString(locale, {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
            </div>

            <div className="flex items-center gap-2 text-foreground font-medium">
              <span className="text-base">⏰</span>
              <span className="font-mono">
                {startDate.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })} -{' '}
                {endDate.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>

            <div className="flex items-center gap-2 text-muted-foreground">
              <span className="text-base">📍</span>
              <span>Web Conference link will be shared via email</span>
            </div>
          </div>
        </div>

        {/* .ICS Export and Calendar Buttons */}
        <div className="space-y-3 pt-2">
          <button
            type="button"
            onClick={handleDownloadIcs}
            className="w-full py-3 px-4 bg-primary text-primary-foreground font-semibold text-xs rounded-xl hover:bg-primary/90 transition-all shadow-md flex items-center justify-center gap-2"
          >
            <span>📥 Export to Calendar (.ics)</span>
          </button>

          <Link
            href={`/${subaccountSlug}/${locale}/book/${calendarSlug}`}
            className="block text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            Book Another Appointment
          </Link>
        </div>
      </div>
    </div>
  );
}
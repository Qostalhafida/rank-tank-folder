'use client';

import React, { use, useEffect, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import {
  getCalendarBySlug,
  getAvailableSlotsForDate,
  reserveAppointment,
} from '@/server/actions/booking';
import { AvailableSlot, Calendar } from '@/types/booking';

interface BookingPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    calendarSlug: string;
  }>;
}

export default function BookingPage({ params }: BookingPageProps) {
  const { subaccountSlug, locale, calendarSlug } = use(params);
  const router = useRouter();

  const [calendar, setCalendar] = useState<Calendar | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [availableSlots, setAvailableSlots] = useState<AvailableSlot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<AvailableSlot | null>(null);
  const [step, setStep] = useState<'SLOT' | 'DETAILS'>('SLOT');

  // Form Fields
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [isPending, startTransition] = useTransition();

  // 1. Fetch Calendar Configuration on Mount
  useEffect(() => {
    getCalendarBySlug(subaccountSlug, calendarSlug).then((res) => {
      if (res.success && res.data) {
        setCalendar(res.data);
        // Default to today's date formatted as YYYY-MM-DD
        const today = new Date().toISOString().split('T')[0];
        setSelectedDate(today);
      }
    });
  }, [subaccountSlug, calendarSlug]);

  // 2. Fetch Available Slots when Date Changes
  useEffect(() => {
    if (calendar && selectedDate) {
      setSelectedSlot(null);
      startTransition(async () => {
        const res = await getAvailableSlotsForDate(calendar.id, selectedDate);
        if (res.success && res.data) {
          setAvailableSlots(res.data);
        }
      });
    }
  }, [calendar, selectedDate]);

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!calendar || !selectedSlot) return;

    if (!firstName.trim() || !lastName.trim() || !email.trim()) {
      setErrorMsg('Please complete all required fields.');
      return;
    }

    setErrorMsg(null);
    startTransition(async () => {
      const res = await reserveAppointment({
        calendarId: calendar.id,
        subaccountId: calendar.subaccount_id,
        startTime: selectedSlot.startTime,
        notes: notes.trim() || undefined,
        contact: {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: email.trim(),
          phone: phone.trim() || undefined,
        },
      });

      if (res.success && res.data) {
        // Store ICS content in sessionStorage for immediate export on confirmation screen
        sessionStorage.setItem('last_ics', res.data.icsContent);
        router.push(
          `/${subaccountSlug}/${locale}/book/${calendarSlug}/confirmation?id=${encodeURIComponent(
            res.data.appointment.id
          )}`
        );
      } else {
        setErrorMsg(res.error || 'Failed to reserve appointment. Slot may be taken.');
      }
    });
  };

  if (!calendar) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-sm text-muted-foreground">
        <span className="animate-spin mr-2">⟳</span> Loading availability schedule...
      </div>
    );
  }

  const formatSlotTime = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-muted/10 py-10 px-4 sm:px-6 flex items-center justify-center">
      <div className="w-full max-w-4xl bg-card border border-border rounded-2xl shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-12">
        {/* Left Column: Calendar Details */}
        <div className="md:col-span-4 p-6 sm:p-8 bg-muted/20 border-b md:border-b-0 md:border-r border-border space-y-4">
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-primary">
              Native Scheduling
            </span>
            <h1 className="text-xl font-bold text-foreground">{calendar.name}</h1>
          </div>

          <div className="space-y-2 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span>⏱</span>
              <span>{calendar.duration_minutes} minutes duration</span>
            </div>
            <div className="flex items-center gap-2">
              <span>🌐</span>
              <span>{calendar.timezone} timezone</span>
            </div>
            <div className="flex items-center gap-2">
              <span>📅</span>
              <span>Video / Phone Consultation</span>
            </div>
          </div>

          {selectedSlot && (
            <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg text-xs text-primary space-y-1">
              <span className="font-semibold block">Selected Slot:</span>
              <p className="font-mono">
                {new Date(selectedSlot.startTime).toLocaleDateString(locale, {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                })}{' '}
                at {formatSlotTime(selectedSlot.startTime)}
              </p>
            </div>
          )}
        </div>

        {/* Right Column: Interactive Slot Picker & Details Form */}
        <div className="md:col-span-8 p-6 sm:p-8 flex flex-col justify-between">
          {errorMsg && (
            <div className="mb-4 p-3 bg-destructive/10 text-destructive text-xs rounded-md border border-destructive/20">
              {errorMsg}
            </div>
          )}

          {step === 'SLOT' ? (
            <div className="space-y-6">
              {/* Date Input */}
              <div>
                <label className="block text-xs font-semibold text-foreground uppercase tracking-wider mb-2">
                  Select a Date
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3.5 py-2 text-sm bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              {/* Slot Grid */}
              <div>
                <label className="block text-xs font-semibold text-foreground uppercase tracking-wider mb-2">
                  Available Slots ({availableSlots.filter((s) => s.available).length})
                </label>

                {isPending ? (
                  <div className="h-40 flex items-center justify-center text-xs text-muted-foreground">
                    <span className="animate-spin mr-2">⟳</span> Checking available time slots...
                  </div>
                ) : availableSlots.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-64 overflow-y-auto pr-1">
                    {availableSlots.map((slot, idx) => (
                      <button
                        key={idx}
                        type="button"
                        disabled={!slot.available}
                        onClick={() => setSelectedSlot(slot)}
                        className={`py-2 px-3 text-xs font-mono font-medium rounded-lg border transition-all ${
                          selectedSlot?.startTime === slot.startTime
                            ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                            : slot.available
                            ? 'bg-background border-border hover:border-primary text-foreground'
                            : 'bg-muted/40 border-border/50 text-muted-foreground/50 cursor-not-allowed line-through'
                        }`}
                      >
                        {formatSlotTime(slot.startTime)}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 border border-dashed rounded-lg text-center text-xs text-muted-foreground">
                    No open availability found on this date. Please select another day.
                  </div>
                )}
              </div>

              {/* Step Navigation */}
              <div className="pt-4 border-t border-border flex justify-end">
                <button
                  type="button"
                  disabled={!selectedSlot}
                  onClick={() => setStep('DETAILS')}
                  className="py-2.5 px-5 bg-primary text-primary-foreground font-semibold text-xs rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
                >
                  Next: Enter Your Details →
                </button>
              </div>
            </div>
          ) : (
            /* Step 2: Attendee Details Form */
            <form onSubmit={handleBookingSubmit} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-border">
                <h3 className="text-sm font-semibold text-foreground">Your Information</h3>
                <button
                  type="button"
                  onClick={() => setStep('SLOT')}
                  className="text-xs text-primary hover:underline"
                >
                  ← Change Time Slot
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-foreground mb-1">
                    First Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-foreground mb-1">
                    Last Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-foreground mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-foreground mb-1">
                    Phone (Optional)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-foreground mb-1">
                  Additional Notes or Questions
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Share anything that will help prepare for our meeting..."
                  className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              <div className="pt-3 border-t border-border flex justify-end">
                <button
                  type="submit"
                  disabled={isPending}
                  className="py-2.5 px-6 bg-primary text-primary-foreground font-semibold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md disabled:opacity-50 flex items-center gap-2"
                >
                  {isPending && <span className="animate-spin">⟳</span>}
                  Confirm & Reserve Appointment
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
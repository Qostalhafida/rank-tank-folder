import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createFunnel, deleteFunnel, getFunnels } from '@/server/actions/funnels';
import { createServerClient } from '@/lib/supabase/server';

interface FunnelsAdminPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Sales Funnels & Conversion Analytics',
  };
}

export default async function FunnelsAdminPage({ params }: FunnelsAdminPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'funnels:read');

  // 2. Fetch Funnels with configured step sequences
  const funnelsRes = await getFunnels(tenant.id);
  const funnels = funnelsRes.data || [];

  // 3. Fetch Conversion Analytics for each funnel (Orders tied to funnel metadata)
  const supabase = await createServerClient();
  const { data: funnelOrders } = await supabase
    .from('orders')
    .select('id, total_amount, metadata, status')
    .eq('subaccount_id', tenant.id)
    .neq('status', 'CANCELLED');

  const analyticsMap: Record<string, { totalOrders: number; totalRevenue: number }> = {};

  (funnelOrders || []).forEach((order) => {
    const funnelSlug = (order.metadata as Record<string, any>)?.funnelSlug;
    if (funnelSlug) {
      if (!analyticsMap[funnelSlug]) {
        analyticsMap[funnelSlug] = { totalOrders: 0, totalRevenue: 0 };
      }
      analyticsMap[funnelSlug].totalOrders += 1;
      analyticsMap[funnelSlug].totalRevenue += order.total_amount || 0;
    }
  });

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(val);

  return (
    <div className="space-y-6">
      {/* Header & Quick Create */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">⚡</span>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Sales Funnels
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-primary/10 text-primary font-mono font-medium">
              {funnels.length} Active
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Distraction-free high-conversion landing pages, one-click bumps, and post-purchase offers.
          </p>
        </div>

        {/* Inline Create Funnel Action */}
        <form
          action={async (formData: FormData) => {
            'use server';
            const name = formData.get('name') as string;
            const slug = formData.get('slug') as string;
            if (name && slug) {
              await createFunnel(tenant.id, { name, slug });
            }
          }}
          className="flex gap-2 self-start sm:self-auto"
        >
          <input
            type="text"
            name="name"
            required
            placeholder="Funnel Name..."
            className="px-3 py-1.5 text-xs bg-card border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <input
            type="text"
            name="slug"
            required
            placeholder="slug-path"
            className="px-3 py-1.5 text-xs bg-card border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <button
            type="submit"
            className="px-3.5 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm shrink-0"
          >
            + Create Funnel
          </button>
        </form>
      </div>

      {/* Funnels List */}
      <div className="space-y-4">
        {funnels.length > 0 ? (
          funnels.map((funnel) => {
            const stats = analyticsMap[funnel.slug] || { totalOrders: 0, totalRevenue: 0 };
            const publicUrl = `/${subaccountSlug}/${locale}/f/${funnel.slug}`;

            return (
              <div
                key={funnel.id}
                className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4 hover:shadow-md transition-shadow"
              >
                {/* Funnel Card Header */}
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-border/80 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-foreground">{funnel.name}</h3>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 font-semibold uppercase">
                        Active
                      </span>
                    </div>
                    <Link
                      href={publicUrl}
                      target="_blank"
                      className="text-xs font-mono text-muted-foreground hover:text-primary transition-colors flex items-center gap-1 mt-0.5"
                    >
                      <span>/f/{funnel.slug}</span>
                      <span>↗</span>
                    </Link>
                  </div>

                  {/* Funnel Performance Badges */}
                  <div className="flex items-center gap-4 text-xs font-mono">
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-sans text-muted-foreground block">
                        Orders
                      </span>
                      <span className="font-bold text-foreground text-sm">
                        {stats.totalOrders}
                      </span>
                    </div>

                    <div className="text-right border-l border-border pl-4">
                      <span className="text-[10px] uppercase font-sans text-muted-foreground block">
                        Revenue
                      </span>
                      <span className="font-bold text-primary text-sm">
                        {formatPrice(stats.totalRevenue)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Steps Flow Sequence Representation */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
                    Funnel Architecture Flow ({funnel.steps.length} Steps)
                  </span>

                  <div className="flex items-center gap-2 flex-wrap text-xs">
                    {funnel.steps.map((step, idx) => (
                      <React.Fragment key={step.id}>
                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-muted/40 border border-border rounded-lg">
                          <span className="w-4 h-4 rounded-full bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center font-mono">
                            {idx + 1}
                          </span>
                          <span className="font-semibold text-foreground uppercase text-[11px]">
                            {step.step_type.replace('_', ' ')}
                          </span>
                        </div>
                        {idx < funnel.steps.length - 1 && (
                          <span className="text-muted-foreground font-bold">→</span>
                        )}
                      </React.Fragment>
                    ))}
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-2 flex justify-end items-center gap-3 border-t border-border/60">
                  <Link
                    href={publicUrl}
                    target="_blank"
                    className="text-xs text-primary font-medium hover:underline"
                  >
                    Preview Live
                  </Link>

                  <form
                    action={async () => {
                      'use server';
                      await deleteFunnel(tenant.id, funnel.id);
                    }}
                  >
                    <button
                      type="submit"
                      className="text-xs text-destructive hover:underline font-medium"
                    >
                      Delete
                    </button>
                  </form>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-12 border border-dashed border-border rounded-xl text-center text-xs text-muted-foreground bg-muted/10">
            No sales funnels created yet. Use the form above to deploy your first high-converting funnel.
          </div>
        )}
      </div>
    </div>
  );
}
import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createTag, deleteTag, getTags } from '@/server/actions/tags';
import { Tag } from '@/types/crm';

interface TagsSettingsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'CRM Tags & Segmentation',
  };
}

const SETTINGS_SECTIONS = [
  { label: 'General & Mode', href: '' },
  { label: 'Custom Domains', href: '/domains' },
  { label: 'Team & RBAC', href: '/team' },
  { label: 'Tags Manager', href: '/tags', active: true },
  { label: 'n8n Webhooks', href: '/integrations' },
  { label: 'Pixels & CAPI', href: '/pixels' },
];

const PRESET_COLORS = [
  { hex: '#3b82f6', label: 'Blue' },
  { hex: '#10b981', label: 'Emerald' },
  { hex: '#f59e0b', label: 'Amber' },
  { hex: '#ef4444', label: 'Red' },
  { hex: '#8b5cf6', label: 'Purple' },
  { hex: '#06b6d4', label: 'Cyan' },
  { hex: '#ec4899', label: 'Pink' },
  { hex: '#64748b', label: 'Slate' },
];

export default async function TagsSettingsPage({ params }: TagsSettingsPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'contacts:read');

  // 2. Fetch CRM Tags
  const tagsRes = await getTags(tenant.id);
  const tags: Tag[] = tagsRes.data || [];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground tracking-tight">CRM Tags Manager</h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Create and organize color-coded tags for automated audience segmentation and workflow triggers.
        </p>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
        {SETTINGS_SECTIONS.map((sec) => (
          <Link
            key={sec.href}
            href={`/${subaccountSlug}/${locale}/admin/settings${sec.href}`}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
              sec.active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {sec.label}
          </Link>
        ))}
      </div>

      {/* Create Tag Form */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-sm font-bold text-foreground">Create New Tag</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Tags can be manually attached or automatically applied through checkout form events.
          </p>
        </div>

        <form
          action={async (formData: FormData) => {
            'use server';
            await requirePermission(tenant.id, 'contacts:write');

            const name = (formData.get('name') as string)?.trim();
            const color = (formData.get('color') as string) || '#3b82f6';

            if (name) {
              await createTag(tenant.id, { name, color });
              revalidatePath(`/[subaccountSlug]/admin/settings/tags`, 'page');
            }
          }}
          className="space-y-4 text-xs"
        >
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              name="name"
              required
              placeholder="e.g. High Value VIP, Call Confirmed, Abandoned..."
              className="flex-1 px-3.5 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs"
            />

            <button
              type="submit"
              className="px-4 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm shrink-0"
            >
              + Create Tag
            </button>
          </div>

          {/* Color Selector */}
          <div className="flex items-center gap-3 pt-1">
            <span className="text-[11px] font-medium text-muted-foreground">Tag Color:</span>
            <div className="flex items-center gap-2 flex-wrap">
              {PRESET_COLORS.map((col, idx) => (
                <label key={col.hex} className="cursor-pointer">
                  <input
                    type="radio"
                    name="color"
                    value={col.hex}
                    defaultChecked={idx === 0}
                    className="sr-only peer"
                  />
                  <span
                    className="w-6 h-6 rounded-full block border-2 border-transparent peer-checked:ring-2 peer-checked:ring-primary peer-checked:ring-offset-2 transition-transform hover:scale-105"
                    style={{ backgroundColor: col.hex }}
                    title={col.label}
                  />
                </label>
              ))}
            </div>
          </div>
        </form>
      </div>

      {/* Tags Directory Table */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
          Configured CRM Tags ({tags.length})
        </h2>

        <div className="divide-y divide-border/60">
          {tags.length > 0 ? (
            tags.map((tag) => (
              <div
                key={tag.id}
                className="py-3 flex items-center justify-between text-xs hover:bg-muted/30 transition-colors rounded px-2"
              >
                <div className="flex items-center gap-3">
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: tag.color }}
                  />
                  <div>
                    <span className="font-semibold text-foreground">{tag.name}</span>
                    <span className="block text-[10px] text-muted-foreground font-mono">
                      Created on {new Date(tag.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-xs text-muted-foreground font-mono">
                    {tag.contacts_count ?? 0} Contacts
                  </span>

                  <form
                    action={async () => {
                      'use server';
                      await requirePermission(tenant.id, 'contacts:write');
                      await deleteTag(tenant.id, tag.id);
                      revalidatePath(`/[subaccountSlug]/admin/settings/tags`, 'page');
                    }}
                  >
                    <button
                      type="submit"
                      className="text-xs text-destructive hover:underline font-medium"
                    >
                      Delete
                    </button>
                  </form>
                </div>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-muted-foreground italic">
              No tags configured. Use the form above to add your first segment tag.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount, updateSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';

interface IntegrationsSettingsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'n8n & Outbound Webhook Integrations',
  };
}

const SETTINGS_SECTIONS = [
  { label: 'General & Mode', href: '' },
  { label: 'Custom Domains', href: '/domains' },
  { label: 'Team & RBAC', href: '/team' },
  { label: 'Tags Manager', href: '/tags' },
  { label: 'n8n Webhooks', href: '/integrations', active: true },
  { label: 'Pixels & CAPI', href: '/pixels' },
];

const AVAILABLE_EVENTS = [
  { key: '*', label: 'All Platform Events' },
  { key: 'ORDER_CREATED', label: 'Order Created (COD/Paid)' },
  { key: 'ORDER_STATUS_UPDATED', label: 'Order Status Changed' },
  { key: 'LEAD_CAPTURED', label: 'Abandoned Form Lead' },
  { key: 'CONTACT_TAGGED', label: 'Contact Tagged' },
  { key: 'APPOINTMENT_SCHEDULED', label: 'Appointment Reserved' },
];

export default async function IntegrationsSettingsPage({ params }: IntegrationsSettingsPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'settings:webhooks');

  const themeConfig = tenant.theme as Record<string, any>;
  const webhooks: {
    id: string;
    url: string;
    secret: string;
    events: string[];
    isActive: boolean;
  }[] = themeConfig?.integrations?.webhooks || [];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground tracking-tight">
          n8n & Webhook Dispatchers
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Stream realtime platform events to your self-hosted n8n instance or external workflows with HMAC SHA-256 signing.
        </p>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
        {SETTINGS_SECTIONS.map((sec) => (
          <Link
            key={sec.href}
            href={`/${subaccountSlug}/${locale}/admin/settings${sec.href}`}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
              sec.active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {sec.label}
          </Link>
        ))}
      </div>

      {/* Add Webhook Endpoint Form */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-sm font-bold text-foreground">Register Webhook Endpoint</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Configure an outbound listener URL to receive authenticated events automatically.
          </p>
        </div>

        <form
          action={async (formData: FormData) => {
            'use server';
            await requirePermission(tenant.id, 'settings:webhooks');

            const url = (formData.get('url') as string)?.trim();
            const secret = (formData.get('secret') as string)?.trim() || 'default-secret';
            const selectedEvents = formData.getAll('events') as string[];

            if (url) {
              const newWebhook = {
                id: `wh_${Date.now()}`,
                url,
                secret,
                events: selectedEvents.length > 0 ? selectedEvents : ['*'],
                isActive: true,
              };

              const existingHooks = themeConfig?.integrations?.webhooks || [];
              const updatedHooks = [...existingHooks, newWebhook];

              await updateSubaccount(tenant.id, {
                theme: {
                  ...themeConfig,
                  integrations: {
                    ...(themeConfig?.integrations || {}),
                    webhooks: updatedHooks,
                  },
                },
              });

              revalidatePath(`/[subaccountSlug]/admin/settings/integrations`, 'page');
            }
          }}
          className="space-y-4 text-xs"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Target Endpoint URL *
              </label>
              <input
                type="url"
                name="url"
                required
                placeholder="https://n8n.yourbrand.com/webhook/orders"
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                HMAC Signing Secret *
              </label>
              <input
                type="text"
                name="secret"
                defaultValue={`sec_${Date.now().toString(36)}`}
                required
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>
          </div>

          {/* Subscribed Events */}
          <div className="space-y-2 pt-1">
            <label className="block text-xs font-semibold text-foreground uppercase tracking-wider">
              Subscribe to Events
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {AVAILABLE_EVENTS.map((evt, idx) => (
                <label key={evt.key} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    name="events"
                    value={evt.key}
                    defaultChecked={idx === 0}
                    className="w-4 h-4 rounded text-primary focus:ring-primary/40 border-border"
                  />
                  <span className="text-xs text-foreground font-medium">{evt.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-4 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm"
            >
              + Add Webhook Listener
            </button>
          </div>
        </form>
      </div>

      {/* Active Endpoints List */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
          Active Outbound Listeners ({webhooks.length})
        </h2>

        <div className="divide-y divide-border/60">
          {webhooks.length > 0 ? (
            webhooks.map((hook) => (
              <div
                key={hook.id}
                className="py-3 flex flex-col sm:flex-row justify-between sm:items-center gap-3 text-xs"
              >
                <div className="space-y-1 min-w-0 pr-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-foreground truncate max-w-sm">
                      {hook.url}
                    </span>
                    <span
                      className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        hook.isActive ? 'bg-emerald-500/10 text-emerald-600' : 'bg-muted'
                      }`}
                    >
                      {hook.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <span>Events: {hook.events.join(', ')}</span>
                    <span>•</span>
                    <span className="font-mono">Secret: {hook.secret.slice(0, 6)}...</span>
                  </div>
                </div>

                <form
                  action={async () => {
                    'use server';
                    await requirePermission(tenant.id, 'settings:webhooks');
                    const updated = webhooks.filter((w) => w.id !== hook.id);
                    await updateSubaccount(tenant.id, {
                      theme: {
                        ...themeConfig,
                        integrations: {
                          ...(themeConfig?.integrations || {}),
                          webhooks: updated,
                        },
                      },
                    });
                    revalidatePath(`/[subaccountSlug]/admin/settings/integrations`, 'page');
                  }}
                >
                  <button
                    type="submit"
                    className="text-xs text-destructive hover:underline font-medium"
                  >
                    Remove
                  </button>
                </form>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-muted-foreground italic">
              No webhook listeners configured. Events are not currently dispatched to external services.
            </div>
          )}
        </div>
      </div>

      {/* n8n Integration Guide */}
      <div className="p-5 bg-card border border-border rounded-xl space-y-3 text-xs text-muted-foreground">
        <h3 className="font-bold text-foreground uppercase tracking-wider text-[11px]">
          n8n Webhook Signature Verification
        </h3>
        <p className="leading-relaxed">
          Outbound dispatches include the <code className="font-mono text-foreground font-bold">X-Webhook-Signature</code> header formatted as <code className="font-mono text-foreground">t=&lt;timestamp&gt;,v1=&lt;signature&gt;</code> computed via HMAC SHA-256 over <code className="font-mono text-foreground">&lt;timestamp&gt;.&lt;payload&gt;</code>. Use a Crypto node in n8n to verify message authenticity before processing orders or abandoned leads.
        </p>
      </div>
    </div>
  );
}
import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount, updateSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { SubaccountMode, SupportedLocale, TenantThemeConfig } from '@/types/subaccount';

interface SettingsAdminPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Store Settings & Master Mode',
  };
}

const SETTINGS_SECTIONS = [
  { label: 'General & Mode', href: '', active: true },
  { label: 'Custom Domains', href: '/domains' },
  { label: 'Team & RBAC', href: '/team' },
  { label: 'Tags Manager', href: '/tags' },
  { label: 'n8n Webhooks', href: '/integrations' },
  { label: 'Pixels & CAPI', href: '/pixels' },
];

export default async function SettingsAdminPage({ params }: SettingsAdminPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'settings:read');

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Settings Navigation Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground tracking-tight">Store Settings</h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Configure operations, branding, checkouts, and international currencies.
        </p>
      </div>

      {/* Sub-Settings Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
        {SETTINGS_SECTIONS.map((sec) => (
          <Link
            key={sec.href}
            href={`/${subaccountSlug}/${locale}/admin/settings${sec.href}`}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
              sec.active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {sec.label}
          </Link>
        ))}
      </div>

      {/* Main Settings Form */}
      <form
        action={async (formData: FormData) => {
          'use server';
          await requirePermission(tenant.id, 'settings:write');

          const name = formData.get('name') as string;
          const mode = formData.get('mode') as SubaccountMode;
          const currency = formData.get('currency') as string;
          const primaryColor = formData.get('primaryColor') as string;
          const secondaryColor = formData.get('secondaryColor') as string;
          const accentColor = formData.get('accentColor') as string;
          const borderRadius = formData.get('borderRadius') as TenantThemeConfig['borderRadius'];
          const brandLogoUrl = formData.get('brandLogoUrl') as string;

          const updatedTheme: TenantThemeConfig = {
            ...tenant.theme,
            primaryColor: primaryColor || '#2563eb',
            secondaryColor: secondaryColor || '#64748b',
            accentColor: accentColor || '#f59e0b',
            borderRadius: borderRadius || 'md',
            brandLogoUrl: brandLogoUrl || undefined,
          };

          await updateSubaccount(tenant.id, {
            name,
            mode,
            currency,
            theme: updatedTheme,
          });

          revalidatePath(`/[subaccountSlug]/admin/settings`, 'page');
        }}
        className="space-y-6"
      >
        {/* 1. Master Mode Switcher (COD / Online / Hybrid) */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
          <div>
            <h2 className="text-sm font-bold text-foreground">Operational Mode</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Select how your storefront and checkout engine process customer orders.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* COD Option */}
            <label className="relative p-4 rounded-xl border-2 border-border cursor-pointer hover:border-primary transition-all flex flex-col justify-between has-[:checked]:border-primary has-[:checked]:bg-primary/5">
              <input
                type="radio"
                name="mode"
                value="COD"
                defaultChecked={tenant.mode === 'COD'}
                className="sr-only"
              />
              <div className="space-y-1">
                <span className="text-lg block">💵</span>
                <span className="font-bold text-xs text-foreground block">
                  COD (Cash on Delivery)
                </span>
                <p className="text-[11px] text-muted-foreground leading-tight">
                  High-converting direct forms. Ideal for MENA, GCC, and local fulfillment markets.
                </p>
              </div>
            </label>

            {/* Online Option */}
            <label className="relative p-4 rounded-xl border-2 border-border cursor-pointer hover:border-primary transition-all flex flex-col justify-between has-[:checked]:border-primary has-[:checked]:bg-primary/5">
              <input
                type="radio"
                name="mode"
                value="ONLINE"
                defaultChecked={tenant.mode === 'ONLINE'}
                className="sr-only"
              />
              <div className="space-y-1">
                <span className="text-lg block">💳</span>
                <span className="font-bold text-xs text-foreground block">
                  Prepaid (Online Cart)
                </span>
                <p className="text-[11px] text-muted-foreground leading-tight">
                  Traditional e-commerce shopping cart with Stripe, cards, and instant download vault.
                </p>
              </div>
            </label>

            {/* Hybrid Option */}
            <label className="relative p-4 rounded-xl border-2 border-border cursor-pointer hover:border-primary transition-all flex flex-col justify-between has-[:checked]:border-primary has-[:checked]:bg-primary/5">
              <input
                type="radio"
                name="mode"
                value="HYBRID"
                defaultChecked={tenant.mode === 'HYBRID'}
                className="sr-only"
              />
              <div className="space-y-1">
                <span className="text-lg block">⚡</span>
                <span className="font-bold text-xs text-foreground block">Hybrid Mode</span>
                <p className="text-[11px] text-muted-foreground leading-tight">
                  Offers shoppers both Cash on Delivery and credit card online checkouts.
                </p>
              </div>
            </label>
          </div>
        </div>

        {/* 2. Store Identity & Currency */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-foreground">Store Identity & Currency</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Store Name
              </label>
              <input
                type="text"
                name="name"
                defaultValue={tenant.name}
                required
                className="w-full px-3.5 py-2 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Store Currency
              </label>
              <select
                name="currency"
                defaultValue={tenant.currency}
                className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md font-mono focus:outline-none"
              >
                <option value="USD">USD ($) - US Dollar</option>
                <option value="MAD">MAD (DH) - Moroccan Dirham</option>
                <option value="EUR">EUR (€) - Euro</option>
                <option value="SAR">SAR (ر.س) - Saudi Riyal</option>
                <option value="AED">AED (د.إ) - UAE Dirham</option>
                <option value="GBP">GBP (£) - British Pound</option>
              </select>
            </div>
          </div>
        </div>

        {/* 3. Theme & Brand Customization */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-foreground">Branding & CSS Variables</h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Primary Brand Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  name="primaryColor"
                  defaultValue={tenant.theme?.primaryColor || '#2563eb'}
                  className="w-8 h-8 rounded border border-input cursor-pointer"
                />
                <span className="font-mono text-xs text-muted-foreground">
                  {tenant.theme?.primaryColor || '#2563eb'}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Secondary Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  name="secondaryColor"
                  defaultValue={tenant.theme?.secondaryColor || '#64748b'}
                  className="w-8 h-8 rounded border border-input cursor-pointer"
                />
                <span className="font-mono text-xs text-muted-foreground">
                  {tenant.theme?.secondaryColor || '#64748b'}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Corner Radius
              </label>
              <select
                name="borderRadius"
                defaultValue={tenant.theme?.borderRadius || 'md'}
                className="w-full px-3 py-2 text-xs bg-background border border-input rounded-md font-medium focus:outline-none"
              >
                <option value="none">None (Square)</option>
                <option value="sm">Small (4px)</option>
                <option value="md">Medium (8px)</option>
                <option value="lg">Large (12px)</option>
                <option value="full">Pill / Full</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-foreground mb-1">
              Brand Logo URL (Optional)
            </label>
            <input
              type="url"
              name="brandLogoUrl"
              defaultValue={tenant.theme?.brandLogoUrl || ''}
              placeholder="https://cdn.yourdomain.com/logo.png"
              className="w-full px-3.5 py-2 text-xs bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md"
          >
            Save All Settings
          </button>
        </div>
      </form>
    </div>
  );
}
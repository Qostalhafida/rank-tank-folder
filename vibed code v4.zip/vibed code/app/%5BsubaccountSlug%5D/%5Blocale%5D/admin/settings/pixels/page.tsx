import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount, updateSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';

interface PixelsSettingsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Meta CAPI & TikTok Events Settings',
  };
}

const SETTINGS_SECTIONS = [
  { label: 'General & Mode', href: '' },
  { label: 'Custom Domains', href: '/domains' },
  { label: 'Team & RBAC', href: '/team' },
  { label: 'Tags Manager', href: '/tags' },
  { label: 'n8n Webhooks', href: '/integrations' },
  { label: 'Pixels & CAPI', href: '/pixels', active: true },
];

export default async function PixelsSettingsPage({ params }: PixelsSettingsPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'settings:pixels');

  const themeConfig = (tenant.theme as Record<string, any>) || {};
  const pixelsConfig = themeConfig.pixels || {};

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground tracking-tight">
          Tracking Pixels & Server-Side CAPI
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Configure server-side Meta Conversions API and TikTok Events API to bypass ad-blockers and iOS privacy restrictions.
        </p>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
        {SETTINGS_SECTIONS.map((sec) => (
          <Link
            key={sec.href}
            href={`/${subaccountSlug}/${locale}/admin/settings${sec.href}`}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
              sec.active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {sec.label}
          </Link>
        ))}
      </div>

      {/* Pixels & CAPI Settings Form */}
      <form
        action={async (formData: FormData) => {
          'use server';
          await requirePermission(tenant.id, 'settings:pixels');

          const metaPixelId = (formData.get('metaPixelId') as string)?.trim() || undefined;
          const metaAccessToken = (formData.get('metaAccessToken') as string)?.trim() || undefined;
          const tiktokPixelId = (formData.get('tiktokPixelId') as string)?.trim() || undefined;
          const tiktokAccessToken = (formData.get('tiktokAccessToken') as string)?.trim() || undefined;

          await updateSubaccount(tenant.id, {
            theme: {
              ...themeConfig,
              pixels: {
                metaPixelId,
                metaAccessToken,
                tiktokPixelId,
                tiktokAccessToken,
              },
            },
          });

          revalidatePath(`/[subaccountSlug]/admin/settings/pixels`, 'page');
        }}
        className="space-y-6 text-xs"
      >
        {/* 1. Meta (Facebook) Conversions API */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div className="flex items-center gap-2">
              <span className="text-lg">📘</span>
              <div>
                <h2 className="text-sm font-bold text-foreground">
                  Meta Conversions API (CAPI)
                </h2>
                <p className="text-[11px] text-muted-foreground">
                  Dispatches direct server-to-server Purchase and Lead events to Meta Events Manager.
                </p>
              </div>
            </div>

            {pixelsConfig.metaPixelId && pixelsConfig.metaAccessToken && (
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                Connected
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Meta Pixel ID
              </label>
              <input
                type="text"
                name="metaPixelId"
                defaultValue={pixelsConfig.metaPixelId || ''}
                placeholder="e.g. 123456789012345"
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Conversions API Access Token
              </label>
              <input
                type="password"
                name="metaAccessToken"
                defaultValue={pixelsConfig.metaAccessToken || ''}
                placeholder="EAAG..."
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>
          </div>
        </div>

        {/* 2. TikTok Events API */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div className="flex items-center gap-2">
              <span className="text-lg">🎵</span>
              <div>
                <h2 className="text-sm font-bold text-foreground">
                  TikTok Events API
                </h2>
                <p className="text-[11px] text-muted-foreground">
                  Server-side conversion tracking for TikTok Ads campaigns.
                </p>
              </div>
            </div>

            {pixelsConfig.tiktokPixelId && pixelsConfig.tiktokAccessToken && (
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                Connected
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                TikTok Pixel Code / ID
              </label>
              <input
                type="text"
                name="tiktokPixelId"
                defaultValue={pixelsConfig.tiktokPixelId || ''}
                placeholder="e.g. CXXXXXXXXXXXXXXX"
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                TikTok Events Access Token
              </label>
              <input
                type="password"
                name="tiktokAccessToken"
                defaultValue={pixelsConfig.tiktokAccessToken || ''}
                placeholder="TikTok Long-lived Token..."
                className="w-full px-3.5 py-2 bg-background border border-input rounded-md font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md"
          >
            Save Pixel Configurations
          </button>
        </div>
      </form>

      {/* Security & Hashing Documentation */}
      <div className="p-5 bg-card border border-border rounded-xl space-y-3 text-xs text-muted-foreground">
        <h3 className="font-bold text-foreground uppercase tracking-wider text-[11px]">
          Server-Side SHA-256 Data Protection
        </h3>
        <p className="leading-relaxed">
          All customer personal identifiers (phone numbers, email addresses, names, and delivery cities) dispatched through our server-side CAPI engine are automatically trimmed, lowercase normalized, and hashed using <strong className="text-foreground">SHA-256</strong> prior to transmission to Meta and TikTok servers to ensure full privacy compliance.
        </p>
      </div>
    </div>
  );
}
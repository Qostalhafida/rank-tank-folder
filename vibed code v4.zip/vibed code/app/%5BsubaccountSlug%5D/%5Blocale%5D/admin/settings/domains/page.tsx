import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { getCustomDomain } from '@/server/actions/domains';
import { CloudflareDnsCard } from '@/components/admin/settings/CloudflareDnsCard';

interface DomainSettingsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Custom Domain & SSL Settings',
  };
}

const SETTINGS_SECTIONS = [
  { label: 'General & Mode', href: '' },
  { label: 'Custom Domains', href: '/domains', active: true },
  { label: 'Team & RBAC', href: '/team' },
  { label: 'Tags Manager', href: '/tags' },
  { label: 'n8n Webhooks', href: '/integrations' },
  { label: 'Pixels & CAPI', href: '/pixels' },
];

export default async function DomainSettingsPage({ params }: DomainSettingsPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'settings:domains');

  // 2. Fetch Active Custom Domain Configuration
  const domainRes = await getCustomDomain(tenant.id);
  const domain = domainRes.data || null;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground tracking-tight">Custom Domains</h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Connect and verify your external branded domain with free automated SSL certificates.
        </p>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
        {SETTINGS_SECTIONS.map((sec) => (
          <Link
            key={sec.href}
            href={`/${subaccountSlug}/${locale}/admin/settings${sec.href}`}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
              sec.active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {sec.label}
          </Link>
        ))}
      </div>

      {/* Cloudflare Automated DNS Verification Card */}
      <CloudflareDnsCard subaccountId={tenant.id} initialDomain={domain} />

      {/* Informational Guidance */}
      <div className="p-5 bg-card border border-border rounded-xl space-y-3 text-xs text-muted-foreground">
        <h3 className="font-bold text-foreground uppercase tracking-wider text-[11px]">
          How Custom Domains Work
        </h3>
        <ul className="list-disc list-inside space-y-1.5 leading-relaxed">
          <li>
            <strong className="text-foreground">Edge Routing:</strong> Once validated, traffic to your domain will be routed directly to your subaccount storefront without showing our platform domain.
          </li>
          <li>
            <strong className="text-foreground">Automated SSL:</strong> Cloudflare provisions and renews SSL/TLS certificates automatically every 90 days.
          </li>
          <li>
            <strong className="text-foreground">Propagation:</strong> DNS changes typically take between 5 to 30 minutes to propagate worldwide depending on your registrar TTL settings.
          </li>
        </ul>
      </div>
    </div>
  );
}
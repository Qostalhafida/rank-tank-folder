import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount, inviteSubaccountMember, removeSubaccountMember } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createAdminClient } from '@/lib/supabase/admin';
import { SubaccountRole } from '@/types/rbac';

interface TeamSettingsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Team Members & RBAC Roles',
  };
}

const SETTINGS_SECTIONS = [
  { label: 'General & Mode', href: '' },
  { label: 'Custom Domains', href: '/domains' },
  { label: 'Team & RBAC', href: '/team', active: true },
  { label: 'Tags Manager', href: '/tags' },
  { label: 'n8n Webhooks', href: '/integrations' },
  { label: 'Pixels & CAPI', href: '/pixels' },
];

const ROLES_INFO: { role: SubaccountRole; label: string; desc: string }[] = [
  {
    role: 'SUBACCOUNT_ADMIN',
    label: 'Admin',
    desc: 'Full access to products, funnels, orders, CRM, and integrations.',
  },
  {
    role: 'SUBACCOUNT_AGENT',
    label: 'Call Center Agent',
    desc: 'Access to CRM contacts, deal pipelines, order status updates, and booking schedules.',
  },
  {
    role: 'SUBACCOUNT_STAFF',
    label: 'Fulfillment Staff',
    desc: 'Read-only order inspector and thermal waybill printing permissions.',
  },
];

export default async function TeamSettingsPage({ params }: TeamSettingsPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'team:manage');

  const supabase = createAdminClient();

  // 2. Fetch Members and Resolve User Profiles
  const { data: membersData } = await supabase
    .from('subaccount_members')
    .select('id, user_id, role, created_at')
    .eq('subaccount_id', tenant.id)
    .order('created_at', { ascending: true });

  const { data: usersData } = await supabase.auth.admin.listUsers();
  const allUsers = usersData?.users || [];

  const members = (membersData || []).map((m) => {
    const user = allUsers.find((u) => u.id === m.user_id);
    return {
      id: m.id,
      userId: m.user_id,
      role: m.role as SubaccountRole,
      createdAt: m.created_at,
      email: user?.email || 'Unknown User',
    };
  });

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground tracking-tight">Team & Permissions</h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Manage operator accounts and enforce Role-Based Access Control (RBAC).
        </p>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
        {SETTINGS_SECTIONS.map((sec) => (
          <Link
            key={sec.href}
            href={`/${subaccountSlug}/${locale}/admin/settings${sec.href}`}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
              sec.active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            {sec.label}
          </Link>
        ))}
      </div>

      {/* Invite Team Member Form */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-sm font-bold text-foreground">Assign New Team Member</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Add registered operators by email and define their operational role.
          </p>
        </div>

        <form
          action={async (formData: FormData) => {
            'use server';
            const email = formData.get('email') as string;
            const role = formData.get('role') as SubaccountRole;

            if (email && role) {
              await inviteSubaccountMember({
                subaccountId: tenant.id,
                email: email.trim(),
                role,
              });
              revalidatePath(`/[subaccountSlug]/admin/settings/team`, 'page');
            }
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <input
            type="email"
            name="email"
            required
            placeholder="operator@agency.com"
            className="flex-1 px-3.5 py-2 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
          />

          <select
            name="role"
            required
            className="px-3 py-2 text-xs bg-background border border-input rounded-md font-medium focus:outline-none"
          >
            {ROLES_INFO.map((r) => (
              <option key={r.role} value={r.role}>
                {r.label}
              </option>
            ))}
          </select>

          <button
            type="submit"
            className="px-4 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm shrink-0"
          >
            + Assign Operator
          </button>
        </form>
      </div>

      {/* Active Members Directory */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
          Active Store Operators ({members.length})
        </h2>

        <div className="divide-y divide-border/60">
          {members.map((member) => {
            const isOwner = member.role === 'SUBACCOUNT_OWNER';

            return (
              <div
                key={member.id}
                className="py-3.5 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center text-xs">
                    {member.email.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{member.email}</p>
                    <p className="text-[10px] text-muted-foreground font-mono">
                      Joined {new Date(member.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      isOwner
                        ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                        : member.role === 'SUBACCOUNT_ADMIN'
                        ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {member.role.replace('SUBACCOUNT_', '')}
                  </span>

                  {!isOwner && (
                    <form
                      action={async () => {
                        'use server';
                        await removeSubaccountMember(tenant.id, member.id);
                        revalidatePath(`/[subaccountSlug]/admin/settings/team`, 'page');
                      }}
                    >
                      <button
                        type="submit"
                        className="text-xs text-destructive hover:underline font-medium"
                      >
                        Remove
                      </button>
                    </form>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Role Explanations Reference */}
      <div className="p-5 bg-card border border-border rounded-xl space-y-3 text-xs text-muted-foreground">
        <h3 className="font-bold text-foreground uppercase tracking-wider text-[11px]">
          RBAC Permissions Matrix
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {ROLES_INFO.map((r) => (
            <div key={r.role} className="p-3 bg-muted/20 border border-border/80 rounded-lg space-y-1">
              <span className="font-bold text-foreground block">{r.label}</span>
              <p className="text-[11px] leading-tight">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
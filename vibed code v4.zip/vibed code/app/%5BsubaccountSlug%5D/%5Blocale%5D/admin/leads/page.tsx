import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { dismissAbandonedLead, getAbandonedLeads } from '@/server/actions/leads';

interface AbandonedLeadsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    page?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Abandoned Checkout Leads',
  };
}

export default async function AbandonedLeadsPage({
  params,
  searchParams,
}: AbandonedLeadsPageProps) {
  const { subaccountSlug, locale } = await params;
  const { page: pageQuery } = await searchParams;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'contacts:read');

  const page = Math.max(1, parseInt(pageQuery || '1', 10));
  const pageSize = 20;

  // 2. Fetch Abandoned Leads (Captured on input blur with zero completed orders)
  const leadsRes = await getAbandonedLeads(tenant.id, { page, limit: pageSize });
  const leads = leadsRes.data?.leads || [];
  const totalCount = leadsRes.data?.totalCount || 0;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">🧲</span>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Abandoned Form Leads
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-600 font-mono font-bold border border-amber-500/20">
              {totalCount} Unconverted
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Shoppers who began entering checkout details but dropped off before completing their order.
          </p>
        </div>
      </div>

      {/* Leads Table Container */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-border bg-muted/30 uppercase font-semibold text-muted-foreground tracking-wider">
              <th className="py-3 px-4">Lead Contact</th>
              <th className="py-3 px-4">Phone Number</th>
              <th className="py-3 px-4">City / Area</th>
              <th className="py-3 px-4">Captured</th>
              <th className="py-3 px-4">Tags</th>
              <th className="py-3 px-4 text-right">Direct Recovery</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {leads.length > 0 ? (
              leads.map((lead) => {
                const fullName =
                  `${lead.first_name ?? ''} ${lead.last_name ?? ''}`.trim() ||
                  'Incomplete Prospect';

                const sanitizedPhone = lead.phone ? lead.phone.replace(/[^0-9]/g, '') : null;

                return (
                  <tr key={lead.id} className="hover:bg-muted/30 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-amber-500/10 text-amber-600 font-bold flex items-center justify-center text-xs shrink-0">
                          {fullName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{fullName}</p>
                          <p className="text-[11px] text-muted-foreground">{lead.email || 'No email'}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                      {lead.phone || '—'}
                    </td>

                    <td className="py-3.5 px-4 text-muted-foreground">
                      {lead.city || '—'}
                    </td>

                    <td className="py-3.5 px-4 text-muted-foreground font-mono text-[11px]">
                      {new Date(lead.updated_at).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap gap-1">
                        {lead.tags && lead.tags.length > 0 ? (
                          lead.tags.map((tag) => (
                            <span
                              key={tag.id}
                              className="text-[10px] font-medium px-2 py-0.5 rounded-full border"
                              style={{
                                borderColor: `${tag.color}40`,
                                backgroundColor: `${tag.color}15`,
                                color: tag.color,
                              }}
                            >
                              {tag.name}
                            </span>
                          ))
                        ) : (
                          <span className="text-muted-foreground/60">—</span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      {sanitizedPhone && (
                        <>
                          <a
                            href={`https://wa.me/${sanitizedPhone}?text=${encodeURIComponent(
                              `Hello ${fullName}, we noticed you didn't finish your order on our store. Do you need any assistance?`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-block py-1 px-2.5 bg-emerald-600 text-white rounded text-[11px] font-bold hover:bg-emerald-700 transition-colors shadow-sm"
                          >
                            WhatsApp
                          </a>
                          <a
                            href={`tel:${sanitizedPhone}`}
                            className="inline-block py-1 px-2.5 bg-card border border-border text-foreground rounded text-[11px] font-medium hover:bg-muted transition-colors"
                          >
                            Call
                          </a>
                        </>
                      )}

                      <form
                        action={async () => {
                          'use server';
                          await dismissAbandonedLead(tenant.id, lead.id);
                        }}
                        className="inline-block"
                      >
                        <button
                          type="submit"
                          title="Dismiss Lead"
                          className="py-1 px-2 text-muted-foreground hover:text-destructive text-[11px] transition-colors"
                        >
                          ✕
                        </button>
                      </form>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6} className="py-12 text-center text-muted-foreground text-xs italic">
                  No abandoned leads found. All checkouts are converting or captured.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-xs pt-2">
          <a
            href={`/${subaccountSlug}/${locale}/admin/leads?page=${page - 1}`}
            className={`px-3 py-1.5 bg-card border border-border rounded-md ${
              page <= 1 ? 'pointer-events-none opacity-40' : 'hover:bg-muted'
            }`}
          >
            Previous
          </a>
          <span className="text-muted-foreground font-mono">
            Page {page} of {totalPages}
          </span>
          <a
            href={`/${subaccountSlug}/${locale}/admin/leads?page=${page + 1}`}
            className={`px-3 py-1.5 bg-card border border-border rounded-md ${
              page >= totalPages ? 'pointer-events-none opacity-40' : 'hover:bg-muted'
            }`}
          >
            Next
          </a>
        </div>
      )}
    </div>
  );
}
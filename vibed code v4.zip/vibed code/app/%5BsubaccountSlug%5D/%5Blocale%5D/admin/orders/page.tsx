import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';
import { Database } from '@/types/database';

type OrderRow = Database['public']['Tables']['orders']['Row'];

interface OrdersPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    status?: string;
    paymentMethod?: string;
    search?: string;
    page?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Fulfillment & Orders',
  };
}

const STATUS_FILTERS = [
  'ALL',
  'PENDING',
  'CONFIRMED',
  'DISPATCHED',
  'DELIVERED',
  'CANCELLED',
  'RETURNED',
] as const;

export default async function OrdersPage({
  params,
  searchParams,
}: OrdersPageProps) {
  const { subaccountSlug, locale } = await params;
  const { status, paymentMethod, search, page: pageQuery } = await searchParams;

  // 1. Resolve Subaccount Context & Check RBAC
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'orders:read');

  // 2. Build Filtered Query
  const supabase = await createServerClient();
  const page = Math.max(1, parseInt(pageQuery || '1', 10));
  const pageSize = 25;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase
    .from('orders')
    .select(
      `
      *,
      contacts (
        id,
        first_name,
        last_name,
        phone,
        email,
        city
      )
    `,
      { count: 'exact' }
    )
    .eq('subaccount_id', tenant.id);

  if (status && status !== 'ALL') {
    query = query.eq('status', status as OrderRow['status']);
  }

  if (paymentMethod && paymentMethod !== 'ALL') {
    query = query.eq('payment_method', paymentMethod as OrderRow['payment_method']);
  }

  if (search) {
    const term = `%${search.trim()}%`;
    query = query.or(`order_number.ilike.${term},waybill_number.ilike.${term}`);
  }

  const { data: ordersData, count, error } = await query
    .order('created_at', { ascending: false })
    .range(from, to);

  if (error) {
    console.error('Orders query failure:', error.message);
  }

  const orders = ordersData || [];
  const totalCount = count || 0;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(val);

  return (
    <div className="space-y-6">
      {/* Orders Directory Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Fulfillment & Orders
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-muted font-mono font-medium text-muted-foreground">
              {totalCount} total
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Manage customer deliveries, cash-on-delivery confirmations, and thermal waybills.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href={`/${subaccountSlug}/${locale}/admin/print/waybills`}
            className="px-3.5 py-1.5 bg-card border border-border text-foreground hover:bg-muted text-xs font-semibold rounded-md transition-colors shadow-sm flex items-center gap-1.5"
          >
            <span>🖨️</span> Batch Print Labels
          </Link>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-border">
        {STATUS_FILTERS.map((s) => {
          const isActive = (status || 'ALL') === s;
          const href = s === 'ALL'
            ? `/${subaccountSlug}/${locale}/admin/orders`
            : `/${subaccountSlug}/${locale}/admin/orders?status=${s}`;

          return (
            <Link
              key={s}
              href={href}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              {s}
            </Link>
          );
        })}
      </div>

      {/* Orders Table Container */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-border bg-muted/30 uppercase font-semibold text-muted-foreground tracking-wider">
              <th className="py-3 px-4">Order</th>
              <th className="py-3 px-4">Customer & City</th>
              <th className="py-3 px-4">Payment</th>
              <th className="py-3 px-4">Delivery Status</th>
              <th className="py-3 px-4">Waybill</th>
              <th className="py-3 px-4 text-right">Amount</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {orders.length > 0 ? (
              orders.map((order) => {
                const customer = order.contacts as any;
                const shipping = order.shipping_address as Record<string, any> | null;
                const fullName =
                  customer
                    ? `${customer.first_name ?? ''} ${customer.last_name ?? ''}`.trim()
                    : shipping
                    ? `${shipping.firstName ?? ''} ${shipping.lastName ?? ''}`.trim()
                    : 'Customer';

                const phone = customer?.phone || shipping?.phone || null;
                const city = customer?.city || shipping?.city || '—';
                const isCod = order.payment_method === 'COD';

                return (
                  <tr key={order.id} className="hover:bg-muted/30 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-foreground">
                      <Link
                        href={`/${subaccountSlug}/${locale}/admin/orders/${order.id}`}
                        className="hover:underline text-primary"
                      >
                        #{order.order_number}
                      </Link>
                      <span className="block text-[10px] font-sans font-normal text-muted-foreground mt-0.5">
                        {new Date(order.created_at).toLocaleDateString()}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-semibold text-foreground">{fullName}</p>
                      <div className="flex items-center gap-2 mt-0.5 text-muted-foreground">
                        <span className="font-mono text-[11px]">{phone || 'No phone'}</span>
                        {phone && (
                          <a
                            href={`https://wa.me/${phone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] text-emerald-600 hover:underline font-bold"
                          >
                            WA
                          </a>
                        )}
                        <span>•</span>
                        <span>{city}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          isCod
                            ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                            : 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                        }`}
                      >
                        {isCod ? 'Cash on Delivery' : order.payment_method}
                      </span>
                      <span className="block text-[10px] text-muted-foreground font-mono mt-0.5 uppercase">
                        {order.payment_status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          order.status === 'CONFIRMED' || order.status === 'DELIVERED'
                            ? 'bg-emerald-500/10 text-emerald-600'
                            : order.status === 'PENDING'
                            ? 'bg-amber-500/10 text-amber-600'
                            : order.status === 'DISPATCHED'
                            ? 'bg-blue-500/10 text-blue-600'
                            : 'bg-destructive/10 text-destructive'
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono text-[11px] text-muted-foreground">
                      {order.waybill_number || <span className="opacity-50">—</span>}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-foreground">
                      {formatPrice(order.total_amount)}
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <Link
                        href={`/${subaccountSlug}/${locale}/admin/orders/${order.id}`}
                        className="text-primary hover:underline font-medium"
                      >
                        Inspect
                      </Link>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={7} className="py-12 text-center text-muted-foreground text-xs italic">
                  No orders found matching the filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-xs pt-2">
          <Link
            href={`/${subaccountSlug}/${locale}/admin/orders?page=${page - 1}${
              status ? `&status=${status}` : ''
            }`}
            className={`px-3 py-1.5 bg-card border border-border rounded-md ${
              page <= 1 ? 'pointer-events-none opacity-40' : 'hover:bg-muted'
            }`}
          >
            Previous
          </Link>
          <span className="text-muted-foreground font-mono">
            Page {page} of {totalPages}
          </span>
          <Link
            href={`/${subaccountSlug}/${locale}/admin/orders?page=${page + 1}${
              status ? `&status=${status}` : ''
            }`}
            className={`px-3 py-1.5 bg-card border border-border rounded-md ${
              page >= totalPages ? 'pointer-events-none opacity-40' : 'hover:bg-muted'
            }`}
          >
            Next
          </Link>
        </div>
      )}
    </div>
  );
}
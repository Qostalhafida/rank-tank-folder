import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { updateOrderStatus } from '@/server/actions/orders';
import { createServerClient } from '@/lib/supabase/server';
import { Database, MultilingualText } from '@/types/database';

type OrderStatus = Database['public']['Tables']['orders']['Row']['status'];

interface OrderInspectorPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    orderId: string;
  }>;
}

export async function generateMetadata({ params }: OrderInspectorPageProps) {
  const { orderId } = await params;
  return {
    title: `Order Inspector #${orderId.slice(0, 8)}`,
  };
}

const ALL_STATUSES: OrderStatus[] = [
  'PENDING',
  'CONFIRMED',
  'DISPATCHED',
  'DELIVERED',
  'CANCELLED',
  'RETURNED',
];

export default async function OrderInspectorPage({ params }: OrderInspectorPageProps) {
  const { subaccountSlug, locale, orderId } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'orders:read');

  // 2. Fetch Order and Attached Line Items
  const supabase = await createServerClient();
  const { data: order, error } = await supabase
    .from('orders')
    .select(`
      *,
      contacts (
        id,
        first_name,
        last_name,
        phone,
        email,
        lifetime_value,
        orders_count
      ),
      order_items (*)
    `)
    .eq('id', orderId)
    .eq('subaccount_id', tenant.id)
    .single();

  if (error || !order) notFound();

  const customer = order.contacts as any;
  const shipping = order.shipping_address as Record<string, any> | null;
  const orderItems = (order.order_items as any[]) || [];
  const isCod = order.payment_method === 'COD';

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
    }).format(val);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-4 border-b border-border">
        <div>
          <Link
            href={`/${subaccountSlug}/${locale}/admin/orders`}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 mb-1"
          >
            ← Back to Orders
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold font-mono text-foreground">
              #{order.order_number}
            </h1>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                order.status === 'CONFIRMED' || order.status === 'DELIVERED'
                  ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                  : order.status === 'PENDING'
                  ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              {order.status}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href={`/${subaccountSlug}/${locale}/admin/print/waybills?orderId=${order.id}`}
            target="_blank"
            className="px-3.5 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm flex items-center gap-1.5"
          >
            <span>🖨️</span> Print A6 Thermal Label
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Order Line Items & Financial Summary */}
        <div className="lg:col-span-8 space-y-6">
          {/* Order Items Table */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Package Line Items ({orderItems.length})
            </h2>

            <div className="divide-y divide-border/60">
              {orderItems.map((item) => {
                const titleText =
                  typeof item.product_title === 'string'
                    ? item.product_title
                    : (item.product_title as MultilingualText)?.[locale] ||
                      (item.product_title as MultilingualText)?.en ||
                      'Product Item';

                return (
                  <div
                    key={item.id}
                    className="py-3 flex items-center justify-between text-xs"
                  >
                    <div className="space-y-0.5">
                      <p className="font-semibold text-foreground">{titleText}</p>
                      <p className="text-[11px] text-muted-foreground font-mono">
                        {formatPrice(item.unit_price)} × {item.quantity}
                      </p>
                    </div>
                    <span className="font-mono font-bold text-foreground">
                      {formatPrice(item.total_price)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Financial Breakdown */}
            <div className="pt-3 border-t border-border space-y-1.5 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono text-foreground font-medium">
                  {formatPrice(order.subtotal)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Fee</span>
                <span className="font-mono text-foreground">
                  {order.shipping_cost > 0 ? formatPrice(order.shipping_cost) : 'Free'}
                </span>
              </div>
              {order.discount_amount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>Discount Applied</span>
                  <span className="font-mono">-{formatPrice(order.discount_amount)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-bold text-foreground pt-2 border-t border-border">
                <span>Total Amount {isCod ? '(To Collect)' : ''}</span>
                <span className="font-mono text-primary text-base">
                  {formatPrice(order.total_amount)}
                </span>
              </div>
            </div>
          </div>

          {/* Fulfillment Status Modifier Form */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <h2 className="text-xs font-bold text-foreground uppercase tracking-wider">
              Update Status & Waybill
            </h2>

            <form
              action={async (formData: FormData) => {
                'use server';
                const nextStatus = formData.get('status') as OrderStatus;
                const nextWaybill = formData.get('waybillNumber') as string;
                await updateOrderStatus(tenant.id, order.id, nextStatus, nextWaybill || null);
              }}
              className="space-y-4 text-xs"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-foreground mb-1">
                    Delivery Status
                  </label>
                  <select
                    name="status"
                    defaultValue={order.status}
                    className="w-full px-3 py-2 bg-background border border-input rounded-md text-xs font-medium focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    {ALL_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-foreground mb-1">
                    Courier Waybill Number
                  </label>
                  <input
                    type="text"
                    name="waybillNumber"
                    defaultValue={order.waybill_number || ''}
                    placeholder="e.g. WB-9481048"
                    className="w-full px-3 py-2 bg-background border border-input rounded-md text-xs font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-4 py-2 bg-primary text-primary-foreground font-semibold rounded-md hover:bg-primary/90 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Column: Customer Profile & Destination */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4 text-xs">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider border-b border-border pb-2">
              Customer Information
            </h2>

            <div className="space-y-2">
              <div>
                <span className="text-muted-foreground block text-[11px]">Full Name</span>
                <p className="font-bold text-foreground text-sm">
                  {shipping?.firstName || customer?.first_name || 'Customer'}{' '}
                  {shipping?.lastName || customer?.last_name || ''}
                </p>
              </div>

              <div>
                <span className="text-muted-foreground block text-[11px]">Phone Number</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="font-mono font-medium text-foreground">
                    {shipping?.phone || customer?.phone || 'No phone'}
                  </span>
                  {(shipping?.phone || customer?.phone) && (
                    <a
                      href={`https://wa.me/${(shipping?.phone || customer?.phone).replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-bold hover:bg-emerald-700"
                    >
                      WhatsApp
                    </a>
                  )}
                </div>
              </div>

              <div>
                <span className="text-muted-foreground block text-[11px]">Email Address</span>
                <p className="font-medium text-foreground">{customer?.email || '—'}</p>
              </div>
            </div>

            <div className="pt-3 border-t border-border space-y-1">
              <span className="text-muted-foreground block text-[11px]">Delivery Address</span>
              <p className="font-medium text-foreground leading-relaxed">
                {shipping?.addressLine1 || 'No address line'}
                {shipping?.addressLine2 ? `, ${shipping.addressLine2}` : ''}
              </p>
              <p className="text-muted-foreground">
                {[shipping?.city, shipping?.province, shipping?.country].filter(Boolean).join(', ')}
              </p>
            </div>

            {customer?.id && (
              <div className="pt-3 border-t border-border flex justify-between items-center">
                <span className="text-muted-foreground">Customer LTV:</span>
                <span className="font-mono font-bold text-foreground">
                  {formatPrice(customer.lifetime_value || 0)}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';
import {
  PrintableWaybillCard,
  WaybillOrderData,
} from '@/components/admin/PrintableWaybillCard';
import { MultilingualText } from '@/types/database';

interface PrintWaybillsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    orderId?: string;
    orderIds?: string;
    status?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Print A6 Thermal Shipping Labels',
  };
}

export default async function PrintWaybillsPage({
  params,
  searchParams,
}: PrintWaybillsPageProps) {
  const { subaccountSlug, locale } = await params;
  const { orderId, orderIds, status } = await searchParams;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'orders:print_waybills');

  const supabase = await createServerClient();

  // 2. Build Query for Targeted Orders
  let query = supabase
    .from('orders')
    .select(`
      *,
      contacts (
        first_name,
        last_name,
        phone,
        email
      ),
      order_items (
        quantity,
        unit_price,
        product_title
      )
    `)
    .eq('subaccount_id', tenant.id);

  if (orderId) {
    query = query.eq('id', orderId);
  } else if (orderIds) {
    const idsList = orderIds.split(',').map((id) => id.trim()).filter(Boolean);
    query = query.in('id', idsList);
  } else if (status) {
    query = query.eq('status', status as any);
  } else {
    // Default to confirmed orders ready for dispatch
    query = query.in('status', ['CONFIRMED', 'PENDING']).limit(30);
  }

  const { data: rawOrders, error } = await query.order('created_at', { ascending: false });

  if (error) {
    console.error('Failed to query orders for printing:', error.message);
  }

  const ordersList = rawOrders || [];

  // 3. Format Orders for Thermal Printing Layout
  const printableOrders: WaybillOrderData[] = ordersList.map((order) => {
    const contact = order.contacts as any;
    const shipping = order.shipping_address as Record<string, any> | null;

    const customerName =
      `${shipping?.firstName || contact?.first_name || 'Customer'} ${
        shipping?.lastName || contact?.last_name || ''
      }`.trim();

    const customerPhone = shipping?.phone || contact?.phone || 'No phone recorded';

    const items = (order.order_items || []).map((item: any) => {
      const title =
        typeof item.product_title === 'string'
          ? item.product_title
          : (item.product_title as MultilingualText)?.[locale] ||
            (item.product_title as MultilingualText)?.en ||
            'Package Item';

      return {
        title,
        quantity: item.quantity,
        unitPrice: item.unit_price,
      };
    });

    return {
      orderNumber: order.order_number,
      waybillNumber:
        order.waybill_number || `WB-${order.order_number.replace(/[^0-9]/g, '') || order.id.slice(0, 8)}`,
      createdAt: order.created_at,
      totalAmount: order.total_amount,
      currency: tenant.currency || 'USD',
      paymentMethod: order.payment_method,
      customer: {
        name: customerName,
        phone: customerPhone,
        addressLine1: shipping?.addressLine1 || 'Customer Address',
        addressLine2: shipping?.addressLine2 || undefined,
        city: shipping?.city || 'City',
        province: shipping?.province || undefined,
        country: shipping?.country || undefined,
      },
      items,
      storeName: tenant.name,
    };
  });

  return (
    <div className="space-y-6">
      {/* Non-Printable Action Bar (Hidden during thermal printing) */}
      <div className="print:hidden bg-card border border-border p-4 rounded-xl shadow-sm flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div className="space-y-0.5">
          <Link
            href={`/${subaccountSlug}/${locale}/admin/orders`}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            ← Back to Fulfillment Center
          </Link>
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold text-foreground">
              Thermal Label Printing Center
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-mono font-bold">
              {printableOrders.length} labels ready
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {printableOrders.length > 0 && (
            <button
              type="button"
              id="print-trigger-button"
              className="px-4 py-2 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <span>🖨️ Send to Thermal Printer (A6)</span>
            </button>
          )}
        </div>
      </div>

      {/* Printable Labels Canvas */}
      {printableOrders.length > 0 ? (
        <div className="flex flex-wrap gap-8 justify-center print:block print:p-0">
          {printableOrders.map((order, idx) => (
            <div key={idx} className="print:break-after-page">
              <PrintableWaybillCard order={order} />
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 border border-dashed border-border rounded-xl text-center text-xs text-muted-foreground bg-muted/10">
          No orders selected or matched for printing waybills.
        </div>
      )}

      {/* Thermal Print Trigger Script */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
            document.getElementById('print-trigger-button')?.addEventListener('click', function() {
              window.print();
            });
          `,
        }}
      />
    </div>
  );
}
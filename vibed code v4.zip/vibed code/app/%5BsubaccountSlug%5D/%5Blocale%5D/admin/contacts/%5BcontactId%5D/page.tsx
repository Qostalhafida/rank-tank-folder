import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';
import { updateContact } from '@/server/actions/contacts';
import { TagBadgeList } from '@/components/crm/contacts/TagBadgeList';

interface ContactProfilePageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    contactId: string;
  }>;
}

export async function generateMetadata({ params }: ContactProfilePageProps) {
  const { contactId } = await params;
  return {
    title: `360° Contact Profile #${contactId.slice(0, 8)}`,
  };
}

export default async function ContactProfilePage({ params }: ContactProfilePageProps) {
  const { subaccountSlug, locale, contactId } = await params;

  // 1. Resolve Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'contacts:read');

  const supabase = await createServerClient();

  // 2. Fetch Contact 360 Dossier Concurrently
  const [contactRes, ordersRes, opportunitiesRes, appointmentsRes] =
    await Promise.all([
      // Contact with attached tags
      supabase
        .from('contacts')
        .select(`
          *,
          contact_tags (
            tags (
              id,
              name,
              color
            )
          )
        `)
        .eq('id', contactId)
        .eq('subaccount_id', tenant.id)
        .single(),

      // Associated Orders
      supabase
        .from('orders')
        .select('id, order_number, total_amount, status, payment_method, created_at')
        .eq('contact_id', contactId)
        .eq('subaccount_id', tenant.id)
        .order('created_at', { ascending: false }),

      // Associated Deals / Opportunities
      supabase
        .from('opportunities')
        .select(`
          id,
          title,
          value,
          currency,
          status,
          created_at,
          pipeline_stages (name, color)
        `)
        .eq('contact_id', contactId)
        .eq('subaccount_id', tenant.id)
        .order('created_at', { ascending: false }),

      // Associated Calendar Appointments
      supabase
        .from('appointments')
        .select(`
          id,
          start_time,
          end_time,
          status,
          notes,
          calendars (name)
        `)
        .eq('contact_id', contactId)
        .eq('subaccount_id', tenant.id)
        .order('start_time', { ascending: false }),
    ]);

  if (contactRes.error || !contactRes.data) notFound();

  const contact = contactRes.data;
  const tags = (contact.contact_tags || []).map((ct: any) => ct.tags).filter(Boolean);
  const orders = ordersRes.data || [];
  const opportunities = opportunitiesRes.data || [];
  const appointments = appointmentsRes.data || [];

  const fullName =
    `${contact.first_name ?? ''} ${contact.last_name ?? ''}`.trim() || 'Customer';
  const averageOrderValue =
    contact.orders_count > 0 ? contact.lifetime_value / contact.orders_count : 0;

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(val);

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-4 border-b border-border">
        <div>
          <Link
            href={`/${subaccountSlug}/${locale}/admin/contacts`}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 mb-1"
          >
            ← Back to Contacts
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center text-sm">
              {fullName.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">{fullName}</h1>
              <p className="text-xs text-muted-foreground font-mono">
                CRM ID: {contact.id}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {contact.phone && (
            <a
              href={`https://wa.me/${contact.phone.replace(/[^0-9]/g, '')}`}
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-1.5 bg-emerald-600 text-white rounded-md text-xs font-semibold hover:bg-emerald-700 transition-colors shadow-sm flex items-center gap-1.5"
            >
              <span>💬</span> WhatsApp Customer
            </a>
          )}
        </div>
      </div>

      {/* KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Lifetime Value (LTV)
          </span>
          <span className="text-2xl font-black font-mono text-primary block">
            {formatPrice(contact.lifetime_value)}
          </span>
        </div>

        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Orders Completed
          </span>
          <span className="text-2xl font-black font-mono text-foreground block">
            {contact.orders_count}
          </span>
        </div>

        <div className="p-5 bg-card border border-border rounded-xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Average Order Value (AOV)
          </span>
          <span className="text-2xl font-black font-mono text-foreground block">
            {formatPrice(averageOrderValue)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Editable Contact Dossier */}
        <div className="lg:col-span-5 space-y-6">
          {/* Tags Card */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Segment Tags
            </h3>
            <TagBadgeList tags={tags} size="md" />
          </div>

          {/* Contact Details Form */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider border-b border-border pb-2">
              Customer Profile Details
            </h3>

            <form
              action={async (formData: FormData) => {
                'use server';
                await requirePermission(tenant.id, 'contacts:write');
                const firstName = formData.get('firstName') as string;
                const lastName = formData.get('lastName') as string;
                const email = (formData.get('email') as string) || null;
                const phone = (formData.get('phone') as string) || null;
                const addressLine1 = (formData.get('addressLine1') as string) || null;
                const city = (formData.get('city') as string) || null;

                await updateContact(tenant.id, contact.id, {
                  first_name: firstName,
                  last_name: lastName,
                  email,
                  phone,
                  address_line1: addressLine1,
                  city,
                });

                revalidatePath(`/[subaccountSlug]/admin/contacts/${contact.id}`, 'page');
              }}
              className="space-y-3 text-xs"
            >
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-foreground mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    defaultValue={contact.first_name || ''}
                    className="w-full px-3 py-1.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-foreground mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    defaultValue={contact.last_name || ''}
                    className="w-full px-3 py-1.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-foreground mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  name="phone"
                  defaultValue={contact.phone || ''}
                  className="w-full px-3 py-1.5 bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-foreground mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  defaultValue={contact.email || ''}
                  className="w-full px-3 py-1.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-foreground mb-1">
                  Street Address
                </label>
                <input
                  type="text"
                  name="addressLine1"
                  defaultValue={contact.address_line1 || ''}
                  className="w-full px-3 py-1.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-foreground mb-1">
                  City
                </label>
                <input
                  type="text"
                  name="city"
                  defaultValue={contact.city || ''}
                  className="w-full px-3 py-1.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Column: Timeline & Cross-Entity History */}
        <div className="lg:col-span-7 space-y-6">
          {/* Order History */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider flex items-center justify-between border-b border-border pb-2">
              <span>Order History ({orders.length})</span>
            </h3>

            <div className="divide-y divide-border/60">
              {orders.length > 0 ? (
                orders.map((o) => (
                  <div key={o.id} className="py-2.5 flex justify-between items-center text-xs">
                    <div>
                      <Link
                        href={`/${subaccountSlug}/${locale}/admin/orders/${o.id}`}
                        className="font-mono font-bold text-primary hover:underline"
                      >
                        #{o.order_number}
                      </Link>
                      <span className="block text-[11px] text-muted-foreground">
                        {new Date(o.created_at).toLocaleDateString()} • {o.payment_method}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-bold text-foreground block">
                        {formatPrice(o.total_amount)}
                      </span>
                      <span className="text-[10px] font-bold uppercase text-muted-foreground">
                        {o.status}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-muted-foreground py-4 italic text-center">
                  No orders placed by this contact.
                </p>
              )}
            </div>
          </div>

          {/* Deals & Opportunities */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider border-b border-border pb-2">
              Pipeline Deals ({opportunities.length})
            </h3>

            <div className="divide-y divide-border/60">
              {opportunities.length > 0 ? (
                opportunities.map((opp) => (
                  <div key={opp.id} className="py-2.5 flex justify-between items-center text-xs">
                    <div>
                      <p className="font-semibold text-foreground">{opp.title}</p>
                      <span
                        className="inline-block text-[10px] font-bold uppercase px-2 py-0.5 rounded-full mt-0.5 border"
                        style={{
                          borderColor: `${(opp.pipeline_stages as any)?.color}40`,
                          backgroundColor: `${(opp.pipeline_stages as any)?.color}15`,
                          color: (opp.pipeline_stages as any)?.color || '#3b82f6',
                        }}
                      >
                        {(opp.pipeline_stages as any)?.name || 'Stage'}
                      </span>
                    </div>

                    <div className="text-right font-mono font-bold text-foreground">
                      {formatPrice(opp.value)}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-muted-foreground py-4 italic text-center">
                  No pipeline deals associated with this contact.
                </p>
              )}
            </div>
          </div>

          {/* Appointments */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider border-b border-border pb-2">
              Booked Appointments ({appointments.length})
            </h3>

            <div className="divide-y divide-border/60">
              {appointments.length > 0 ? (
                appointments.map((appt) => (
                  <div key={appt.id} className="py-2.5 flex justify-between items-center text-xs">
                    <div>
                      <p className="font-semibold text-foreground">
                        {(appt.calendars as any)?.name || 'Consultation'}
                      </p>
                      <p className="text-[11px] text-muted-foreground font-mono">
                        {new Date(appt.start_time).toLocaleString()}
                      </p>
                    </div>

                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600">
                      {appt.status}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-muted-foreground py-4 italic text-center">
                  No appointments booked.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
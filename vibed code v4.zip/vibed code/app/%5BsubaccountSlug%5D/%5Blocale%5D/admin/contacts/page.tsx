import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createContact, getContacts } from '@/server/actions/contacts';
import { ContactTable } from '@/components/crm/contacts/ContactTable';
import { ContactFilterParams } from '@/types/crm';

interface ContactsDirectoryPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    search?: string;
    page?: string;
    minLtv?: string;
    maxLtv?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }>;
}

export async function generateMetadata() {
  return {
    title: 'CRM Contacts Directory',
  };
}

export default async function ContactsDirectoryPage({
  params,
  searchParams,
}: ContactsDirectoryPageProps) {
  const { subaccountSlug, locale } = await params;
  const searchValues = await searchParams;

  // 1. Resolve Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'contacts:read');

  // 2. Fetch Initial Contacts with Filters
  const filterParams: ContactFilterParams = {
    search: searchValues.search,
    page: searchValues.page ? parseInt(searchValues.page, 10) : 1,
    pageSize: 20,
    minLtv: searchValues.minLtv ? parseFloat(searchValues.minLtv) : undefined,
    maxLtv: searchValues.maxLtv ? parseFloat(searchValues.maxLtv) : undefined,
    sortBy: (searchValues.sortBy as any) || 'lifetime_value',
    sortOrder: searchValues.sortOrder || 'desc',
  };

  const contactsRes = await getContacts(tenant.id, filterParams);
  const contacts = contactsRes.data?.contacts || [];
  const totalCount = contactsRes.data?.totalCount || 0;

  return (
    <div className="space-y-6">
      {/* Directory Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">👥</span>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              CRM Contacts Directory
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-primary/10 text-primary font-mono font-medium">
              {totalCount} Total Audience
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Search customer records, segment by tag affinities, and track lifetime value (LTV).
          </p>
        </div>

        {/* Quick Contact Creator Form */}
        <form
          action={async (formData: FormData) => {
            'use server';
            await requirePermission(tenant.id, 'contacts:write');
            const firstName = (formData.get('firstName') as string)?.trim();
            const lastName = (formData.get('lastName') as string)?.trim();
            const phone = (formData.get('phone') as string)?.trim();
            const email = (formData.get('email') as string)?.trim() || undefined;
            const city = (formData.get('city') as string)?.trim() || undefined;

            if (phone || email) {
              await createContact(tenant.id, {
                first_name: firstName || null,
                last_name: lastName || null,
                phone: phone || null,
                email: email || null,
                city: city || null,
              });
              revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');
            }
          }}
          className="flex flex-wrap gap-2 self-start sm:self-auto text-xs"
        >
          <input
            type="text"
            name="firstName"
            required
            placeholder="First Name..."
            className="px-3 py-1.5 bg-card border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs w-28"
          />
          <input
            type="text"
            name="lastName"
            placeholder="Last Name..."
            className="px-3 py-1.5 bg-card border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs w-28"
          />
          <input
            type="tel"
            name="phone"
            required
            placeholder="Phone Number..."
            className="px-3 py-1.5 bg-card border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs w-32"
          />
          <button
            type="submit"
            className="px-3.5 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm shrink-0"
          >
            + Add Contact
          </button>
        </form>
      </div>

      {/* Searchable Contact Table with Live LTV Badges */}
      <ContactTable
        initialContacts={contacts}
        totalCount={totalCount}
        subaccountId={tenant.id}
        subaccountSlug={subaccountSlug}
        locale={locale}
      />
    </div>
  );
}
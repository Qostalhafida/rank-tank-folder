import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { getPipelineWithStages } from '@/server/actions/pipelines';
import { createServerClient } from '@/lib/supabase/server';
import { PipelineStage } from '@/types/crm';

interface PipelineSettingsPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    pipelineId?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Pipeline Stage Builder & Automations',
  };
}

const STAGE_PRESET_COLORS = [
  '#3b82f6', // Blue
  '#f59e0b', // Amber
  '#8b5cf6', // Violet
  '#10b981', // Emerald
  '#ef4444', // Red
  '#06b6d4', // Cyan
  '#ec4899', // Pink
  '#64748b', // Slate
];

export default async function PipelineSettingsPage({
  params,
  searchParams,
}: PipelineSettingsPageProps) {
  const { subaccountSlug, locale } = await params;
  const { pipelineId } = await searchParams;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'pipelines:write');

  // 2. Fetch Pipeline with its Ordered Stages
  const pipelineRes = await getPipelineWithStages(tenant.id, pipelineId);
  if (!pipelineRes.success || !pipelineRes.data) {
    notFound();
  }

  const pipeline = pipelineRes.data;
  const stages: PipelineStage[] = pipeline.stages || [];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header & Back Navigation */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-4 border-b border-border">
        <div>
          <Link
            href={`/${subaccountSlug}/${locale}/admin/pipelines`}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 mb-1"
          >
            ← Back to Kanban Pipeline
          </Link>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Configure Pipeline Stages: {pipeline.name}
            </h1>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Add, reorder, and color-code pipeline stages for optimistic drag-and-drop workflow tracking.
          </p>
        </div>
      </div>

      {/* Add Stage Form */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-sm font-bold text-foreground">Add New Stage</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            New stages will appear as columns on your team&apos;s Realtime Kanban board.
          </p>
        </div>

        <form
          action={async (formData: FormData) => {
            'use server';
            await requirePermission(tenant.id, 'pipelines:write');
            const client = await createServerClient();

            const name = (formData.get('name') as string)?.trim();
            const color = (formData.get('color') as string) || '#3b82f6';

            if (name) {
              const nextPosition = stages.length;

              await client.from('pipeline_stages').insert({
                pipeline_id: pipeline.id,
                subaccount_id: tenant.id,
                name,
                color,
                position: nextPosition,
              });

              revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
              revalidatePath(`/[subaccountSlug]/admin/pipelines/settings`, 'page');
            }
          }}
          className="space-y-3 text-xs"
        >
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              name="name"
              required
              placeholder="e.g. Negotiation / Proposal Sent"
              className="flex-1 px-3.5 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs"
            />

            <button
              type="submit"
              className="px-4 py-2 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm shrink-0"
            >
              + Add Column
            </button>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <span className="text-[11px] text-muted-foreground">Color Pill:</span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {STAGE_PRESET_COLORS.map((col, idx) => (
                <label key={col} className="cursor-pointer">
                  <input
                    type="radio"
                    name="color"
                    value={col}
                    defaultChecked={idx === 0}
                    className="sr-only peer"
                  />
                  <span
                    className="w-5 h-5 rounded-full block border-2 border-transparent peer-checked:ring-2 peer-checked:ring-primary peer-checked:ring-offset-2 transition-transform hover:scale-105"
                    style={{ backgroundColor: col }}
                  />
                </label>
              ))}
            </div>
          </div>
        </form>
      </div>

      {/* Ordered Stages List */}
      <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
          Active Board Columns ({stages.length})
        </h2>

        <div className="space-y-2">
          {stages.length > 0 ? (
            stages.map((stage, idx) => (
              <div
                key={stage.id}
                className="p-3 bg-background border border-border rounded-lg flex flex-col sm:flex-row justify-between sm:items-center gap-3 text-xs shadow-sm hover:border-primary/40 transition-colors"
              >
                {/* Column Meta */}
                <div className="flex items-center gap-3 min-w-0">
                  <span className="w-5 h-5 rounded bg-muted text-muted-foreground flex items-center justify-center font-mono font-bold text-[10px]">
                    {idx + 1}
                  </span>

                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: stage.color }}
                  />

                  <div>
                    <h3 className="font-bold text-foreground text-xs">{stage.name}</h3>
                    <p className="text-[10px] text-muted-foreground font-mono">
                      {stage.opportunities_count ?? 0} active deals • Total Value: $
                      {(stage.total_value ?? 0).toLocaleString()}
                    </p>
                  </div>
                </div>

                {/* Stage Position & Delete Actions */}
                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {/* Move Up */}
                  {idx > 0 && (
                    <form
                      action={async () => {
                        'use server';
                        await requirePermission(tenant.id, 'pipelines:write');
                        const client = await createServerClient();
                        const prevStage = stages[idx - 1];

                        await client
                          .from('pipeline_stages')
                          .update({ position: idx })
                          .eq('id', prevStage.id);

                        await client
                          .from('pipeline_stages')
                          .update({ position: idx - 1 })
                          .eq('id', stage.id);

                        revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
                        revalidatePath(`/[subaccountSlug]/admin/pipelines/settings`, 'page');
                      }}
                    >
                      <button
                        type="submit"
                        className="px-2 py-1 bg-muted hover:bg-muted/80 rounded text-[11px] font-mono text-foreground"
                        title="Move Left/Up"
                      >
                        ↑
                      </button>
                    </form>
                  )}

                  {/* Move Down */}
                  {idx < stages.length - 1 && (
                    <form
                      action={async () => {
                        'use server';
                        await requirePermission(tenant.id, 'pipelines:write');
                        const client = await createServerClient();
                        const nextStage = stages[idx + 1];

                        await client
                          .from('pipeline_stages')
                          .update({ position: idx })
                          .eq('id', nextStage.id);

                        await client
                          .from('pipeline_stages')
                          .update({ position: idx + 1 })
                          .eq('id', stage.id);

                        revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
                        revalidatePath(`/[subaccountSlug]/admin/pipelines/settings`, 'page');
                      }}
                    >
                      <button
                        type="submit"
                        className="px-2 py-1 bg-muted hover:bg-muted/80 rounded text-[11px] font-mono text-foreground"
                        title="Move Right/Down"
                      >
                        ↓
                      </button>
                    </form>
                  )}

                  {/* Delete Stage */}
                  <form
                    action={async () => {
                      'use server';
                      await requirePermission(tenant.id, 'pipelines:delete');
                      const client = await createServerClient();

                      await client
                        .from('pipeline_stages')
                        .delete()
                        .eq('id', stage.id)
                        .eq('subaccount_id', tenant.id);

                      revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
                      revalidatePath(`/[subaccountSlug]/admin/pipelines/settings`, 'page');
                    }}
                  >
                    <button
                      type="submit"
                      disabled={(stage.opportunities_count ?? 0) > 0}
                      className="px-2.5 py-1 text-destructive hover:underline text-[11px] disabled:opacity-40 disabled:cursor-not-allowed"
                      title={
                        (stage.opportunities_count ?? 0) > 0
                          ? 'Cannot delete stage containing active opportunities'
                          : 'Delete stage'
                      }
                    >
                      Delete
                    </button>
                  </form>
                </div>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-muted-foreground italic">
              No stages defined. Add your first pipeline column above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
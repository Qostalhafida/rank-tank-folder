import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { getSessionContext } from '@/lib/auth/rbac';
import { getPipelineWithStages } from '@/server/actions/pipelines';
import { KanbanBoard } from '@/components/crm/pipelines/KanbanBoard';

interface PipelinesPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    pipelineId?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Deals & Opportunities Pipeline',
  };
}

export default async function PipelinesPage({
  params,
  searchParams,
}: PipelinesPageProps) {
  const { subaccountSlug, locale } = await params;
  const { pipelineId } = await searchParams;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Validate RBAC Session
  const session = await getSessionContext(tenant.id);

  // 3. Fetch Pipeline with Embedded Stages and Deals
  const pipelineRes = await getPipelineWithStages(tenant.id, pipelineId);
  if (!pipelineRes.success || !pipelineRes.data) {
    return (
      <div className="p-8 text-center text-sm text-muted-foreground border border-dashed rounded-xl">
        No sales pipeline configured. Please visit settings to initialize stages.
      </div>
    );
  }

  const pipeline = pipelineRes.data;

  // Compute total pipeline value
  const totalPipelineValue = pipeline.stages.reduce(
    (acc, stage) => acc + (stage.total_value || 0),
    0
  );

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(val);

  return (
    <div className="flex flex-col h-[calc(100vh-100px)] space-y-4">
      {/* Pipeline Navigation Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              {pipeline.name}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-primary/10 text-primary font-mono font-semibold">
              {formatPrice(totalPipelineValue)}
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Realtime optimistic Kanban board with versioned race-condition guards.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href={`/${subaccountSlug}/${locale}/admin/pipelines/settings`}
            className="px-3 py-1.5 bg-card border border-border text-foreground hover:bg-muted text-xs font-medium rounded-md transition-colors shadow-sm"
          >
            ⚙️ Configure Stages
          </Link>
        </div>
      </div>

      {/* Concurrent Kanban Board */}
      <div className="flex-1 bg-card border border-border rounded-xl shadow-sm overflow-hidden flex flex-col min-h-0">
        <KanbanBoard
          initialPipeline={pipeline}
          subaccountId={tenant.id}
          currentUserId={session.userId}
          currentUserName={session.email.split('@')[0]}
        />
      </div>
    </div>
  );
}
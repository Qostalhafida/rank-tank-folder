import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';
import { DigitalAsset, LicenseKey } from '@/types/digital';
import { Database, MultilingualText } from '@/types/database';

interface DigitalVaultAdminPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Digital Vault & License Key Pools',
  };
}

export default async function DigitalVaultAdminPage({ params }: DigitalVaultAdminPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'digital:upload');

  const supabase = await createServerClient();

  // 2. Fetch Digital Assets & License Keys
  const [assetsRes, keysRes, productsRes] = await Promise.all([
    supabase
      .from('digital_assets')
      .select('*, products(title)')
      .eq('subaccount_id', tenant.id)
      .order('created_at', { ascending: false }),

    supabase
      .from('license_keys')
      .select('*, products(title)')
      .eq('subaccount_id', tenant.id)
      .order('created_at', { ascending: false })
      .limit(50),

    supabase
      .from('products')
      .select('id, title, type')
      .eq('subaccount_id', tenant.id)
      .eq('type', 'DIGITAL')
      .eq('is_active', true),
  ]);

  const assets: (DigitalAsset & { products?: { title: MultilingualText } })[] =
    (assetsRes.data as any) || [];
  const keys: (LicenseKey & { products?: { title: MultilingualText } })[] =
    (keysRes.data as any) || [];
  const digitalProducts = productsRes.data || [];

  const availableKeysCount = keys.filter((k) => k.status === 'AVAILABLE').length;
  const assignedKeysCount = keys.filter((k) => k.status === 'ASSIGNED').length;

  const formatFileSize = (bytes: number) => {
    if (!bytes) return '0 KB';
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">💾</span>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Digital Assets & License Dispenser
            </h1>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Manage tokenized secure downloads, upload course deliverables, and configure license key pools.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-card border border-border rounded-xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Digital Files Protected
          </span>
          <span className="text-2xl font-bold font-mono text-foreground">{assets.length}</span>
        </div>

        <div className="p-4 bg-card border border-border rounded-xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Keys Available for Dispensing
          </span>
          <span className="text-2xl font-bold font-mono text-emerald-600">
            {availableKeysCount}
          </span>
        </div>

        <div className="p-4 bg-card border border-border rounded-xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
            Keys Dispensed to Buyers
          </span>
          <span className="text-2xl font-bold font-mono text-primary">
            {assignedKeysCount}
          </span>
        </div>
      </div>

      {/* Management Grid: Files on Left, Key Pool on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Register Digital Deliverables */}
        <div className="lg:col-span-7 bg-card border border-border rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider">
              Secure Private Files ({assets.length})
            </h3>
          </div>

          {/* Quick File Register Form */}
          <form
            action={async (formData: FormData) => {
              'use server';
              await requirePermission(tenant.id, 'digital:upload');
              const client = await createServerClient();

              const fileName = formData.get('fileName') as string;
              const storagePath = formData.get('storagePath') as string;
              const productId = formData.get('productId') as string;
              const downloadLimit = parseInt((formData.get('downloadLimit') as string) || '5', 10);

              if (fileName && storagePath && productId) {
                await client.from('digital_assets').insert({
                  subaccount_id: tenant.id,
                  product_id: productId,
                  asset_type: 'FILE',
                  file_name: fileName.trim(),
                  storage_path: storagePath.trim(),
                  file_size_bytes: 1048576, // 1MB default placeholder
                  mime_type: 'application/pdf',
                  download_limit: downloadLimit,
                });

                revalidatePath(`/[subaccountSlug]/admin/digital`, 'page');
              }
            }}
            className="p-3 bg-muted/30 border border-border rounded-lg space-y-3 text-xs"
          >
            <span className="font-semibold text-foreground block text-[11px]">
              Register New Secure Asset
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                name="fileName"
                required
                placeholder="e.g. Masterclass-Handbook.pdf"
                className="px-3 py-1.5 bg-background border border-input rounded-md focus:outline-none"
              />
              <input
                type="text"
                name="storagePath"
                required
                placeholder="Storage vault path..."
                className="px-3 py-1.5 bg-background border border-input rounded-md font-mono focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <select
                name="productId"
                required
                className="px-2.5 py-1.5 bg-background border border-input rounded-md font-medium focus:outline-none"
              >
                <option value="">Link to digital product...</option>
                {digitalProducts.map((p) => {
                  const title = (p.title as MultilingualText)?.[locale] || (p.title as MultilingualText)?.en || 'Item';
                  return (
                    <option key={p.id} value={p.id}>
                      {title}
                    </option>
                  );
                })}
              </select>

              <input
                type="number"
                name="downloadLimit"
                defaultValue={5}
                placeholder="Max downloads per buyer..."
                className="px-3 py-1.5 bg-background border border-input rounded-md font-mono focus:outline-none"
              />
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                className="px-3.5 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm"
              >
                + Register Deliverable
              </button>
            </div>
          </form>

          {/* Files List */}
          <div className="divide-y divide-border/60">
            {assets.length > 0 ? (
              assets.map((asset) => {
                const productTitle =
                  asset.products?.title?.[locale] ||
                  asset.products?.title?.en ||
                  'Digital Product';

                return (
                  <div
                    key={asset.id}
                    className="py-3 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-semibold text-foreground">{asset.file_name}</p>
                      <p className="text-[11px] text-muted-foreground font-mono">
                        {productTitle} • {formatFileSize(asset.file_size_bytes)} • Max{' '}
                        {asset.download_limit ?? '∞'} downloads
                      </p>
                    </div>

                    <form
                      action={async () => {
                        'use server';
                        await requirePermission(tenant.id, 'digital:upload');
                        const client = await createServerClient();
                        await client
                          .from('digital_assets')
                          .delete()
                          .eq('id', asset.id)
                          .eq('subaccount_id', tenant.id);
                        revalidatePath(`/[subaccountSlug]/admin/digital`, 'page');
                      }}
                    >
                      <button
                        type="submit"
                        className="text-[11px] text-destructive hover:underline"
                      >
                        Delete
                      </button>
                    </form>
                  </div>
                );
              })
            ) : (
              <div className="py-6 text-center text-xs text-muted-foreground italic">
                No digital assets registered in the vault yet.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: License Key Dispenser Pool */}
        <div className="lg:col-span-5 bg-card border border-border rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider">
              License Key Dispenser Pool
            </h3>
          </div>

          {/* Batch Import Keys Form */}
          <form
            action={async (formData: FormData) => {
              'use server';
              await requirePermission(tenant.id, 'digital:manage_keys');
              const client = await createServerClient();

              const rawKeys = (formData.get('keys') as string) || '';
              const productId = formData.get('productId') as string;

              if (rawKeys && productId) {
                const keyLines = rawKeys
                  .split('\n')
                  .map((k) => k.trim())
                  .filter(Boolean);

                const rows = keyLines.map((licenseKey) => ({
                  subaccount_id: tenant.id,
                  product_id: productId,
                  license_key: licenseKey,
                  status: 'AVAILABLE' as const,
                }));

                await client.from('license_keys').insert(rows);
                revalidatePath(`/[subaccountSlug]/admin/digital`, 'page');
              }
            }}
            className="p-3 bg-muted/30 border border-border rounded-lg space-y-3 text-xs"
          >
            <span className="font-semibold text-foreground block text-[11px]">
              Bulk Import License Keys
            </span>

            <select
              name="productId"
              required
              className="w-full px-2.5 py-1.5 bg-background border border-input rounded-md font-medium focus:outline-none"
            >
              <option value="">Select digital product...</option>
              {digitalProducts.map((p) => {
                const title = (p.title as MultilingualText)?.[locale] || (p.title as MultilingualText)?.en || 'Item';
                return (
                  <option key={p.id} value={p.id}>
                    {title}
                  </option>
                );
              })}
            </select>

            <textarea
              name="keys"
              required
              rows={3}
              placeholder="Paste license keys (one per line)...&#10;XXXX-YYYY-ZZZZ-1111&#10;XXXX-YYYY-ZZZZ-2222"
              className="w-full px-3 py-1.5 bg-background border border-input rounded-md font-mono text-[11px] focus:outline-none"
            />

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-3.5 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm"
              >
                Import to Pool
              </button>
            </div>
          </form>

          {/* Active Keys Sample Directory */}
          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
            {keys.length > 0 ? (
              keys.map((key) => (
                <div
                  key={key.id}
                  className="p-2.5 bg-background border border-border rounded-md flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <span className="font-mono font-bold text-foreground block truncate">
                      {key.license_key}
                    </span>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {key.products?.title?.[locale] || 'License'}
                    </span>
                  </div>

                  <span
                    className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded font-mono shrink-0 ${
                      key.status === 'AVAILABLE'
                        ? 'bg-emerald-500/10 text-emerald-600'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {key.status}
                  </span>
                </div>
              ))
            ) : (
              <div className="py-6 text-center text-xs text-muted-foreground italic">
                No license keys in the dispenser pool.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
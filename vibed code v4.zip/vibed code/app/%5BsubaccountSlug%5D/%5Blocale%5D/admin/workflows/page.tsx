'use client';

import React, { use, useEffect, useState, useTransition } from 'react';
import { useWorkflowStore } from '@/stores/workflow-store';
import {
  getWorkflows,
  saveWorkflow,
  toggleWorkflowStatus,
  deleteWorkflow,
} from '@/server/actions/workflows';
import {
  Workflow,
  WorkflowCanvasNode,
  WorkflowNodeType,
  WorkflowTriggerType,
  WorkflowActionType,
} from '@/types/workflows';

interface WorkflowsAdminPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    workflowId?: string;
  }>;
}

const TRIGGER_PRESETS: { type: WorkflowTriggerType; label: string; icon: string }[] = [
  { type: 'ORDER_CREATED', label: 'Order Created (COD/Paid)', icon: '🛍️' },
  { type: 'LEAD_CAPTURED', label: 'Form Abandoned Lead', icon: '🧲' },
  { type: 'CONTACT_TAGGED', label: 'Tag Added to Contact', icon: '🏷️' },
  { type: 'OPPORTUNITY_STAGE_CHANGED', label: 'Deal Moved in Pipeline', icon: '📋' },
  { type: 'APPOINTMENT_SCHEDULED', label: 'New Appointment Booked', icon: '📅' },
];

const ACTION_PRESETS: { type: WorkflowActionType; label: string; icon: string }[] = [
  { type: 'SEND_SMS', label: 'Send SMS (WhatsApp/Twilio)', icon: '💬' },
  { type: 'SEND_EMAIL', label: 'Send Confirmation Email', icon: '✉️' },
  { type: 'ADD_TAG', label: 'Attach CRM Tag', icon: '🏷️' },
  { type: 'MOVE_PIPELINE_STAGE', label: 'Move Deal Stage', icon: '🎯' },
  { type: 'DISPATCH_WEBHOOK', label: 'Dispatch to n8n Webhook', icon: '⚡' },
];

export default function WorkflowsAdminPage({
  params,
  searchParams,
}: WorkflowsAdminPageProps) {
  const { subaccountSlug } = use(params);
  const { workflowId: targetWorkflowId } = use(searchParams);

  const {
    workflowId,
    name,
    isActive,
    nodes,
    edges,
    isDirty,
    setWorkflow,
    setName,
    setIsActive,
    addNode,
    removeNode,
    addEdge,
    resetWorkflow,
  } = useWorkflowStore();

  const [workflowsList, setWorkflowsList] = useState<Workflow[]>([]);
  const [subaccountId, setSubaccountId] = useState<string>('');
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  // 1. Fetch Workflows List on Mount
  useEffect(() => {
    // Resolve subaccount and workflows
    fetch(`/api/edge/resolve-domain?slug=${subaccountSlug}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.subaccountId) {
          setSubaccountId(data.subaccountId);
          getWorkflows(data.subaccountId).then((res) => {
            if (res.success && res.data) {
              setWorkflowsList(res.data);
              const target = targetWorkflowId
                ? res.data.find((w) => w.id === targetWorkflowId)
                : res.data[0];

              if (target) {
                setWorkflow(target);
              }
            }
          });
        }
      })
      .catch(() => null);
  }, [subaccountSlug, targetWorkflowId, setWorkflow]);

  // 2. Add New Canvas Node Handler
  const handleAddCanvasNode = (
    type: WorkflowNodeType,
    triggerType?: WorkflowTriggerType,
    actionType?: WorkflowActionType
  ) => {
    const newNodeId = `node_${Date.now()}`;
    const defaultPosition = {
      x: 100 + nodes.length * 30,
      y: 80 + nodes.length * 70,
    };

    let label = 'Automation Step';
    if (type === 'TRIGGER') {
      label = TRIGGER_PRESETS.find((t) => t.type === triggerType)?.label || 'Trigger';
    } else if (type === 'ACTION') {
      label = ACTION_PRESETS.find((a) => a.type === actionType)?.label || 'Action';
    } else if (type === 'DELAY') {
      label = 'Delay: Wait 1 Hour';
    }

    const newNode: WorkflowCanvasNode = {
      id: newNodeId,
      type,
      position: defaultPosition,
      data: {
        label,
        triggerType,
        actionType,
        delayConfig: type === 'DELAY' ? { amount: 1, unit: 'hours' } : undefined,
      },
    };

    addNode(newNode);

    // Automatically connect with previous node if one exists
    if (nodes.length > 0) {
      const prevNode = nodes[nodes.length - 1];
      addEdge({
        id: `edge_${prevNode.id}_${newNodeId}`,
        source: prevNode.id,
        target: newNodeId,
      });
    }
  };

  // 3. Save Workflow Handler
  const handleSave = () => {
    if (!subaccountId) return;

    setSaveFeedback(null);
    startTransition(async () => {
      const res = await saveWorkflow(subaccountId, {
        id: workflowId || undefined,
        name,
        is_active: isActive,
        nodes,
        edges,
      });

      if (res.success && res.data) {
        setWorkflow(res.data);
        setSaveFeedback('Workflow successfully saved');
        setTimeout(() => setSaveFeedback(null), 3000);

        // Update list
        setWorkflowsList((prev) => {
          const index = prev.findIndex((w) => w.id === res.data!.id);
          if (index > -1) {
            const nextList = [...prev];
            nextList[index] = res.data!;
            return nextList;
          }
          return [res.data!, ...prev];
        });
      }
    });
  };

  const handleCreateNew = () => {
    resetWorkflow();
    setName('New Customer Flow');
    // Pre-populate with default trigger
    handleAddCanvasNode('TRIGGER', 'ORDER_CREATED');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-100px)] space-y-4">
      {/* Top Action Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="text-lg font-bold text-foreground bg-transparent border-b border-dashed border-border focus:border-primary focus:outline-none px-1 py-0.5"
          />
          <button
            onClick={() => setIsActive(!isActive)}
            className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase transition-colors ${
              isActive
                ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                : 'bg-muted text-muted-foreground border border-border'
            }`}
          >
            {isActive ? '● Active' : '○ Paused'}
          </button>
        </div>

        <div className="flex items-center gap-2">
          {saveFeedback && (
            <span className="text-xs text-emerald-600 font-medium animate-pulse">
              ✓ {saveFeedback}
            </span>
          )}

          <button
            onClick={handleCreateNew}
            className="px-3 py-1.5 bg-card border border-border text-foreground hover:bg-muted text-xs font-semibold rounded-md shadow-sm transition-colors"
          >
            + New Flow
          </button>

          <button
            onClick={handleSave}
            disabled={isPending}
            className="px-4 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm disabled:opacity-50 flex items-center gap-1.5"
          >
            {isPending && <span className="animate-spin">⟳</span>}
            Save Automation
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-4 min-h-0">
        {/* Left Toolbar / Node Step Palette */}
        <div className="md:col-span-3 bg-card border border-border rounded-xl p-4 shadow-sm flex flex-col justify-between overflow-y-auto space-y-5">
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
              Step Components
            </h3>

            {/* Triggers Category */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-foreground block">
                1. Triggers (When this happens)
              </span>
              <div className="space-y-1">
                {TRIGGER_PRESETS.map((t) => (
                  <button
                    key={t.type}
                    onClick={() => handleAddCanvasNode('TRIGGER', t.type)}
                    className="w-full text-left p-2 rounded-lg border border-border bg-muted/30 hover:bg-muted text-xs font-medium text-foreground flex items-center gap-2 transition-colors"
                  >
                    <span>{t.icon}</span>
                    <span className="truncate">{t.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Actions Category */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-foreground block">
                2. Actions (Do this next)
              </span>
              <div className="space-y-1">
                {ACTION_PRESETS.map((a) => (
                  <button
                    key={a.type}
                    onClick={() => handleAddCanvasNode('ACTION', undefined, a.type)}
                    className="w-full text-left p-2 rounded-lg border border-border bg-muted/30 hover:bg-muted text-xs font-medium text-foreground flex items-center gap-2 transition-colors"
                  >
                    <span>{a.icon}</span>
                    <span className="truncate">{a.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Delays Category */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-foreground block">
                3. Delays
              </span>
              <button
                onClick={() => handleAddCanvasNode('DELAY')}
                className="w-full text-left p-2 rounded-lg border border-border bg-muted/30 hover:bg-muted text-xs font-medium text-foreground flex items-center gap-2 transition-colors"
              >
                <span>⏱</span>
                <span>Wait / Delay Timer</span>
              </button>
            </div>
          </div>

          {/* Existing Workflows Directory List */}
          <div className="border-t border-border pt-3 space-y-2">
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
              Saved Workflows ({workflowsList.length})
            </span>
            <div className="space-y-1 max-h-36 overflow-y-auto">
              {workflowsList.map((wf) => (
                <button
                  key={wf.id}
                  onClick={() => setWorkflow(wf)}
                  className={`w-full text-left p-1.5 rounded text-xs truncate transition-colors flex items-center justify-between ${
                    wf.id === workflowId
                      ? 'bg-primary/10 text-primary font-bold'
                      : 'hover:bg-muted text-muted-foreground'
                  }`}
                >
                  <span className="truncate">{wf.name}</span>
                  <span className="text-[10px] font-mono shrink-0 ml-1">
                    {wf.is_active ? '●' : '○'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Canvas: Drag-and-Drop / Interactive Visual Flow */}
        <div className="md:col-span-9 bg-card border border-border rounded-xl p-6 shadow-sm overflow-auto relative bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:16px_16px] dark:bg-[radial-gradient(#1e293b_1px,transparent_1px)]">
          {nodes.length > 0 ? (
            <div className="space-y-6 max-w-md mx-auto py-4">
              {nodes.map((node, index) => {
                const isTrigger = node.type === 'TRIGGER';
                const isAction = node.type === 'ACTION';
                const isDelay = node.type === 'DELAY';

                return (
                  <div key={node.id} className="relative group">
                    {/* Node Card */}
                    <div
                      className={`p-4 rounded-xl border-2 shadow-sm transition-all bg-card ${
                        isTrigger
                          ? 'border-blue-500/40 bg-blue-500/5'
                          : isAction
                          ? 'border-emerald-500/40 bg-emerald-500/5'
                          : 'border-amber-500/40 bg-amber-500/5'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider font-mono ${
                            isTrigger
                              ? 'text-blue-600'
                              : isAction
                              ? 'text-emerald-600'
                              : 'text-amber-600'
                          }`}
                        >
                          Step {index + 1} • {node.type}
                        </span>

                        <button
                          onClick={() => removeNode(node.id)}
                          className="text-xs text-muted-foreground hover:text-destructive p-0.5"
                        >
                          ✕
                        </button>
                      </div>

                      <h4 className="text-sm font-bold text-foreground mt-1">
                        {node.data.label}
                      </h4>

                      {node.data.delayConfig && (
                        <p className="text-xs text-muted-foreground mt-0.5 font-mono">
                          Duration: {node.data.delayConfig.amount} {node.data.delayConfig.unit}
                        </p>
                      )}
                    </div>

                    {/* Connecting Connector Indicator to Next Step */}
                    {index < nodes.length - 1 && (
                      <div className="h-6 flex items-center justify-center">
                        <div className="w-0.5 h-full bg-border" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-xs text-muted-foreground">
              <span className="text-3xl mb-2">🔄</span>
              <p className="font-semibold text-foreground text-sm">Visual Canvas Empty</p>
              <p className="max-w-xs mt-1">
                Select a trigger from the left sidebar to start building your automated customer journey.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';
import { AvailabilityScheduler } from '@/components/admin/AvailabilityScheduler';
import { Appointment, Calendar, WeeklySchedule } from '@/types/booking';

interface CalendarsAdminPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    calendarId?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Calendars & Availability Scheduling',
  };
}

const DEFAULT_WEEKLY_SCHEDULE: WeeklySchedule = {
  monday: { isOpen: true, windows: [{ start: '09:00', end: '17:00' }] },
  tuesday: { isOpen: true, windows: [{ start: '09:00', end: '17:00' }] },
  wednesday: { isOpen: true, windows: [{ start: '09:00', end: '17:00' }] },
  thursday: { isOpen: true, windows: [{ start: '09:00', end: '17:00' }] },
  friday: { isOpen: true, windows: [{ start: '09:00', end: '17:00' }] },
  saturday: { isOpen: false, windows: [] },
  sunday: { isOpen: false, windows: [] },
};

export default async function CalendarsAdminPage({
  params,
  searchParams,
}: CalendarsAdminPageProps) {
  const { subaccountSlug, locale } = await params;
  const { calendarId } = await searchParams;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'booking:read');

  const supabase = await createServerClient();

  // 2. Fetch or Seed Default Calendar
  let { data: calendarsData } = await supabase
    .from('calendars')
    .select('*')
    .eq('subaccount_id', tenant.id)
    .order('created_at', { ascending: true });

  if (!calendarsData || calendarsData.length === 0) {
    const { data: seededCal } = await supabase
      .from('calendars')
      .insert({
        subaccount_id: tenant.id,
        name: 'Strategy Consultation',
        slug: 'consultation',
        duration_minutes: 30,
        weekly_schedule: DEFAULT_WEEKLY_SCHEDULE as any,
        timezone: 'UTC',
      })
      .select('*')
      .single();

    calendarsData = seededCal ? [seededCal] : [];
  }

  const calendars: Calendar[] = (calendarsData || []).map((c: any) => ({
    ...c,
    weekly_schedule: c.weekly_schedule as unknown as WeeklySchedule,
  }));

  const activeCalendar =
    calendars.find((c) => c.id === calendarId) || calendars[0];

  // 3. Fetch Upcoming Appointments for Selected Calendar
  let appointments: Appointment[] = [];

  if (activeCalendar) {
    const { data: apptsData } = await supabase
      .from('appointments')
      .select(`
        *,
        contacts (
          first_name,
          last_name,
          email,
          phone
        )
      `)
      .eq('calendar_id', activeCalendar.id)
      .eq('subaccount_id', tenant.id)
      .order('start_time', { ascending: true })
      .limit(10);

    appointments = (apptsData || []).map((a: any) => ({
      ...a,
      contact: a.contacts ?? null,
    }));
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">📅</span>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Calendars & Scheduling
            </h1>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Configure consultation availability, buffer intervals, and review booked client meetings.
          </p>
        </div>

        {activeCalendar && (
          <Link
            href={`/${subaccountSlug}/${locale}/book/${activeCalendar.slug}`}
            target="_blank"
            className="px-3.5 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-md hover:bg-primary/90 transition-colors shadow-sm self-start sm:self-auto flex items-center gap-1.5"
          >
            <span>Public Booking Link</span>
            <span>↗</span>
          </Link>
        )}
      </div>

      {/* Calendar Switcher Tabs */}
      {calendars.length > 1 && (
        <div className="flex items-center gap-2 border-b border-border pb-1 overflow-x-auto text-xs">
          {calendars.map((cal) => (
            <Link
              key={cal.id}
              href={`/${subaccountSlug}/${locale}/admin/calendars?calendarId=${cal.id}`}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors shrink-0 ${
                cal.id === activeCalendar?.id
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              {cal.name}
            </Link>
          ))}
        </div>
      )}

      {activeCalendar && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Weekly Working Hours Matrix */}
          <div className="lg:col-span-8">
            <AvailabilityScheduler
              subaccountId={tenant.id}
              calendarId={activeCalendar.id}
              initialSchedule={activeCalendar.weekly_schedule}
              timezone={activeCalendar.timezone}
            />
          </div>

          {/* Right Column: Upcoming Appointments Feed */}
          <div className="lg:col-span-4 bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-xs font-bold text-foreground uppercase tracking-wider">
                Upcoming Bookings ({appointments.length})
              </h3>
            </div>

            <div className="divide-y divide-border/60">
              {appointments.length > 0 ? (
                appointments.map((appt) => {
                  const clientName = appt.contact
                    ? `${appt.contact.first_name ?? ''} ${appt.contact.last_name ?? ''}`.trim()
                    : 'Client Attendee';

                  const startTime = new Date(appt.start_time);

                  return (
                    <div key={appt.id} className="py-3 space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-foreground">{clientName}</span>
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                            appt.status === 'SCHEDULED'
                              ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                              : 'bg-muted text-muted-foreground'
                          }`}
                        >
                          {appt.status}
                        </span>
                      </div>

                      <p className="text-muted-foreground font-mono text-[11px]">
                        {startTime.toLocaleDateString(locale, {
                          month: 'short',
                          day: 'numeric',
                        })}{' '}
                        •{' '}
                        {startTime.toLocaleTimeString(locale, {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>

                      {appt.contact?.phone && (
                        <p className="text-[11px] text-muted-foreground font-mono">
                          {appt.contact.phone}
                        </p>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="py-8 text-center text-xs text-muted-foreground italic">
                  No upcoming appointments scheduled yet.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
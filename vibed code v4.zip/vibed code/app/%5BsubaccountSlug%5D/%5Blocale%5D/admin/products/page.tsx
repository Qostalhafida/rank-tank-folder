import Link from 'next/link';
import { notFound, revalidatePath } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { requirePermission } from '@/lib/auth/rbac';
import { createServerClient } from '@/lib/supabase/server';
import { Database, MultilingualText } from '@/types/database';

type ProductRow = Database['public']['Tables']['products']['Row'];

interface ProductsAdminPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Products & Inventory Catalog',
  };
}

export default async function ProductsAdminPage({ params }: ProductsAdminPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context & RBAC Guard
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  await requirePermission(tenant.id, 'products:read');

  // 2. Fetch Catalog Products
  const supabase = await createServerClient();
  const { data: productsData, error } = await supabase
    .from('products')
    .select('*')
    .eq('subaccount_id', tenant.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Catalog fetch failure:', error.message);
  }

  const products: ProductRow[] = productsData || [];

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(val);

  return (
    <div className="space-y-6">
      {/* Header & Quick Creation Form */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">🏷️</span>
            <h1 className="text-xl font-bold text-foreground tracking-tight">
              Products & Inventory
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-muted font-mono font-medium text-muted-foreground">
              {products.length} Items
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Manage your physical SKUs, stock levels, and digital downloadable products.
          </p>
        </div>

        {/* Quick Product Creator Action */}
        <form
          action={async (formData: FormData) => {
            'use server';
            await requirePermission(tenant.id, 'products:write');
            const client = await createServerClient();

            const title = (formData.get('title') as string) || '';
            const price = parseFloat((formData.get('price') as string) || '0');
            const type = (formData.get('type') as 'PHYSICAL' | 'DIGITAL') || 'PHYSICAL';
            const slug = title
              .toLowerCase()
              .replace(/[^a-z0-9]+/g, '-')
              .replace(/(^-|-$)+/g, '');

            await client.from('products').insert({
              subaccount_id: tenant.id,
              title: { en: title, [locale]: title },
              slug: `${slug}-${Date.now().toString().slice(-4)}`,
              type,
              price,
              is_active: true,
              images: [],
              metadata: {},
            });

            revalidatePath(`/[subaccountSlug]/admin/products`, 'page');
          }}
          className="flex flex-wrap gap-2 self-start sm:self-auto"
        >
          <input
            type="text"
            name="title"
            required
            placeholder="Product Title..."
            className="px-3 py-1.5 text-xs bg-card border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <input
            type="number"
            name="price"
            required
            step="0.01"
            placeholder="Price..."
            className="w-24 px-3 py-1.5 text-xs bg-card border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <select
            name="type"
            className="px-2.5 py-1.5 text-xs bg-card border border-input rounded-md font-medium focus:outline-none"
          >
            <option value="PHYSICAL">Physical</option>
            <option value="DIGITAL">Digital</option>
          </select>
          <button
            type="submit"
            className="px-3.5 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm shrink-0"
          >
            + Add Product
          </button>
        </form>
      </div>

      {/* Catalog Table */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-border bg-muted/30 uppercase font-semibold text-muted-foreground tracking-wider">
              <th className="py-3 px-4">Item</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">SKU / Stock</th>
              <th className="py-3 px-4">Price</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {products.length > 0 ? (
              products.map((product) => {
                const titleText =
                  product.title[locale] || product.title.en || 'Untitled Item';
                const isPhysical = product.type === 'PHYSICAL';

                return (
                  <tr key={product.id} className="hover:bg-muted/30 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-muted/40 border border-border overflow-hidden shrink-0 flex items-center justify-center">
                          {product.images && product.images[0] ? (
                            <img
                              src={product.images[0]}
                              alt={titleText}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="text-muted-foreground text-xs">📦</span>
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-foreground text-xs">{titleText}</p>
                          <Link
                            href={`/${subaccountSlug}/${locale}/products/${product.slug}`}
                            target="_blank"
                            className="text-[10px] font-mono text-muted-foreground hover:text-primary transition-colors"
                          >
                            /products/{product.slug} ↗
                          </Link>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          isPhysical
                            ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20'
                            : 'bg-purple-500/10 text-purple-600 border border-purple-500/20'
                        }`}
                      >
                        {product.type}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px]">
                      <div>{product.sku || '—'}</div>
                      {isPhysical && (
                        <div className="text-[10px] text-muted-foreground font-sans">
                          {product.stock_quantity !== null ? (
                            product.stock_quantity > 0 ? (
                              <span className="text-emerald-600 font-medium">
                                {product.stock_quantity} in stock
                              </span>
                            ) : (
                              <span className="text-destructive font-medium">Out of stock</span>
                            )
                          ) : (
                            'Unlimited'
                          )}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-foreground">
                      {formatPrice(product.price)}
                      {product.compare_at_price && (
                        <span className="block text-[10px] text-muted-foreground line-through font-normal">
                          {formatPrice(product.compare_at_price)}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          product.is_active
                            ? 'bg-emerald-500/10 text-emerald-600'
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {product.is_active ? 'Active' : 'Draft'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right space-x-2">
                      <form
                        action={async () => {
                          'use server';
                          await requirePermission(tenant.id, 'products:write');
                          const client = await createServerClient();
                          await client
                            .from('products')
                            .update({ is_active: !product.is_active })
                            .eq('id', product.id)
                            .eq('subaccount_id', tenant.id);
                          revalidatePath(`/[subaccountSlug]/admin/products`, 'page');
                        }}
                        className="inline-block"
                      >
                        <button
                          type="submit"
                          className="text-[11px] text-muted-foreground hover:text-foreground font-medium"
                        >
                          {product.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                      </form>

                      <form
                        action={async () => {
                          'use server';
                          await requirePermission(tenant.id, 'products:delete');
                          const client = await createServerClient();
                          await client
                            .from('products')
                            .delete()
                            .eq('id', product.id)
                            .eq('subaccount_id', tenant.id);
                          revalidatePath(`/[subaccountSlug]/admin/products`, 'page');
                        }}
                        className="inline-block"
                      >
                        <button
                          type="submit"
                          className="text-[11px] text-destructive hover:underline font-medium"
                        >
                          Delete
                        </button>
                      </form>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6} className="py-12 text-center text-muted-foreground text-xs italic">
                  No products in catalog. Use the quick creator above to add your first product.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
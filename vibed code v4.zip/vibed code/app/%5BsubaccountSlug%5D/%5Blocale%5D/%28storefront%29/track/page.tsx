import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  OrderTrackingTimeline,
  TrackingOrderDetails,
} from '@/components/storefront/OrderTrackingTimeline';

interface OrderTrackingPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    order?: string;
    phone?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Track Your Parcel & Order Status',
  };
}

export default async function OrderTrackingPage({
  params,
  searchParams,
}: OrderTrackingPageProps) {
  const { subaccountSlug, locale } = await params;
  const { order: orderQuery, phone: phoneQuery } = await searchParams;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  let trackedOrder: TrackingOrderDetails | null = null;
  let searchAttempted = Boolean(orderQuery);
  let notFoundMessage: string | null = null;

  // 2. Fetch Order if Search Query Provided
  if (orderQuery) {
    const supabase = createAdminClient();
    const cleanOrderNumber = orderQuery.trim().toUpperCase().replace('#', '');

    const { data: orderData, error } = await supabase
      .from('orders')
      .select(`
        *,
        contacts (
          phone,
          email
        ),
        order_items (
          id,
          quantity,
          unit_price,
          product_title
        )
      `)
      .eq('subaccount_id', tenant.id)
      .eq('order_number', cleanOrderNumber)
      .maybeSingle();

    if (error || !orderData) {
      notFoundMessage = 'No order found with the provided reference number.';
    } else {
      // Optional security phone check if phoneQuery was supplied
      const customer = orderData.contacts as any;
      const shipping = orderData.shipping_address as Record<string, any> | null;
      const recordedPhone = customer?.phone || shipping?.phone || '';

      if (phoneQuery) {
        const sanitizedInput = phoneQuery.replace(/[^0-9]/g, '');
        const sanitizedRecorded = recordedPhone.replace(/[^0-9]/g, '');

        if (!sanitizedRecorded.includes(sanitizedInput) && !sanitizedInput.includes(sanitizedRecorded)) {
          notFoundMessage = 'Phone number does not match the order records.';
        } else {
          trackedOrder = {
            orderNumber: orderData.order_number,
            status: orderData.status,
            paymentMethod: orderData.payment_method,
            paymentStatus: orderData.payment_status,
            waybillNumber: orderData.waybill_number,
            createdAt: orderData.created_at,
            totalAmount: orderData.total_amount,
            currency: tenant.currency || 'USD',
            items: (orderData.order_items as any[]) || [],
          };
        }
      } else {
        trackedOrder = {
          orderNumber: orderData.order_number,
          status: orderData.status,
          paymentMethod: orderData.payment_method,
          paymentStatus: orderData.payment_status,
          waybillNumber: orderData.waybill_number,
          createdAt: orderData.created_at,
          totalAmount: orderData.total_amount,
          currency: tenant.currency || 'USD',
          items: (orderData.order_items as any[]) || [],
        };
      }
    }
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl space-y-10">
      {/* Title & Search Form Header */}
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-wider text-primary">
          Realtime Tracking
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
          Track Your Delivery
        </h1>
        <p className="text-xs sm:text-sm text-muted-foreground max-w-md mx-auto">
          Enter your order reference code or tracking number to follow your parcel status in real time.
        </p>
      </div>

      {/* Lookup Search Form */}
      <div className="max-w-xl mx-auto bg-card border border-border p-6 rounded-2xl shadow-sm">
        <form method="GET" className="space-y-4 text-xs">
          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">
              Order Reference Code *
            </label>
            <input
              type="text"
              name="order"
              required
              defaultValue={orderQuery || ''}
              placeholder="e.g. ORD-B2K1-9482"
              className="w-full px-3.5 py-2.5 bg-background border border-input rounded-lg font-mono text-xs uppercase focus:outline-none focus:ring-2 focus:ring-primary/40 text-foreground"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-foreground mb-1.5">
              Phone Number (Optional Verification)
            </label>
            <input
              type="tel"
              name="phone"
              defaultValue={phoneQuery || ''}
              placeholder="e.g. +1 234 567 8900"
              className="w-full px-3.5 py-2.5 bg-background border border-input rounded-lg font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40 text-foreground"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md"
          >
            Track Parcel Status →
          </button>
        </form>
      </div>

      {/* Error / Not Found Message */}
      {searchAttempted && notFoundMessage && (
        <div className="max-w-xl mx-auto p-4 bg-destructive/10 border border-destructive/20 text-destructive text-xs rounded-xl text-center">
          {notFoundMessage}
        </div>
      )}

      {/* Order Tracking Timeline Display */}
      {trackedOrder && (
        <div className="pt-4">
          <OrderTrackingTimeline order={trackedOrder} locale={locale} />
        </div>
      )}
    </div>
  );
}
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createAdminClient } from '@/lib/supabase/admin';
import { CodCheckoutForm } from '@/components/storefront/CodCheckoutForm';
import { Database, MultilingualText } from '@/types/database';

type ProductRow = Database['public']['Tables']['products']['Row'];

interface ProductPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    slug: string;
  }>;
}

export async function generateMetadata({ params }: ProductPageProps) {
  const { subaccountSlug, locale, slug } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');

  if (!subaccountRes.success || !subaccountRes.data) return { title: 'Product Not Found' };

  const supabase = createAdminClient();
  const { data: product } = await supabase
    .from('products')
    .select('title, description, images')
    .eq('subaccount_id', subaccountRes.data.id)
    .eq('slug', slug)
    .eq('is_active', true)
    .maybeSingle();

  if (!product) return { title: 'Product Not Found' };

  const titleText =
    (product.title as MultilingualText)?.[locale] ||
    (product.title as MultilingualText)?.en ||
    'Product Details';
  const descText =
    (product.description as MultilingualText)?.[locale] ||
    (product.description as MultilingualText)?.en ||
    '';

  return {
    title: titleText,
    description: descText,
    openGraph: {
      title: titleText,
      description: descText,
      images: product.images?.[0] ? [{ url: product.images[0] }] : undefined,
    },
  };
}

export default async function ProductDetailPage({ params }: ProductPageProps) {
  const { subaccountSlug, locale, slug } = await params;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Fetch Product from Database
  const supabase = createAdminClient();
  const { data: product, error } = await supabase
    .from('products')
    .select('*')
    .eq('subaccount_id', tenant.id)
    .eq('slug', slug)
    .eq('is_active', true)
    .single();

  if (error || !product) notFound();

  // 3. Fetch Related Cross-Sell Products
  const { data: crossSells } = await supabase
    .from('products')
    .select('id, slug, title, price, compare_at_price, images')
    .eq('subaccount_id', tenant.id)
    .eq('is_active', true)
    .neq('id', product.id)
    .limit(3);

  const localizedTitle =
    product.title[locale] || product.title.en || 'Product';
  const localizedDescription =
    product.description?.[locale] || product.description?.en || '';

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
    }).format(val);

  const discountPercentage =
    product.compare_at_price && product.compare_at_price > product.price
      ? Math.round(
          ((product.compare_at_price - product.price) / product.compare_at_price) * 100
        )
      : null;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Product Gallery */}
        <div className="lg:col-span-6 space-y-4">
          <div className="aspect-square bg-muted/30 border border-border rounded-xl overflow-hidden shadow-sm flex items-center justify-center">
            {product.images && product.images.length > 0 ? (
              <img
                src={product.images[0]}
                alt={localizedTitle}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-muted-foreground text-sm">No image available</span>
            )}
          </div>

          {/* Thumbnails */}
          {product.images && product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <img
                  key={idx}
                  src={img}
                  alt={`${localizedTitle} preview ${idx + 1}`}
                  className="w-16 h-16 rounded-md object-cover border border-border cursor-pointer hover:border-primary transition-colors"
                />
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Pricing, Overview & Instant Checkout */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            {discountPercentage && (
              <span className="inline-block px-2.5 py-0.5 bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 text-xs font-bold uppercase rounded-md mb-2">
                Save {discountPercentage}% OFF
              </span>
            )}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
              {localizedTitle}
            </h1>

            {/* Pricing Tag */}
            <div className="flex items-baseline gap-3 mt-3 font-mono">
              <span className="text-2xl sm:text-3xl font-black text-primary">
                {formatPrice(product.price)}
              </span>
              {product.compare_at_price && (
                <span className="text-base text-muted-foreground line-through">
                  {formatPrice(product.compare_at_price)}
                </span>
              )}
            </div>

            {/* Stock status */}
            <div className="mt-3 flex items-center gap-2 text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-muted-foreground font-medium">In stock — Ready for fast dispatch</span>
            </div>
          </div>

          {/* Product Description */}
          {localizedDescription && (
            <div className="prose prose-sm dark:prose-invert text-muted-foreground border-t border-border pt-4">
              <p className="whitespace-pre-line">{localizedDescription}</p>
            </div>
          )}

          {/* Fast Direct COD Checkout Module (Embedded on PDP for high conversion) */}
          <div className="pt-2">
            <CodCheckoutForm
              subaccountId={tenant.id}
              subaccountSlug={subaccountSlug}
              locale={locale}
              currency={tenant.currency || 'USD'}
              product={{
                id: product.id,
                title: product.title,
                price: product.price,
                image: product.images?.[0],
              }}
            />
          </div>
        </div>
      </div>

      {/* Cross-Sells / Recommended Products */}
      {crossSells && crossSells.length > 0 && (
        <div className="mt-16 pt-8 border-t border-border space-y-6">
          <h2 className="text-lg font-bold text-foreground">Frequently Bought Together</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {crossSells.map((cross) => {
              const crossTitle =
                (cross.title as MultilingualText)?.[locale] ||
                (cross.title as MultilingualText)?.en ||
                'Product';

              return (
                <a
                  key={cross.id}
                  href={`/${subaccountSlug}/${locale}/products/${cross.slug}`}
                  className="group p-4 bg-card border border-border rounded-xl shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div className="aspect-square bg-muted/40 rounded-lg overflow-hidden mb-3">
                    {cross.images?.[0] && (
                      <img
                        src={cross.images[0]}
                        alt={crossTitle}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-xs text-foreground group-hover:text-primary transition-colors line-clamp-1">
                      {crossTitle}
                    </h3>
                    <div className="mt-1 font-mono text-sm font-bold text-primary">
                      {formatPrice(cross.price)}
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
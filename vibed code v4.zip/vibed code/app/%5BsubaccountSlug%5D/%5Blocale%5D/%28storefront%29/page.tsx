import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createAdminClient } from '@/lib/supabase/admin';
import { CodCheckoutForm } from '@/components/storefront/CodCheckoutForm';
import { MultilingualText } from '@/types/database';

interface StorefrontHomePageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata({ params }: StorefrontHomePageProps) {
  const { subaccountSlug } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');

  if (!subaccountRes.success || !subaccountRes.data) {
    return { title: 'Storefront Not Found' };
  }

  const tenant = subaccountRes.data;
  return {
    title: `${tenant.name} | Official Store`,
    description: `Shop official products and digital training from ${tenant.name}.`,
  };
}

export default async function StorefrontHomePage({ params }: StorefrontHomePageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Fetch Catalog Products
  const supabase = createAdminClient();
  const { data: productsData } = await supabase
    .from('products')
    .select('*')
    .eq('subaccount_id', tenant.id)
    .eq('is_active', true)
    .order('created_at', { ascending: false });

  const products = productsData || [];
  const featuredProduct = products[0];

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
      maximumFractionDigits: 0,
    }).format(val);

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="bg-muted/30 border-b border-border py-12 md:py-20 px-4">
        <div className="container mx-auto max-w-5xl text-center space-y-4">
          <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-bold uppercase rounded-full tracking-wider">
            Verified Official Store
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-foreground tracking-tight leading-tight">
            Discover Exclusive Collections at {tenant.name}
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Fast fulfillment, insured express delivery, and payment options tailored to your preference.
          </p>
        </div>
      </section>

      {/* Dynamic Mode Switch: Direct COD Lander vs Full Catalog Grid */}
      {tenant.mode === 'COD' && featuredProduct ? (
        /* Direct COD 1-Page Ordering Experience */
        <section className="container mx-auto px-4 max-w-4xl space-y-8">
          <div className="text-center space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
              ⚡ Flash Deal — Cash on Delivery
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-foreground">
              Order Today & Pay Upon Arrival
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start bg-card border border-border rounded-2xl p-6 sm:p-8 shadow-sm">
            {/* Product Media & Features */}
            <div className="space-y-4">
              <div className="aspect-square bg-muted/40 rounded-xl overflow-hidden border border-border">
                {featuredProduct.images?.[0] && (
                  <img
                    src={featuredProduct.images[0]}
                    alt={
                      (featuredProduct.title as MultilingualText)?.[locale] ||
                      'Featured Product'
                    }
                    className="w-full h-full object-cover"
                  />
                )}
              </div>

              <div>
                <h3 className="text-lg font-bold text-foreground">
                  {(featuredProduct.title as MultilingualText)?.[locale] ||
                    (featuredProduct.title as MultilingualText)?.en}
                </h3>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                  {(featuredProduct.description as MultilingualText)?.[locale] ||
                    (featuredProduct.description as MultilingualText)?.en}
                </p>
              </div>

              <div className="p-3 bg-muted/30 rounded-lg text-xs space-y-1 font-medium text-foreground">
                <div className="flex items-center gap-2">
                  <span>✓</span> <span>100% Risk-Free Cash On Delivery</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>✓</span> <span>Free 24-48h Express Shipping</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>✓</span> <span>Inspect package before paying courier</span>
                </div>
              </div>
            </div>

            {/* Direct Instant Order Form */}
            <div>
              <CodCheckoutForm
                subaccountId={tenant.id}
                subaccountSlug={subaccountSlug}
                locale={locale}
                currency={tenant.currency || 'USD'}
                product={{
                  id: featuredProduct.id,
                  title: featuredProduct.title,
                  price: featuredProduct.price,
                  image: featuredProduct.images?.[0],
                }}
              />
            </div>
          </div>
        </section>
      ) : null}

      {/* Catalog Grid (All Modes) */}
      <section className="container mx-auto px-4 max-w-6xl space-y-8">
        <div className="flex justify-between items-end border-b border-border pb-4">
          <div>
            <h2 className="text-xl font-bold text-foreground tracking-tight">
              Featured Catalog
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Explore physical releases and digital licenses ready for instant delivery.
            </p>
          </div>
          <span className="text-xs font-mono text-muted-foreground">
            {products.length} Products
          </span>
        </div>

        {products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => {
              const titleText =
                (product.title as MultilingualText)?.[locale] ||
                (product.title as MultilingualText)?.en ||
                'Product';

              return (
                <Link
                  key={product.id}
                  href={`/${subaccountSlug}/${locale}/products/${product.slug}`}
                  className="group bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div className="aspect-square bg-muted/40 relative overflow-hidden">
                    {product.images && product.images[0] ? (
                      <img
                        src={product.images[0]}
                        alt={titleText}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                        No Image
                      </div>
                    )}

                    <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-background/90 text-foreground backdrop-blur-sm border border-border/60">
                      {product.type}
                    </span>
                  </div>

                  <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-semibold text-xs text-foreground group-hover:text-primary transition-colors line-clamp-2">
                        {titleText}
                      </h3>
                    </div>

                    <div className="flex items-baseline justify-between pt-2 border-t border-border/40 font-mono">
                      <span className="font-bold text-sm text-foreground">
                        {formatPrice(product.price)}
                      </span>
                      {product.compare_at_price && (
                        <span className="text-[11px] text-muted-foreground line-through">
                          {formatPrice(product.compare_at_price)}
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        ) : (
          <div className="p-16 border border-dashed border-border rounded-2xl text-center text-xs text-muted-foreground">
            No products are currently available in the catalog. Please check back soon.
          </div>
        )}
      </section>
    </div>
  );
}
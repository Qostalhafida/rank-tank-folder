import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { SupportedLocale } from '@/types/subaccount';

interface PrivacyPolicyPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata({ params }: PrivacyPolicyPageProps) {
  const { subaccountSlug, locale } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  const storeName = subaccountRes.data?.name || 'Store';

  const titles: Record<SupportedLocale, string> = {
    en: `Privacy Policy | ${storeName}`,
    ar: `سياسة الخصوصية | ${storeName}`,
    fr: `Politique de Confidentialité | ${storeName}`,
    es: `Política de Privacidad | ${storeName}`,
    pt: `Política de Privacidade | ${storeName}`,
    it: `Informativa sulla Privacy | ${storeName}`,
  };

  return {
    title: titles[locale as SupportedLocale] || titles.en,
  };
}

export default async function PrivacyPolicyPage({ params }: PrivacyPolicyPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const currentYear = new Date().getFullYear();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="bg-card border border-border rounded-2xl p-6 sm:p-10 shadow-sm space-y-8">
        <div className="border-b border-border pb-4 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
            {locale === 'ar'
              ? 'سياسة الخصوصية وحماية البيانات'
              : locale === 'fr'
              ? 'Politique de Confidentialité et Protection des Données'
              : locale === 'es'
              ? 'Política de Privacidad y Protección de Datos'
              : locale === 'pt'
              ? 'Política de Privacidade e Proteção de Dados'
              : locale === 'it'
              ? 'Informativa sulla Privacy e Protezione dei Dati'
              : 'Privacy Policy & Data Protection'}
          </h1>
          <p className="text-xs text-muted-foreground font-mono">
            {tenant.name} • {locale === 'ar' ? 'آخر تحديث: ' : 'Last Updated: '} {currentYear}
          </p>
        </div>

        {/* Localized Content Matrix */}
        <div className="prose prose-sm dark:prose-invert max-w-none text-muted-foreground leading-relaxed space-y-6">
          {locale === 'ar' ? (
            /* Arabic Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">١. مقدمة ونطاق التطبيق</h2>
                <p>
                  نحن في <strong className="text-foreground">{tenant.name}</strong> نلتزم بأعلى معايير حماية خصوصيتك وسرية بياناتك الشخصية. توضح هذه السياسة كيفية جمع معلوماتك واستخدامها وحمايتها عند تصفحك لمتجرنا أو إتمام طلبات الدفع عند الاستلام (COD) أو شراء المنتجات الرقمية.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٢. البيانات التي نقوم بجمعها</h2>
                <p>نقوم بجمع البيانات اللازمة لتوصيل شحنتك والتحقق من الطلبات، وتتضمن:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>الاسم الكامل ورقم الهاتف (للتواصل وتأكيد موعد التوصيل عبر الهاتف أو الواتساب).</li>
                  <li>عنوان الشحن الدقيق والمدينة والرمز البريدي.</li>
                  <li>عنوان البريد الإلكتروني (لتسليم وصولات الشراء وروابط التنزيل الرقمي).</li>
                  <li>بيانات التصفح وعنوان الـ IP لتحسين أمان المعاملات وتفادي الاحتيال.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٣. استخدام بيانات الدفع عند الاستلام (COD)</h2>
                <p>
                  تتم مشاركة بيانات اسمك ورقم هاتفك وعنوانك حصرًا مع شركات التوصيل والناقلين المعتمدين لدينا لغرض تسليم الطرد وتحصيل المبلغ نقدًا. لا نقوم ببيع أو تأجير أي من بياناتك لأطراف ثالثة لأغراض دعائية.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٤. ملفات تعريف الارتباط وتحليلات الإعلانات</h2>
                <p>
                  يستخدم متجرنا ملفات تعريف ارتباط آمنة وتقنيات التتبع المباشر من الخادم (Meta CAPI و TikTok Events API) لتقييم أداء الحملات وتحسين تجربة التسوق. يتم تشفير البيانات الحساسة عبر خوارزميات SHA-256 قبل معالجتها.
                </p>
              </section>
            </>
          ) : locale === 'fr' ? (
            /* French Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Introduction et Champ d'Application</h2>
                <p>
                  Chez <strong className="text-foreground">{tenant.name}</strong>, nous nous engageons à protéger vos données personnelles. Cette politique décrit la manière dont nous collectons, utilisons et sécurisons vos informations lorsque vous utilisez notre boutique, passez une commande en paiement à la livraison (COD) ou accédez à nos formations et produits numériques.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Données Collectées</h2>
                <ul className="list-disc list-inside space-y-1">
                  <li>Nom complet et numéro de téléphone (pour la confirmation et le suivi du livreur).</li>
                  <li>Adresse physique de livraison et ville.</li>
                  <li>Adresse email (pour la facturation et l'accès aux téléchargements numériques sécurisés).</li>
                  <li>Données techniques anonymisées (adresse IP, navigateur, identifiants de session).</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Traitement des Livraisons en Contre-Remboursement (COD)</h2>
                <p>
                  Vos coordonnées d'expédition sont transmises exclusivement à nos transporteurs agréés dans le seul but d'acheminer votre colis et d'encaisser le règlement en espèces lors de la remise en main propre.
                </p>
              </section>
            </>
          ) : (
            /* English Default (Also covers international baseline) */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Overview & Commitment</h2>
                <p>
                  At <strong className="text-foreground">{tenant.name}</strong>, protecting your personal information and maintaining transparency in data processing is our priority. This Privacy Policy outlines our compliance practices regarding data collection, order fulfillment, digital asset delivery, and analytics.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Personal Information We Collect</h2>
                <p>We collect essential order and contact data required to fulfill our contracts with you:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Full name, delivery address, city, and postal code.</li>
                  <li>Phone number for courier delivery verification and WhatsApp order confirmation notifications.</li>
                  <li>Email address for instant digital license delivery and purchase receipts.</li>
                  <li>Device IP address and network metadata for fraud prevention and secure session verification.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Cash on Delivery (COD) Processing</h2>
                <p>
                  When selecting Cash on Delivery, your address and phone number are shared solely with our integrated courier partners to facilitate hand-to-hand parcel delivery and cash collection. We never sell, lease, or monetize your contact records.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">4. Server-Side Tracking & Pixels</h2>
                <p>
                  Our store utilizes server-side conversion tracking (Meta Conversions API and TikTok Events API). Identifiable parameters are cryptographically hashed using SHA-256 before transmission to protect consumer privacy under GDPR and CCPA standards.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">5. Your Legal Rights</h2>
                <p>
                  You retain the right to request access, correction, or permanent deletion of your CRM records at any time by contacting our support team through the official channels listed on our storefront.
                </p>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
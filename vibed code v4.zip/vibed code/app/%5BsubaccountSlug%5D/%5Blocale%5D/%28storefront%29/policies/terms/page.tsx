import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { SupportedLocale } from '@/types/subaccount';

interface TermsOfServicePageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata({ params }: TermsOfServicePageProps) {
  const { subaccountSlug, locale } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  const storeName = subaccountRes.data?.name || 'Store';

  const titles: Record<SupportedLocale, string> = {
    en: `Terms of Service | ${storeName}`,
    ar: `الشروط والأحكام | ${storeName}`,
    fr: `Conditions Générales de Vente | ${storeName}`,
    es: `Términos del Servicio | ${storeName}`,
    pt: `Termos de Serviço | ${storeName}`,
    it: `Termini di Servizio | ${storeName}`,
  };

  return {
    title: titles[locale as SupportedLocale] || titles.en,
  };
}

export default async function TermsOfServicePage({ params }: TermsOfServicePageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const currentYear = new Date().getFullYear();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="bg-card border border-border rounded-2xl p-6 sm:p-10 shadow-sm space-y-8">
        <div className="border-b border-border pb-4 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
            {locale === 'ar'
              ? 'الشروط والأحكام العامة'
              : locale === 'fr'
              ? 'Conditions Générales de Vente et d’Utilisation'
              : locale === 'es'
              ? 'Términos y Condiciones del Servicio'
              : locale === 'pt'
              ? 'Termos e Condições Gerais'
              : locale === 'it'
              ? 'Termini e Condizioni Generali di Contratto'
              : 'Terms of Service & Sales Agreement'}
          </h1>
          <p className="text-xs text-muted-foreground font-mono">
            {tenant.name} • {locale === 'ar' ? 'ساري المفعول لسنة ' : 'Effective Year: '} {currentYear}
          </p>
        </div>

        {/* Localized Content Matrix */}
        <div className="prose prose-sm dark:prose-invert max-w-none text-muted-foreground leading-relaxed space-y-6">
          {locale === 'ar' ? (
            /* Arabic Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">١. الموافقة على الشروط</h2>
                <p>
                  باستخدامك لموقع <strong className="text-foreground">{tenant.name}</strong> أو تقديمك لأي طلب عبر خيار الدفع عند الاستلام أو الشراء الإلكتروني، فإنك تقر وتوافق صراحة على الالتزام بجميع بنود هذه الاتفاقية وسياسات التوصيل المعمول بها لدينا.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٢. شروط وتعهدات الدفع عند الاستلام (COD)</h2>
                <p>
                  نظام الدفع عند الاستلام قائم على الثقة والجدية المتبادلة. عند إدخال طلبك عبر استمارة الشراء:
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li>تتعهد بأن رقم الهاتف والعنوان المدخلين صحيحين ومتاحين للتواصل من قبل فريق التأكيد ومندوب شركة الشحن.</li>
                  <li>تلتزم باستلام الشحنة ودفع المبلغ الإجمالي المحدد بالفاتورة للمندوب فور وصوله إلى عنوانك.</li>
                  <li>رفض استلام الطلب غير المبرر بعد شحنه يتسبب بأضرار لوجستية ويمنحنا الحق في حظر رقم الهاتف من المعاملات المستقبلية.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٣. حقوق الملكية الفكرية والتراخيص الرقمية</h2>
                <p>
                  جميع المواد التعليمية، الدورات المصورة، الملفات القابلة للتحميل، ومفاتيح البرمجيات المتاحة عبر بوابتنا الرقمية هي ملك حصري لـ <strong className="text-foreground">{tenant.name}</strong>. يُمنح المشتري ترخيصًا شخصيًا غير حصري وغير قابل للتحويل، ويُحظر تمامًا إعادة البيع أو المشاركة غير المصرح بها.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٤. دقة الأسعار والعملات</h2>
                <p>
                  تظهر جميع الأسعار بعملة المتجر المعتمدة ({tenant.currency}). نحتفظ بحق تعديل الأسعار أو إنهاء العروض الترويجية والخصومات دون إشعار مسبق مع ضمان تنفيذ الطلبات المعتمدة مسبقًا بالسعر المعلن أثناء الشراء.
                </p>
              </section>
            </>
          ) : locale === 'fr' ? (
            /* French Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Acceptation des Conditions</h2>
                <p>
                  En accédant au site <strong className="text-foreground">{tenant.name}</strong> et en validant une commande, vous acceptez sans réserve les présentes Conditions Générales de Vente régissant nos ventes physiques, paiements à la livraison et produits numériques.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Engagements Liés au Paiement à la Livraison (COD)</h2>
                <p>
                  La sélection du mode de paiement contre-remboursement implique un engagement d&apos;achat ferme. Le client s&apos;engage à être joignable par téléphone pour la confirmation et à régler le montant exact auprès du transporteur lors de la réception du colis.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Biens Numériques et Licences</h2>
                <p>
                  Les cours, fichiers et licences délivrés via notre coffre-fort numérique sont protégés par le droit d&apos;auteur. L&apos;accès concédé est strictement personnel et non transférable. Tout partage ou revente non autorisé entraîne la révocation immédiate du compte.
                </p>
              </section>
            </>
          ) : (
            /* English Default */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Agreement to Terms</h2>
                <p>
                  By browsing <strong className="text-foreground">{tenant.name}</strong>, submitting an order via Cash on Delivery, or completing an online checkout, you agree to be legally bound by these Terms of Service, along with our Privacy Policy and Fulfillment Guidelines.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Cash on Delivery (COD) Commitments</h2>
                <p>
                  Cash on Delivery relies on mutual commercial integrity. By submitting an order through our checkout:
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li>You warrant that all phone numbers and shipping addresses provided are accurate and monitorable.</li>
                  <li>You agree to receive phone/WhatsApp delivery schedule confirmations from our fulfillment team.</li>
                  <li>You commit to pay the final invoiced order balance in full to the courier upon delivery presentation.</li>
                  <li>Arbitrary rejection of dispatched orders may lead to permanent exclusion from our fulfillment network.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Digital Assets, Training & Key Licensing</h2>
                <p>
                  All video lessons, software license keys, guides, and digital deliverables hosted on our student portal are proprietary intellectual property. We grant you a revocable, non-exclusive, single-user license solely for personal or authorized business use. Unauthorized reproduction, torrenting, or redistribution is strictly prohibited.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">4. Pricing, Currencies & Billing</h2>
                <p>
                  All items are quoted in <span className="font-mono text-foreground font-bold">{tenant.currency}</span> unless stated otherwise. We reserve the right to correct typographical pricing errors and cancel orders resulting from inadvertent system inaccuracies.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">5. Limitation of Liability</h2>
                <p>
                  To the maximum extent permitted by applicable law, <strong className="text-foreground">{tenant.name}</strong> shall not be liable for indirect, incidental, or consequential damages resulting from third-party courier delivery delays or external network disruptions.
                </p>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { SupportedLocale } from '@/types/subaccount';

interface RefundPolicyPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata({ params }: RefundPolicyPageProps) {
  const { subaccountSlug, locale } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  const storeName = subaccountRes.data?.name || 'Store';

  const titles: Record<SupportedLocale, string> = {
    en: `Refund & Return Policy | ${storeName}`,
    ar: `سياسة الاسترجاع والاستبدال | ${storeName}`,
    fr: `Politique de Retour et Remboursement | ${storeName}`,
    es: `Política de Devolución y Reembolso | ${storeName}`,
    pt: `Política de Devolução e Reembolso | ${storeName}`,
    it: `Informativa sui Rimborsi e Resi | ${storeName}`,
  };

  return {
    title: titles[locale as SupportedLocale] || titles.en,
  };
}

export default async function RefundPolicyPage({ params }: RefundPolicyPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const currentYear = new Date().getFullYear();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="bg-card border border-border rounded-2xl p-6 sm:p-10 shadow-sm space-y-8">
        <div className="border-b border-border pb-4 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
            {locale === 'ar'
              ? 'سياسة الاسترجاع والاستبدال واسترداد الأموال'
              : locale === 'fr'
              ? 'Politique de Retour, Échange et Remboursement'
              : locale === 'es'
              ? 'Política de Devoluciones y Reembolsos'
              : locale === 'pt'
              ? 'Política de Devoluções e Reembolsos'
              : locale === 'it'
              ? 'Politica di Reso e Rimborso'
              : 'Refund, Return & Exchange Policy'}
          </h1>
          <p className="text-xs text-muted-foreground font-mono">
            {tenant.name} • {locale === 'ar' ? 'ساري المفعول لسنة ' : 'Valid for '} {currentYear}
          </p>
        </div>

        {/* Localized Content Matrix */}
        <div className="prose prose-sm dark:prose-invert max-w-none text-muted-foreground leading-relaxed space-y-6">
          {locale === 'ar' ? (
            /* Arabic Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">١. ضمان الاسترجاع والاستبدال (المنتجات الملموسة)</h2>
                <p>
                  نحن في <strong className="text-foreground">{tenant.name}</strong> نضمن جودة جميع منتجاتنا ونسعى لتحقيق رضاكم الكامل. يحق للعميل طلب استرجاع أو استبدال المنتجات المادية خلال فترة تصل إلى <strong className="text-foreground">١٤ يومًا</strong> من تاريخ استلام الطرد من مندوب التوصيل، بشرط أن يكون المنتج في حالته الأصلية وبغلافه دون استخدام أو تلف.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٢. المنتجات المتضررة أو غير المطابقة</h2>
                <p>
                  في حال وصل المنتج متضررًا أو غير مطابق للمواصفات المطلوبة، نتحمل كامل مصاريف الإرجاع والشحن الجديد، ونرسل لكم بديلاً فوريًا أو نعيد لكم المبلغ المدفوع كاملًا دون أي اقتطاع.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٣. استرداد أموال الدفع عند الاستلام (COD)</h2>
                <p>
                  بالنسبة للطلبات التي تم سدادها نقدًا عند الاستلام، يتم استرداد المبلغ عبر تحويل بنكي مباشر إلى حساب العميل، أو عبر قسيمة شراء برصيد المتجر حسب رغبة العميل، وذلك خلال ٣ إلى ٥ أيام عمل من استلام وفحص المنتج المرتجع بمستودعاتنا.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٤. سياسة المنتجات الرقمية والتراخيص</h2>
                <p>
                  نظرًا للطبيعة الفورية لتحميل البرامج والدورات التدريبية وتوليد مفاتيح التفعيل الرقمية، فإن جميع مبيعات المنتجات الرقمية التي تم تحميلها أو كشف مفتاح ترخيصها تُعد نهائية وغير قابلة للاسترجاع، ما لم يثبت وجود عيب تقني يحول دون عمل الملفات بصورة صحيحة.
                </p>
              </section>
            </>
          ) : locale === 'fr' ? (
            /* French Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Droit de Rétractation et Retours</h2>
                <p>
                  Chez <strong className="text-foreground">{tenant.name}</strong>, vous disposez d&apos;un délai légal de <strong className="text-foreground">14 jours</strong> à compter de la date de livraison pour demander un échange ou un remboursement de vos articles physiques, sous réserve qu&apos;ils soient neufs, non utilisés et dans leur emballage d&apos;origine scellé.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Modalités de Remboursement pour les Commandes COD</h2>
                <p>
                  Pour les commandes réglées en espèces à la livraison, le remboursement est effectué par virement bancaire ou sous forme d&apos;avoir boutique après réception et contrôle de conformité du colis retourné dans nos ateliers de logistique.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Biens Numériques et Formations Téléchargeables</h2>
                <p>
                  Conformément aux dispositions relatives aux contenus numériques dématérialisés dont l&apos;exécution a commencé avec l&apos;accord préalable du consommateur, les formations vidéo, fichiers téléchargeables et clés de licence ne sont pas éligibles au remboursement une fois le téléchargement initié ou la clé révélée.
                </p>
              </section>
            </>
          ) : (
            /* English Default */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. 14-Day Physical Return Guarantee</h2>
                <p>
                  At <strong className="text-foreground">{tenant.name}</strong>, we pride ourselves on exceptional product standards. If you are not satisfied with your physical item, you may request a return or exchange within <strong className="text-foreground">14 days</strong> of parcel receipt. Items must be returned unused, with all security tags intact and in their original commercial packaging.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Defective, Damaged or Incorrect Shipments</h2>
                <p>
                  If you receive an item that is defective, damaged during courier transit, or mismatched from your order invoice, please contact our support team within 48 hours of delivery. We will arrange a free courier pickup and issue an immediate replacement or full refund at no additional shipping expense.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Cash on Delivery (COD) Refund Procedures</h2>
                <p>
                  For orders paid via Cash on Delivery, refunds cannot be paid back in cash through shipping couriers. Refunds are processed securely via direct bank wire transfer to the customer&apos;s verified bank account or credited as an instant store voucher, within 3 to 5 business days following product inspection at our distribution warehouse.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">4. Digital Goods & License Keys Policy</h2>
                <p>
                  Due to the irreversible nature of digital file access and automated software key distribution, purchases of downloadable products, video courses, and digital licenses are non-refundable once the digital asset has been downloaded or the license key has been dispensed, unless there is a verifiable technical defect that our engineering team cannot resolve.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">5. How to Initiate a Return</h2>
                <p>
                  To request a return authorization, please contact our support desk with your original order reference number (e.g. <span className="font-mono text-foreground font-bold">#ORD-XXXX</span>), clear photos of the item condition, and your preferred resolution (exchange or refund).
                </p>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
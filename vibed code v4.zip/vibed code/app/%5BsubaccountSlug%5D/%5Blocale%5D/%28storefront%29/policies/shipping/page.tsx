import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { SupportedLocale } from '@/types/subaccount';

interface ShippingPolicyPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata({ params }: ShippingPolicyPageProps) {
  const { subaccountSlug, locale } = await params;
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  const storeName = subaccountRes.data?.name || 'Store';

  const titles: Record<SupportedLocale, string> = {
    en: `Shipping & Delivery Policy | ${storeName}`,
    ar: `سياسة الشحن والتوصيل | ${storeName}`,
    fr: `Politique d'Expédition et Livraison | ${storeName}`,
    es: `Política de Envío y Entrega | ${storeName}`,
    pt: `Política de Envio e Entrega | ${storeName}`,
    it: `Informativa sulle Spedizioni e Consegne | ${storeName}`,
  };

  return {
    title: titles[locale as SupportedLocale] || titles.en,
  };
}

export default async function ShippingPolicyPage({ params }: ShippingPolicyPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const currentYear = new Date().getFullYear();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="bg-card border border-border rounded-2xl p-6 sm:p-10 shadow-sm space-y-8">
        <div className="border-b border-border pb-4 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
            {locale === 'ar'
              ? 'سياسة الشحن والتسليم'
              : locale === 'fr'
              ? 'Politique d’Expédition et Délais de Livraison'
              : locale === 'es'
              ? 'Política de Envío y Plazos de Entrega'
              : locale === 'pt'
              ? 'Política de Envio e Prazos de Entrega'
              : locale === 'it'
              ? 'Politica di Spedizione e Consegna'
              : 'Shipping, Delivery & Dispatch Policy'}
          </h1>
          <p className="text-xs text-muted-foreground font-mono">
            {tenant.name} • {locale === 'ar' ? 'ساري المفعول لسنة ' : 'Valid for '} {currentYear}
          </p>
        </div>

        {/* Localized Content Matrix */}
        <div className="prose prose-sm dark:prose-invert max-w-none text-muted-foreground leading-relaxed space-y-6">
          {locale === 'ar' ? (
            /* Arabic Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">١. أوقات معالجة الطلبات</h2>
                <p>
                  يتم تأكيد ومعالجة جميع الطلبات الواردة إلى <strong className="text-foreground">{tenant.name}</strong> خلال ٢٤ إلى ٤٨ ساعة من استلامها. يتصل بك فريق خدمة العملاء هاتفيًا أو عبر رسائل الواتساب للتحقق من العنوان وتأكيد جاهزية التوصيل.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٢. مدة التوصيل وتتبع الشحنات (COD)</h2>
                <p>
                  نعمل بشراكة مباشرة مع أفضل شركات الشحن السريع لتأمين وصول طردك إلى باب منزلك أو مقر عملك:
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li>المدن الكبرى والمراكز الرئيسية: خلال ٢٤ إلى ٤٨ ساعة من تاريخ الشحن.</li>
                  <li>المناطق البعيدة والقرى: خلال ٢ إلى ٤ أيام عمل.</li>
                  <li>بإمكانك دائمًا متابعة مسار شحنتك باستخدام رقم البوليصة عبر صفحة تتبع الطلبات المخصصة بمتجرنا.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٣. إجراءات استلام الطرد والدفع نقدًا</h2>
                <p>
                  عند وصول مندوب التوصيل، يرجى تجهيز المبلغ المحدد بالفاتورة نقدًا لتسهيل عملية الاستلام دون تأخير. يحق للزبون فحص الحالة الخارجية للطرد قبل تسليم المبلغ.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">٤. تسليم المنتجات الرقمية والتراخيص</h2>
                <p>
                  بالنسبة للدورات التدريبية والكتب الإلكترونية وتراخيص البرامج، يتم التسليم فوريًا وبشكل تلقائي بمجرد نجاح المعاملة، وتجد جميع روابط التحميل في حسابك ضمن بوابة الطلاب.
                </p>
              </section>
            </>
          ) : locale === 'fr' ? (
            /* French Translation */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Délais de Traitement et de Préparation</h2>
                <p>
                  Toutes les commandes passées sur <strong className="text-foreground">{tenant.name}</strong> sont traitées et préparées dans notre entrepôt dans un délai de 24 à 48 heures ouvrées après validation téléphonique ou par message de confirmation.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Acheminement et Paiement à la Livraison</h2>
                <ul className="list-disc list-inside space-y-1">
                  <li>Villes principales : livraison express sous 24 à 48 heures.</li>
                  <li>Régions périphériques : livraison sous 2 à 4 jours ouvrés.</li>
                  <li>Le montant exact doit être remis en espèces au livreur lors de la présentation du colis à domicile.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Livraison Immédiate des Biens Numériques</h2>
                <p>
                  Les produits dématérialisés (formations vidéo, fichiers téléchargeables et clés de licence logicielle) sont mis à votre disposition instantanément dès la validation de la commande dans votre espace personnel.
                </p>
              </section>
            </>
          ) : (
            /* English Default */
            <>
              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">1. Order Processing Timeframes</h2>
                <p>
                  Orders received at <strong className="text-foreground">{tenant.name}</strong> are verified, packaged, and dispatched from our logistics centers within 24 to 48 business hours. For Cash on Delivery orders, our support team will reach out via call or WhatsApp prior to dispatch to confirm delivery availability.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">2. Courier Transit Times & Waybill Tracking</h2>
                <p>
                  We partner with regional express courier networks to ensure swift and insured parcel handoffs:
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Major Metropolitan Areas: 24 to 48 business hours following dispatch.</li>
                  <li>Regional & Outlying Territories: 2 to 4 business days.</li>
                  <li>Real-time parcel progress can be tracked anytime using your order reference code on our official order tracking page.</li>
                </ul>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">3. Cash on Delivery (COD) Receiving Protocol</h2>
                <p>
                  When selecting Cash on Delivery, customers are kindly requested to prepare the exact invoiced amount in local currency (<span className="font-mono text-foreground font-bold">{tenant.currency}</span>) for the courier upon arrival at the designated delivery address.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">4. Instant Digital Deliveries</h2>
                <p>
                  Digital educational products, video courses, downloadable digital manuals, and software activation keys are delivered electronically with zero shipping latency. Access tokens are generated instantly on your thank-you receipt and stored in your Digital Membership Vault.
                </p>
              </section>

              <section className="space-y-2">
                <h2 className="text-base font-bold text-foreground">5. Failed Delivery Attempts & Rescheduling</h2>
                <p>
                  Our courier partners make up to three attempts to reach you at your phone number. If delivery cannot be completed due to unresponsiveness or incorrect destination details, the parcel will be held at the nearest courier depot for 48 hours before return processing.
                </p>
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
'use client';

import React, { use, useState, useTransition } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCartStore } from '@/stores/cart-store';
import { createCodOrder, CreateCodOrderInput } from '@/server/actions/orders';

interface CartReviewPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export default function CartReviewPage({ params }: CartReviewPageProps) {
  const { subaccountSlug, locale } = use(params);
  const router = useRouter();

  const {
    items,
    updateQuantity,
    removeItem,
    clearCart,
    getSubtotal,
    getTotalCount,
    subaccountId,
  } = useCartStore();

  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'STRIPE'>('COD');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [isPending, startTransition] = useTransition();

  const subtotal = getSubtotal();
  const totalCount = getTotalCount();
  const shippingCost = 0; // Free express shipping
  const totalAmount = subtotal + shippingCost;
  const currency = 'USD';

  const formatPrice = (amount: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
    }).format(amount);

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();

    if (!items.length) {
      setErrorMsg('Your cart is empty.');
      return;
    }

    if (!fullName.trim() || !phone.trim() || !addressLine1.trim() || !city.trim()) {
      setErrorMsg('Please complete all required shipping fields.');
      return;
    }

    const [firstName, ...lastNameParts] = fullName.trim().split(' ');
    setErrorMsg(null);

    startTransition(async () => {
      // 1. Process COD Checkout
      if (paymentMethod === 'COD') {
        const payload: CreateCodOrderInput = {
          subaccountId: subaccountId || 'default',
          subaccountSlug,
          customer: {
            firstName: firstName || 'Customer',
            lastName: lastNameParts.join(' ') || '',
            phone: phone.trim(),
            email: email.trim() || undefined,
            addressLine1: addressLine1.trim(),
            city: city.trim(),
          },
          items: items.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            unitPrice: item.price,
            productTitle: { en: item.title, [locale]: item.title },
          })),
          shippingCost,
          metadata: { checkoutMode: 'CART_ONLINE_REVIEW' },
        };

        const res = await createCodOrder(payload);

        if (res.success && res.data) {
          clearCart();
          router.push(
            `/${subaccountSlug}/${locale}/checkout/success?order=${encodeURIComponent(
              res.data.orderNumber
            )}`
          );
        } else {
          setErrorMsg(res.error || 'Failed to submit order. Please try again.');
        }
      } else {
        // 2. Online Stripe Checkout Session Trigger
        try {
          const res = await fetch('/api/checkout/stripe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              subaccountSlug,
              items,
              customer: { fullName, email, phone, addressLine1, city },
            }),
          });

          const data = await res.json();
          if (data.url) {
            clearCart();
            window.location.href = data.url;
          } else {
            setErrorMsg(data.error || 'Stripe checkout could not be initialized.');
          }
        } catch {
          setErrorMsg('Online payment gateway connection error.');
        }
      }
    });
  };

  if (!items.length) {
    return (
      <div className="container mx-auto px-4 py-20 max-w-xl text-center space-y-4">
        <span className="text-4xl">🛒</span>
        <h1 className="text-xl font-bold text-foreground">Your shopping cart is empty</h1>
        <p className="text-xs text-muted-foreground">
          Looks like you haven&apos;t added any products to your cart yet.
        </p>
        <Link
          href={`/${subaccountSlug}/${locale}`}
          className="inline-block px-5 py-2.5 bg-primary text-primary-foreground font-semibold text-xs rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
        >
          Browse Our Products →
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold text-foreground tracking-tight">
          Review Cart & Checkout
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Verify your item quantities and enter your delivery destination.
        </p>
      </div>

      {errorMsg && (
        <div className="p-3 bg-destructive/10 border border-destructive/20 text-destructive text-xs rounded-lg">
          {errorMsg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Cart Items List */}
        <div className="lg:col-span-7 bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-border">
            <h2 className="text-xs font-bold text-foreground uppercase tracking-wider">
              Selected Items ({totalCount})
            </h2>
            <button
              type="button"
              onClick={clearCart}
              className="text-xs text-destructive hover:underline"
            >
              Clear Cart
            </button>
          </div>

          <div className="divide-y divide-border/60">
            {items.map((item) => (
              <div key={item.id} className="py-4 flex gap-4 items-center">
                {item.image && (
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-16 h-16 rounded-lg object-cover border border-border shrink-0"
                  />
                )}

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-xs text-foreground truncate">
                    {item.title}
                  </h3>
                  <p className="text-xs font-mono text-muted-foreground mt-0.5">
                    {formatPrice(item.price)} each
                  </p>

                  <div className="flex items-center gap-3 mt-2">
                    {/* Stepper */}
                    <div className="flex items-center border border-border rounded bg-muted/30 text-xs">
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="px-2 py-0.5 text-muted-foreground hover:text-foreground"
                      >
                        −
                      </button>
                      <span className="px-2 font-mono font-medium text-foreground">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="px-2 py-0.5 text-muted-foreground hover:text-foreground"
                      >
                        +
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      className="text-[11px] text-muted-foreground hover:text-destructive transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                </div>

                <div className="text-right font-mono font-bold text-xs text-foreground">
                  {formatPrice(item.price * item.quantity)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Checkout Destination Form & Financial Summary */}
        <div className="lg:col-span-5 space-y-6">
          <form
            onSubmit={handleCheckout}
            className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4 text-xs"
          >
            <h2 className="text-xs font-bold text-foreground uppercase tracking-wider border-b border-border pb-2">
              Shipping & Payment Details
            </h2>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="block text-xs font-medium text-foreground">
                Payment Option
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('COD')}
                  className={`p-2.5 border rounded-lg text-center transition-all ${
                    paymentMethod === 'COD'
                      ? 'border-primary ring-2 ring-primary/20 bg-primary/5 text-primary font-bold'
                      : 'border-border bg-background text-foreground'
                  }`}
                >
                  💵 Cash on Delivery
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('STRIPE')}
                  className={`p-2.5 border rounded-lg text-center transition-all ${
                    paymentMethod === 'STRIPE'
                      ? 'border-primary ring-2 ring-primary/20 bg-primary/5 text-primary font-bold'
                      : 'border-border bg-background text-foreground'
                  }`}
                >
                  💳 Credit Card / Online
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Jane Smith"
                className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-foreground mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+1 234 567 8900"
                  className="w-full px-3 py-2 bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-foreground mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="jane@example.com"
                  className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Street Address *
              </label>
              <input
                type="text"
                required
                value={addressLine1}
                onChange={(e) => setAddressLine1(e.target.value)}
                placeholder="123 Ocean Drive, Apt 4B"
                className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                City / Region *
              </label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Casablanca, Madrid, New York..."
                className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            {/* Financial Summary */}
            <div className="pt-3 border-t border-border space-y-1.5 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono text-foreground font-medium">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Express Shipping</span>
                <span className="font-medium text-emerald-600 uppercase text-[11px]">Free</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-foreground pt-2 border-t border-border">
                <span>Total Amount</span>
                <span className="font-mono text-primary text-base">
                  {formatPrice(totalAmount)}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isPending}
              className="w-full py-3.5 px-4 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isPending ? (
                <span className="animate-spin">⟳ Submitting Order...</span>
              ) : paymentMethod === 'COD' ? (
                <span>Confirm Order (Pay on Delivery) →</span>
              ) : (
                <span>Proceed to Secure Card Checkout →</span>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
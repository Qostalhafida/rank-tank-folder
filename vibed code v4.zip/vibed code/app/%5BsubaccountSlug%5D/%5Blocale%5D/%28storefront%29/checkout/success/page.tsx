import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createAdminClient } from '@/lib/supabase/admin';
import { generateDownloadToken } from '@/lib/storage/tokens';
import { MultilingualText } from '@/types/database';
import { DigitalAsset, LicenseKey } from '@/types/digital';

interface CheckoutSuccessPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
  searchParams: Promise<{
    order?: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'Thank You for Your Order',
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function CheckoutSuccessPage({
  params,
  searchParams,
}: CheckoutSuccessPageProps) {
  const { subaccountSlug, locale } = await params;
  const { order: orderQuery } = await searchParams;

  // 1. Resolve Subaccount Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const supabase = createAdminClient();

  // 2. Fetch Order and Attached Items
  let order = null;
  let orderItems: any[] = [];
  const downloadableAssets: { asset: DigitalAsset; downloadToken: string }[] = [];
  let licenseKeys: LicenseKey[] = [];

  if (orderQuery) {
    const { data: orderData } = await supabase
      .from('orders')
      .select(`
        *,
        contacts (
          id,
          first_name,
          last_name,
          email,
          phone
        ),
        order_items (
          id,
          product_id,
          quantity,
          unit_price,
          total_price,
          product_title,
          products (
            type,
            digital_assets (*)
          )
        )
      `)
      .eq('subaccount_id', tenant.id)
      .or(`order_number.eq.${orderQuery},id.eq.${orderQuery}`)
      .maybeSingle();

    if (orderData) {
      order = orderData;
      orderItems = orderData.order_items || [];

      // Check for digital deliverables and generate instant download tokens
      for (const item of orderItems) {
        const productAssets = (item.products as any)?.digital_assets as
          | DigitalAsset[]
          | undefined;

        if (productAssets && productAssets.length > 0) {
          for (const asset of productAssets) {
            if (asset.asset_type === 'FILE') {
              const token = generateDownloadToken({
                subaccount_id: tenant.id,
                order_id: order.id,
                asset_id: asset.id,
                contact_id: order.contact_id,
                max_downloads: asset.download_limit || 0,
                download_count: 0,
              });

              downloadableAssets.push({ asset, downloadToken: token });
            }
          }
        }
      }

      // Query any software keys assigned to this order
      const { data: keysData } = await supabase
        .from('license_keys')
        .select('*')
        .eq('order_id', order.id)
        .eq('subaccount_id', tenant.id);

      licenseKeys = (keysData as unknown as LicenseKey[]) || [];
    }
  }

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: tenant.currency || 'USD',
    }).format(val);

  const shipping = order?.shipping_address as Record<string, any> | null;
  const isCod = order?.payment_method === 'COD';

  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl space-y-8">
      {/* Success Banner */}
      <div className="bg-card border border-border rounded-2xl p-8 sm:p-10 shadow-sm text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 flex items-center justify-center text-3xl mx-auto shadow-sm">
          ✓
        </div>
        <span className="inline-block px-3 py-1 bg-emerald-500/10 text-emerald-600 text-xs font-bold uppercase rounded-full tracking-wider">
          Receipt #{order?.order_number || 'Confirmed'}
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
          Thank you for your purchase!
        </h1>
        <p className="text-xs sm:text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
          {isCod
            ? 'Your order has been recorded. Our team will verify your phone number and schedule courier dispatch.'
            : 'Your payment was approved. If your order contains digital assets, you can download them directly below.'}
        </p>
      </div>

      {/* Instant Digital Deliverables Section */}
      {downloadableAssets.length > 0 && (
        <div className="bg-card border-2 border-primary/30 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-border">
            <span className="text-xl">⚡</span>
            <div>
              <h2 className="text-sm font-bold text-foreground">Instant Digital Downloads</h2>
              <p className="text-xs text-muted-foreground">
                Your purchase grants immediate access. Click below to stream or download your files.
              </p>
            </div>
          </div>

          <div className="divide-y divide-border/60">
            {downloadableAssets.map(({ asset, downloadToken }, idx) => (
              <div
                key={idx}
                className="py-3 flex flex-col sm:flex-row justify-between sm:items-center gap-3"
              >
                <div>
                  <h4 className="text-xs font-bold text-foreground">{asset.file_name}</h4>
                  <p className="text-[11px] text-muted-foreground font-mono">
                    Tokenized Secure Access • Format: {asset.mime_type}
                  </p>
                </div>

                <a
                  href={`/api/digital/download/${downloadToken}`}
                  className="px-4 py-2 bg-primary text-primary-foreground font-bold text-xs rounded-lg hover:bg-primary/90 transition-all shadow-md self-start sm:self-auto flex items-center gap-2"
                >
                  <span>⬇ Instant Download</span>
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* License Keys Section */}
      {licenseKeys.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4">
          <h2 className="text-xs font-bold text-foreground uppercase tracking-wider">
            Your Software License Keys
          </h2>
          <div className="space-y-2">
            {licenseKeys.map((key) => (
              <div
                key={key.id}
                className="p-3 bg-muted/40 border border-border rounded-lg flex items-center justify-between text-xs"
              >
                <span className="font-mono font-bold text-foreground select-all">
                  {key.license_key}
                </span>
                <span className="text-[10px] font-mono text-emerald-600 font-semibold uppercase">
                  Active
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Order Summary Card */}
      {order && (
        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4 text-xs">
          <h3 className="font-bold text-muted-foreground uppercase tracking-wider border-b border-border pb-2">
            Order Receipt Details
          </h3>

          <div className="divide-y divide-border/60">
            {orderItems.map((item) => {
              const titleText =
                typeof item.product_title === 'string'
                  ? item.product_title
                  : (item.product_title as MultilingualText)?.[locale] ||
                    (item.product_title as MultilingualText)?.en ||
                    'Product';

              return (
                <div key={item.id} className="py-2.5 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-foreground">
                      x{item.quantity}
                    </span>
                    <span className="text-foreground font-medium">{titleText}</span>
                  </div>
                  <span className="font-mono font-bold text-foreground">
                    {formatPrice(item.total_price)}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-border space-y-1.5 text-muted-foreground">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-mono text-foreground font-medium">
                {formatPrice(order.subtotal)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Delivery Fee</span>
              <span className="font-medium text-emerald-600 uppercase text-[11px]">Free</span>
            </div>
            <div className="flex justify-between text-sm font-bold text-foreground pt-2 border-t border-border">
              <span>Total Amount {isCod ? '(Pay On Delivery)' : ''}</span>
              <span className="font-mono text-primary text-base">
                {formatPrice(order.total_amount)}
              </span>
            </div>
          </div>

          {shipping && (
            <div className="pt-3 border-t border-border space-y-0.5 text-muted-foreground">
              <span className="block font-semibold text-foreground text-xs mb-1">
                Delivery Destination:
              </span>
              <p className="text-foreground">
                {shipping.firstName} {shipping.lastName} •{' '}
                <span className="font-mono">{shipping.phone}</span>
              </p>
              <p>
                {shipping.addressLine1}
                {shipping.city ? `, ${shipping.city}` : ''}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Navigation Actions */}
      <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
        {order && (
          <Link
            href={`/${subaccountSlug}/${locale}/track?order=${encodeURIComponent(
              order.order_number
            )}`}
            className="py-2.5 px-5 bg-card border border-border text-xs font-semibold rounded-lg hover:bg-muted/50 transition-colors shadow-sm text-center"
          >
            Track Parcel Status
          </Link>
        )}

        <Link
          href={`/${subaccountSlug}/${locale}`}
          className="py-2.5 px-5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-primary/90 transition-all shadow-sm text-center"
        >
          Continue Shopping
        </Link>
      </div>
    </div>
  );
}
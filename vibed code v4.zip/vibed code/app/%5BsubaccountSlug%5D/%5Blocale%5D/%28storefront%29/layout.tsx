import React from 'react';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { CartDrawer } from '@/components/storefront/CartDrawer';
import { SupportedLocale } from '@/types/subaccount';

interface StorefrontLayoutProps {
  children: React.ReactNode;
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

const LOCALE_NAMES: Record<SupportedLocale, string> = {
  en: 'English',
  ar: 'العربية',
  fr: 'Français',
  es: 'Español',
  pt: 'Português',
  it: 'Italiano',
};

export default async function StorefrontLayout({
  children,
  params,
}: StorefrontLayoutProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  const supportedLocales = (tenant.supported_locales as SupportedLocale[]) || [
    'en',
    'ar',
    'fr',
  ];
  const isOnlineOrHybrid = tenant.mode === 'ONLINE' || tenant.mode === 'HYBRID';

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      {/* Top Banner Notice */}
      <div className="bg-primary text-primary-foreground py-1.5 px-4 text-center text-xs font-semibold tracking-wide">
        <span>🚚 Free Express Shipping & Cash on Delivery Available</span>
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur border-b border-border shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          {/* Brand Logo & Name */}
          <Link
            href={`/${subaccountSlug}/${locale}`}
            className="flex items-center gap-2.5 font-bold text-foreground hover:opacity-90 transition-opacity"
          >
            {tenant.theme?.brandLogoUrl ? (
              <img
                src={tenant.theme.brandLogoUrl}
                alt={tenant.name}
                className="h-8 w-auto object-contain"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground font-black text-sm flex items-center justify-center shadow-sm">
                {tenant.name.charAt(0)}
              </div>
            )}
            <span className="text-base font-extrabold tracking-tight">{tenant.name}</span>
          </Link>

          {/* Navigation & Utilities */}
          <div className="flex items-center gap-4">
            <nav className="hidden md:flex items-center gap-5 text-xs font-medium text-muted-foreground">
              <Link
                href={`/${subaccountSlug}/${locale}`}
                className="hover:text-foreground transition-colors"
              >
                Store Home
              </Link>
              <Link
                href={`/${subaccountSlug}/${locale}/track`}
                className="hover:text-foreground transition-colors"
              >
                Track Order
              </Link>
              <Link
                href={`/${subaccountSlug}/${locale}/portal`}
                className="hover:text-foreground transition-colors"
              >
                Student Vault
              </Link>
            </nav>

            {/* Language Selector Dropdown */}
            {supportedLocales.length > 1 && (
              <div className="relative inline-block text-left text-xs">
                <select
                  defaultValue={locale}
                  onChange={(e) => {
                    // Client redirect on language change
                    const targetLocale = e.target.value;
                    const pathWithoutLocale = window.location.pathname.replace(
                      `/${subaccountSlug}/${locale}`,
                      ''
                    );
                    window.location.href = `/${subaccountSlug}/${targetLocale}${pathWithoutLocale}`;
                  }}
                  className="px-2.5 py-1.5 rounded-md bg-muted/50 border border-border text-xs font-medium text-foreground cursor-pointer focus:outline-none"
                >
                  {supportedLocales.map((loc) => (
                    <option key={loc} value={loc}>
                      {LOCALE_NAMES[loc] || loc.toUpperCase()}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Cart Drawer Trigger (Only shown in ONLINE or HYBRID mode) */}
            {isOnlineOrHybrid && (
              <CartDrawer
                subaccountSlug={subaccountSlug}
                locale={locale}
                currency={tenant.currency || 'USD'}
              />
            )}
          </div>
        </div>
      </header>

      {/* Main Page Workspace */}
      <main className="flex-1">{children}</main>

      {/* Storefront Footer */}
      <footer className="border-t border-border bg-card text-muted-foreground py-10">
        <div className="container mx-auto px-4 max-w-6xl space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-xs">
            {/* Store Information */}
            <div className="space-y-2 md:col-span-2">
              <h3 className="font-bold text-foreground text-sm">{tenant.name}</h3>
              <p className="max-w-sm leading-relaxed">
                Premium multi-currency store offering localized e-commerce, instant digital downloads, and risk-free Cash on Delivery.
              </p>
              <div className="pt-2 flex items-center gap-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-muted text-foreground border border-border">
                  Currency: {tenant.currency}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-muted text-foreground border border-border">
                  Mode: {tenant.mode}
                </span>
              </div>
            </div>

            {/* Quick Navigation */}
            <div className="space-y-2">
              <h4 className="font-bold text-foreground uppercase tracking-wider text-[11px]">
                Explore
              </h4>
              <ul className="space-y-1.5">
                <li>
                  <Link href={`/${subaccountSlug}/${locale}`} className="hover:underline">
                    Catalog
                  </Link>
                </li>
                <li>
                  <Link href={`/${subaccountSlug}/${locale}/track`} className="hover:underline">
                    Track Your Parcel
                  </Link>
                </li>
                <li>
                  <Link href={`/${subaccountSlug}/${locale}/portal`} className="hover:underline">
                    Digital Portal
                  </Link>
                </li>
              </ul>
            </div>

            {/* Compliance & Policies */}
            <div className="space-y-2">
              <h4 className="font-bold text-foreground uppercase tracking-wider text-[11px]">
                Compliance & Legal
              </h4>
              <ul className="space-y-1.5">
                <li>
                  <Link href={`/${subaccountSlug}/${locale}/policies/privacy`} className="hover:underline">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href={`/${subaccountSlug}/${locale}/policies/terms`} className="hover:underline">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href={`/${subaccountSlug}/${locale}/policies/shipping`} className="hover:underline">
                    Shipping Policy
                  </Link>
                </li>
                <li>
                  <Link href={`/${subaccountSlug}/${locale}/policies/refunds`} className="hover:underline">
                    Refund & Return Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-border flex flex-col sm:flex-row justify-between items-center text-xs text-muted-foreground gap-2">
            <p>© {new Date().getFullYear()} {tenant.name}. All rights reserved.</p>
            <p className="text-[11px]">Protected by multi-tenant verified checkout engine.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
import React from 'react';
import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createServerClient } from '@/lib/supabase/server';

interface StudentPortalLayoutProps {
  children: React.ReactNode;
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export default async function StudentPortalLayout({
  children,
  params,
}: StudentPortalLayoutProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Tenant Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Validate Authenticated Student Session
  const supabase = await createServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // If unauthenticated, redirect to portal login with return destination
  if (!user) {
    const returnUrl = encodeURIComponent(`/${subaccountSlug}/${locale}/portal`);
    redirect(`/${subaccountSlug}/${locale}/login?returnUrl=${returnUrl}`);
  }

  return (
    <div className="min-h-screen bg-muted/10 flex flex-col font-sans">
      {/* Student Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link
              href={`/${subaccountSlug}/${locale}/portal`}
              className="flex items-center gap-2 font-bold text-foreground hover:opacity-90 transition-opacity"
            >
              {tenant.theme?.brandLogoUrl ? (
                <img
                  src={tenant.theme.brandLogoUrl}
                  alt={tenant.name}
                  className="h-8 w-auto object-contain"
                />
              ) : (
                <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                  {tenant.name.charAt(0)}
                </div>
              )}
              <span className="text-sm font-semibold tracking-tight">{tenant.name} Vault</span>
            </Link>

            <nav className="hidden sm:flex items-center gap-4 text-xs font-medium">
              <Link
                href={`/${subaccountSlug}/${locale}/portal`}
                className="text-foreground hover:text-primary transition-colors py-1"
              >
                My Library
              </Link>
              <Link
                href={`/${subaccountSlug}/${locale}`}
                className="text-muted-foreground hover:text-foreground transition-colors py-1"
              >
                Storefront
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-medium text-foreground truncate max-w-[150px]">
                {user.email}
              </span>
              <span className="text-[10px] text-muted-foreground font-mono">Student Account</span>
            </div>

            <form
              action={async () => {
                'use server';
                const client = await createServerClient();
                await client.auth.signOut();
                redirect(`/${subaccountSlug}/${locale}/login`);
              }}
            >
              <button
                type="submit"
                className="px-3 py-1.5 bg-muted border border-border text-foreground hover:bg-muted/80 text-xs font-medium rounded-md transition-colors"
              >
                Sign Out
              </button>
            </form>
          </div>
        </div>
      </header>

      {/* Main Student Workspace Container */}
      <main className="flex-1 container mx-auto px-4 py-8 max-w-6xl">{children}</main>

      {/* Student Portal Footer */}
      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground bg-card">
        <p>© {new Date().getFullYear()} {tenant.name}. All digital training rights reserved.</p>
      </footer>
    </div>
  );
}
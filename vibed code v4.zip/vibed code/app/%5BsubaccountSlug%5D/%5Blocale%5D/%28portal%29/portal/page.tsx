import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getSubaccount } from '@/server/actions/subaccounts';
import { createServerClient } from '@/lib/supabase/server';
import { generateDownloadToken } from '@/lib/storage/tokens';
import { Course, DigitalAsset, LicenseKey } from '@/types/digital';

interface StudentPortalPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
  }>;
}

export async function generateMetadata() {
  return {
    title: 'My Digital Vault & Library',
  };
}

export default async function StudentPortalPage({ params }: StudentPortalPageProps) {
  const { subaccountSlug, locale } = await params;

  // 1. Resolve Subaccount Context
  const subaccountRes = await getSubaccount(subaccountSlug, 'slug');
  if (!subaccountRes.success || !subaccountRes.data) notFound();
  const tenant = subaccountRes.data;

  // 2. Fetch Authenticated Student
  const supabase = await createServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !user.email) notFound();

  // 3. Resolve Customer Contact ID in CRM
  const { data: contact } = await supabase
    .from('contacts')
    .select('id')
    .eq('subaccount_id', tenant.id)
    .eq('email', user.email.toLowerCase().trim())
    .maybeSingle();

  // 4. Fetch Enrolled Courses
  let courses: Course[] = [];
  let digitalAssetsWithTokens: { asset: DigitalAsset; downloadToken: string; orderId: string }[] = [];
  let licenseKeys: LicenseKey[] = [];

  if (contact) {
    // A. Query Courses linked to tenant
    const { data: coursesData } = await supabase
      .from('courses')
      .select(`
        *,
        lessons (
          id,
          title,
          duration_seconds,
          position
        )
      `)
      .eq('subaccount_id', tenant.id)
      .order('created_at', { ascending: false });

    courses = (coursesData as unknown as Course[]) || [];

    // B. Query Digital File Downloads for this contact's orders
    const { data: ordersWithAssets } = await supabase
      .from('orders')
      .select(`
        id,
        status,
        payment_status,
        order_items (
          product_id,
          products (
            digital_assets (*)
          )
        )
      `)
      .eq('contact_id', contact.id)
      .eq('subaccount_id', tenant.id)
      .neq('status', 'CANCELLED');

    if (ordersWithAssets) {
      for (const order of ordersWithAssets) {
        for (const item of order.order_items || []) {
          const productAssets = (item.products as any)?.digital_assets as DigitalAsset[] | undefined;
          if (productAssets && productAssets.length > 0) {
            for (const asset of productAssets) {
              if (asset.asset_type === 'FILE') {
                const token = generateDownloadToken({
                  subaccount_id: tenant.id,
                  order_id: order.id,
                  asset_id: asset.id,
                  contact_id: contact.id,
                  max_downloads: asset.download_limit || 0,
                  download_count: 0,
                });

                digitalAssetsWithTokens.push({
                  asset,
                  downloadToken: token,
                  orderId: order.id,
                });
              }
            }
          }
        }
      }
    }

    // C. Query Assigned License Keys
    const { data: keysData } = await supabase
      .from('license_keys')
      .select('*')
      .eq('contact_id', contact.id)
      .eq('subaccount_id', tenant.id)
      .eq('status', 'ASSIGNED');

    licenseKeys = (keysData as unknown as LicenseKey[]) || [];
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-10">
      {/* Welcome Banner */}
      <div className="p-6 bg-card border border-border rounded-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight">
            Welcome to Your Digital Vault
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">
            Access your purchased courses, downloadable assets, and software license keys anytime.
          </p>
        </div>
      </div>

      {/* Courses & Training Section */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-foreground flex items-center gap-2">
          <span>🎓</span> Enrolled Courses & Video Programs ({courses.length})
        </h2>

        {courses.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => {
              const firstLessonId = course.lessons?.[0]?.id;
              const lessonCount = course.lessons?.length || 0;

              return (
                <div
                  key={course.id}
                  className="bg-card border border-border rounded-xl overflow-hidden shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow"
                >
                  <div className="aspect-video bg-muted/40 relative">
                    {course.thumbnail_url ? (
                      <img
                        src={course.thumbnail_url}
                        alt={course.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                        Course Media
                      </div>
                    )}
                    <span className="absolute bottom-2 right-2 px-2 py-0.5 bg-background/90 text-foreground font-mono text-[10px] rounded backdrop-blur-sm border border-border/60">
                      {lessonCount} Lessons
                    </span>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1.5">
                      <h3 className="font-bold text-sm text-foreground line-clamp-1">
                        {course.title}
                      </h3>
                      {course.description && (
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {course.description}
                        </p>
                      )}
                    </div>

                    <Link
                      href={
                        firstLessonId
                          ? `/${subaccountSlug}/${locale}/portal/courses/${course.slug}/lessons/${firstLessonId}`
                          : '#'
                      }
                      className="w-full py-2 px-4 bg-primary text-primary-foreground font-semibold text-xs text-center rounded-lg hover:bg-primary/90 transition-colors shadow-sm block"
                    >
                      Resume Learning →
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 border border-dashed border-border rounded-xl text-center text-xs text-muted-foreground bg-muted/10">
            No course enrollments found for this account.
          </div>
        )}
      </div>

      {/* Digital Downloads Section */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-foreground flex items-center gap-2">
          <span>📦</span> File Downloads & Digital Deliverables ({digitalAssetsWithTokens.length})
        </h2>

        {digitalAssetsWithTokens.length > 0 ? (
          <div className="divide-y divide-border border border-border rounded-xl bg-card overflow-hidden shadow-sm">
            {digitalAssetsWithTokens.map(({ asset, downloadToken }, idx) => (
              <div
                key={idx}
                className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold text-base shrink-0">
                    💾
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-semibold text-foreground">
                      {asset.file_name}
                    </h4>
                    <p className="text-[11px] text-muted-foreground font-mono">
                      {formatFileSize(asset.file_size_bytes)} • {asset.mime_type}
                    </p>
                  </div>
                </div>

                <a
                  href={`/api/digital/download/${downloadToken}`}
                  className="py-2 px-4 bg-secondary text-secondary-foreground font-medium text-xs rounded-lg hover:bg-secondary/90 transition-colors self-start sm:self-auto flex items-center gap-1.5"
                >
                  <span>⬇</span> Download File
                </a>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 border border-dashed border-border rounded-xl text-center text-xs text-muted-foreground bg-muted/10">
            No digital file downloads associated with your orders.
          </div>
        )}
      </div>

      {/* Software License Keys Section */}
      {licenseKeys.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-base font-bold text-foreground flex items-center gap-2">
            <span>🔑</span> Software License Keys ({licenseKeys.length})
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {licenseKeys.map((key) => (
              <div
                key={key.id}
                className="p-4 bg-card border border-border rounded-xl space-y-2 shadow-sm"
              >
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
                  Product Key
                </span>
                <div className="p-2.5 bg-muted rounded-md font-mono text-xs font-bold text-foreground border border-border select-all break-all">
                  {key.license_key}
                </div>
                <span className="text-[10px] text-muted-foreground font-mono block">
                  Issued on: {key.assigned_at ? new Date(key.assigned_at).toLocaleDateString() : 'Active'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
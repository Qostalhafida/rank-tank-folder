'use client';

import React, { use, useEffect, useState, useTransition } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Course, Lesson } from '@/types/digital';

interface LessonViewerPageProps {
  params: Promise<{
    subaccountSlug: string;
    locale: string;
    courseSlug: string;
    id: string;
  }>;
}

export default function LessonViewerPage({ params }: LessonViewerPageProps) {
  const { subaccountSlug, locale, courseSlug, id: lessonId } = use(params);
  const router = useRouter();

  const [course, setCourse] = useState<Course | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [completedLessonIds, setCompletedLessonIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPending, startTransition] = useTransition();

  // 1. Fetch Course, Lessons Playlist, and Student Progress
  useEffect(() => {
    const supabase = createClient();

    async function loadLessonData() {
      setLoading(true);

      // Fetch course and its lessons
      const { data: courseData } = await supabase
        .from('courses')
        .select(`
          *,
          lessons (*)
        `)
        .eq('slug', courseSlug)
        .single();

      if (courseData) {
        const sortedLessons = ((courseData.lessons as Lesson[]) || []).sort(
          (a, b) => a.position - b.position
        );

        const loadedCourse: Course = {
          ...courseData,
          lessons: sortedLessons,
        };

        setCourse(loadedCourse);

        const activeLesson = sortedLessons.find((l) => l.id === lessonId);
        setCurrentLesson(activeLesson || sortedLessons[0] || null);

        // Fetch user completion progress
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: contact } = await supabase
            .from('contacts')
            .select('id')
            .eq('email', user.email?.toLowerCase().trim())
            .maybeSingle();

          if (contact) {
            const { data: progress } = await supabase
              .from('lesson_progress')
              .select('lesson_id')
              .eq('contact_id', contact.id)
              .eq('completed', true);

            if (progress) {
              setCompletedLessonIds(progress.map((p) => p.lesson_id));
            }
          }
        }
      }

      setLoading(false);
    }

    loadLessonData();
  }, [courseSlug, lessonId]);

  const handleToggleComplete = () => {
    if (!currentLesson) return;

    const isAlreadyCompleted = completedLessonIds.includes(currentLesson.id);
    const updated = isAlreadyCompleted
      ? completedLessonIds.filter((id) => id !== currentLesson.id)
      : [...completedLessonIds, currentLesson.id];

    setCompletedLessonIds(updated);

    startTransition(async () => {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: contact } = await supabase
        .from('contacts')
        .select('id')
        .eq('email', user.email?.toLowerCase().trim())
        .maybeSingle();

      if (contact) {
        await supabase.from('lesson_progress').upsert(
          {
            contact_id: contact.id,
            lesson_id: currentLesson.id,
            completed: !isAlreadyCompleted,
            completed_at: !isAlreadyCompleted ? new Date().toISOString() : null,
          },
          { onConflict: 'contact_id,lesson_id' }
        );
      }
    });
  };

  if (loading || !course || !currentLesson) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center text-sm text-muted-foreground">
        <span className="animate-spin mr-2">⟳</span> Loading lesson content...
      </div>
    );
  }

  const lessons = course.lessons || [];
  const currentIndex = lessons.findIndex((l) => l.id === currentLesson.id);
  const prevLesson = currentIndex > 0 ? lessons[currentIndex - 1] : null;
  const nextLesson = currentIndex < lessons.length - 1 ? lessons[currentIndex + 1] : null;
  const isCompleted = completedLessonIds.includes(currentLesson.id);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-4 border-b border-border">
        <div>
          <Link
            href={`/${subaccountSlug}/${locale}/portal`}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 mb-1"
          >
            ← Back to Vault
          </Link>
          <h1 className="text-lg font-bold text-foreground">{course.title}</h1>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleToggleComplete}
            disabled={isPending}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 ${
              isCompleted
                ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30'
                : 'bg-card text-foreground border-border hover:bg-muted'
            }`}
          >
            <span>{isCompleted ? '✓ Completed' : '○ Mark as Complete'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Video Player & Markdown Notes */}
        <div className="lg:col-span-8 space-y-6">
          {/* Responsive Video Container */}
          <div className="aspect-video w-full bg-black rounded-xl overflow-hidden shadow-lg border border-border relative flex items-center justify-center">
            {currentLesson.video_url ? (
              <iframe
                src={currentLesson.video_url}
                title={currentLesson.title}
                className="w-full h-full border-none"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className="text-center p-6 text-neutral-400 text-xs">
                <span>📹</span> No streaming video attached to this lesson
              </div>
            )}
          </div>

          {/* Lesson Header & Steppers */}
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 bg-card p-5 border border-border rounded-xl shadow-sm">
            <div>
              <span className="text-[10px] font-bold font-mono uppercase tracking-wider text-primary">
                Lesson {currentIndex + 1} of {lessons.length}
              </span>
              <h2 className="text-base sm:text-lg font-bold text-foreground mt-0.5">
                {currentLesson.title}
              </h2>
            </div>

            {/* Previous & Next Stepper Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              {prevLesson ? (
                <button
                  onClick={() =>
                    router.push(
                      `/${subaccountSlug}/${locale}/portal/courses/${courseSlug}/lessons/${prevLesson.id}`
                    )
                  }
                  className="px-3 py-1.5 bg-muted text-foreground text-xs font-medium rounded-md hover:bg-muted/80 transition-colors"
                >
                  ← Previous
                </button>
              ) : null}

              {nextLesson ? (
                <button
                  onClick={() =>
                    router.push(
                      `/${subaccountSlug}/${locale}/portal/courses/${courseSlug}/lessons/${nextLesson.id}`
                    )
                  }
                  className="px-3 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-md hover:bg-primary/90 transition-colors"
                >
                  Next Lesson →
                </button>
              ) : null}
            </div>
          </div>

          {/* Lesson Notes & Text Content */}
          {currentLesson.content_markdown && (
            <div className="bg-card border border-border p-6 rounded-xl shadow-sm space-y-3">
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                Lesson Material & Notes
              </h3>
              <div className="prose prose-sm dark:prose-invert text-foreground/90 max-w-none whitespace-pre-line leading-relaxed">
                {currentLesson.content_markdown}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Interactive Lesson Playlist Sidebar */}
        <div className="lg:col-span-4 bg-card border border-border rounded-xl p-4 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-border">
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider">
              Course Playlist
            </h3>
            <span className="text-xs font-mono text-muted-foreground">
              {completedLessonIds.length}/{lessons.length} done
            </span>
          </div>

          {/* Lessons List */}
          <div className="space-y-1 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
            {lessons.map((lesson, idx) => {
              const isActive = lesson.id === currentLesson.id;
              const isItemCompleted = completedLessonIds.includes(lesson.id);

              return (
                <Link
                  key={lesson.id}
                  href={`/${subaccountSlug}/${locale}/portal/courses/${courseSlug}/lessons/${lesson.id}`}
                  className={`w-full p-2.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                    isActive
                      ? 'bg-primary text-primary-foreground font-semibold shadow-sm'
                      : 'hover:bg-muted/50 text-foreground'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 pr-2">
                    <span
                      className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] shrink-0 ${
                        isItemCompleted
                          ? isActive
                            ? 'bg-white text-primary font-bold'
                            : 'bg-emerald-500 text-white font-bold'
                          : isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {isItemCompleted ? '✓' : idx + 1}
                    </span>
                    <span className="truncate">{lesson.title}</span>
                  </div>

                  {lesson.duration_seconds > 0 && (
                    <span
                      className={`text-[10px] font-mono shrink-0 ${
                        isActive ? 'text-primary-foreground/80' : 'text-muted-foreground'
                      }`}
                    >
                      {formatDuration(lesson.duration_seconds)}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
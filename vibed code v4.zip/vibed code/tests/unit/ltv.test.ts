import { describe, it, expect } from 'vitest';

/**
 * Pure business logic calculation engine for customer LTV and order rollups.
 */
export interface OrderMetricsSnapshot {
  totalAmount: number;
  status: 'PENDING' | 'CONFIRMED' | 'DISPATCHED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED';
  paymentStatus: 'UNPAID' | 'PAID' | 'REFUNDED';
  refundedAmount?: number;
}

export function computeCustomerLtvRollup(
  orders: OrderMetricsSnapshot[]
): { lifetimeValue: number; ordersCount: number } {
  let lifetimeValue = 0;
  let ordersCount = 0;

  for (const order of orders) {
    // Exclude cancelled and returned uncollected orders
    if (order.status === 'CANCELLED' || order.status === 'RETURNED') {
      continue;
    }

    ordersCount += 1;

    if (order.paymentStatus === 'REFUNDED') {
      const net = Math.max(0, order.totalAmount - (order.refundedAmount ?? order.totalAmount));
      lifetimeValue += net;
    } else {
      lifetimeValue += order.totalAmount;
    }
  }

  // Prevent floating-point drift (e.g. 0.1 + 0.2 = 0.30000000000000004)
  const roundedLtv = Math.round(lifetimeValue * 100) / 100;

  return {
    lifetimeValue: roundedLtv,
    ordersCount,
  };
}

export function applyIncrementalOrderToLtv(
  currentLtv: number,
  currentOrdersCount: number,
  newOrderTotal: number
): { nextLtv: number; nextOrdersCount: number } {
  const nextLtv = Math.round((currentLtv + newOrderTotal) * 100) / 100;
  return {
    nextLtv,
    nextOrdersCount: currentOrdersCount + 1,
  };
}

export function applyUpsellToLtv(
  currentLtv: number,
  upsellAmount: number
): number {
  return Math.round((currentLtv + upsellAmount) * 100) / 100;
}

describe('Customer Lifetime Value (LTV) & Order Rollup Engine', () => {
  it('should initialize a newly captured contact with 0 LTV and 0 orders', () => {
    const metrics = computeCustomerLtvRollup([]);
    expect(metrics.lifetimeValue).toBe(0);
    expect(metrics.ordersCount).toBe(0);
  });

  it('should accurately calculate LTV for multiple confirmed and delivered orders', () => {
    const orders: OrderMetricsSnapshot[] = [
      { totalAmount: 49.99, status: 'DELIVERED', paymentStatus: 'PAID' },
      { totalAmount: 120.0, status: 'CONFIRMED', paymentStatus: 'UNPAID' }, // Valid COD pending collection
      { totalAmount: 35.5, status: 'DISPATCHED', paymentStatus: 'UNPAID' },
    ];

    const metrics = computeCustomerLtvRollup(orders);
    expect(metrics.ordersCount).toBe(3);
    expect(metrics.lifetimeValue).toBe(205.49);
  });

  it('should exclude CANCELLED and RETURNED orders from LTV and order count', () => {
    const orders: OrderMetricsSnapshot[] = [
      { totalAmount: 150.0, status: 'DELIVERED', paymentStatus: 'PAID' },
      { totalAmount: 85.0, status: 'CANCELLED', paymentStatus: 'UNPAID' },
      { totalAmount: 40.0, status: 'RETURNED', paymentStatus: 'UNPAID' },
    ];

    const metrics = computeCustomerLtvRollup(orders);
    expect(metrics.ordersCount).toBe(1);
    expect(metrics.lifetimeValue).toBe(150.0);
  });

  it('should handle partial and full refunds gracefully', () => {
    const orders: OrderMetricsSnapshot[] = [
      { totalAmount: 100.0, status: 'CONFIRMED', paymentStatus: 'REFUNDED', refundedAmount: 100.0 }, // Fully refunded
      { totalAmount: 200.0, status: 'CONFIRMED', paymentStatus: 'REFUNDED', refundedAmount: 50.0 },  // Partial refund: $150 retained
    ];

    const metrics = computeCustomerLtvRollup(orders);
    expect(metrics.ordersCount).toBe(2);
    expect(metrics.lifetimeValue).toBe(150.0);
  });

  it('should correctly increment LTV when a 1-click post-purchase upsell is attached to an order', () => {
    const initialLtv = 59.99;
    const upsellCost = 24.5;

    const nextLtv = applyUpsellToLtv(initialLtv, upsellCost);

    // Order count stays the same (item added to current order), but LTV increases
    expect(nextLtv).toBe(84.49);
  });

  it('should prevent floating-point arithmetic precision issues', () => {
    // 19.99 + 10.01 + 0.1 + 0.2
    const orders: OrderMetricsSnapshot[] = [
      { totalAmount: 19.99, status: 'DELIVERED', paymentStatus: 'PAID' },
      { totalAmount: 10.01, status: 'DELIVERED', paymentStatus: 'PAID' },
      { totalAmount: 0.1, status: 'DELIVERED', paymentStatus: 'PAID' },
      { totalAmount: 0.2, status: 'DELIVERED', paymentStatus: 'PAID' },
    ];

    const metrics = computeCustomerLtvRollup(orders);
    expect(metrics.lifetimeValue).toBe(30.3);
  });
});
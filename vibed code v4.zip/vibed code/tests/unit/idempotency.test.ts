import { describe, it, expect, vi, beforeEach } from 'vitest';
import { IdempotencyLedger } from '@/lib/idempotency/ledger';
import { IdempotencyConflictError } from '@/types/idempotency';
import { createAdminClient } from '@/lib/supabase/admin';

// Mock the Supabase elevated admin client
vi.mock('@/lib/supabase/admin', () => ({
  createAdminClient: vi.fn(),
}));

describe('IdempotencyLedger Unit Tests', () => {
  let mockSupabase: any;
  let inMemoryDb: Map<string, any>;

  beforeEach(() => {
    vi.clearAllMocks();
    inMemoryDb = new Map();

    mockSupabase = {
      from: vi.fn().mockReturnValue({
        select: vi.fn().mockReturnThis(),
        insert: vi.fn().mockImplementation((payload) => {
          if (inMemoryDb.has(payload.key)) {
            return Promise.resolve({
              data: null,
              error: { code: '23505', message: 'duplicate key value violates unique constraint' },
            });
          }
          const record = { id: `id_${Date.now()}`, ...payload };
          inMemoryDb.set(payload.key, record);
          return Promise.resolve({ data: record, error: null });
        }),
        update: vi.fn().mockImplementation((updates) => ({
          eq: vi.fn().mockImplementation((col, val) => {
            const keyToFind = col === 'key' ? val : Array.from(inMemoryDb.entries()).find(([_, v]) => v.id === val)?.[0];
            if (keyToFind && inMemoryDb.has(keyToFind)) {
              const current = inMemoryDb.get(keyToFind);
              const updated = { ...current, ...updates };
              inMemoryDb.set(keyToFind, updated);
              return Promise.resolve({ data: updated, error: null });
            }
            return Promise.resolve({ data: null, error: { message: 'Row not found' } });
          }),
        })),
        eq: vi.fn().mockImplementation((col, val) => ({
          maybeSingle: vi.fn().mockImplementation(() => {
            const record = inMemoryDb.get(val);
            return Promise.resolve({ data: record || null, error: null });
          }),
        })),
      }),
    };

    (createAdminClient as any).mockReturnValue(mockSupabase);
  });

  it('should acquire lock for a brand new idempotency key', async () => {
    const key = 'checkout_order_test_1';
    const result = await IdempotencyLedger.acquireLock(key);

    expect(result.acquired).toBe(true);
    expect(result.cachedData).toBeUndefined();

    const stored = inMemoryDb.get(key);
    expect(stored).toBeDefined();
    expect(stored.status).toBe('PROCESSING');
  });

  it('should return cached data if key is already RESOLVED', async () => {
    const key = 'checkout_order_resolved_key';
    const payload = { orderId: 'ord_123', totalAmount: 49.99 };

    // Seed resolved record
    inMemoryDb.set(key, {
      id: 'uuid_1',
      key,
      status: 'RESOLVED',
      response_payload: payload,
      locked_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 86400000).toISOString(),
    });

    const result = await IdempotencyLedger.acquireLock(key);

    expect(result.acquired).toBe(false);
    expect(result.cachedData).toEqual(payload);
  });

  it('should throw IdempotencyConflictError if another worker is currently PROCESSING the key', async () => {
    const key = 'concurrent_request_key';

    // Seed active lock
    inMemoryDb.set(key, {
      id: 'uuid_2',
      key,
      status: 'PROCESSING',
      response_payload: null,
      locked_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 120000).toISOString(), // active for next 2 minutes
    });

    await expect(IdempotencyLedger.acquireLock(key)).rejects.toThrow(IdempotencyConflictError);
  });

  it('should re-acquire lock if previous lock expired', async () => {
    const key = 'expired_lock_key';

    // Seed expired lock from 5 minutes ago
    inMemoryDb.set(key, {
      id: 'uuid_3',
      key,
      status: 'PROCESSING',
      response_payload: null,
      locked_at: new Date(Date.now() - 300000).toISOString(),
      expires_at: new Date(Date.now() - 1000).toISOString(),
    });

    const result = await IdempotencyLedger.acquireLock(key);
    expect(result.acquired).toBe(true);

    const updated = inMemoryDb.get(key);
    expect(new Date(updated.expires_at).getTime()).toBeGreaterThan(Date.now());
  });

  it('execute wrapper should run operation once, cache result, and avoid second execution', async () => {
    const key = 'execute_wrapper_test_key';
    const operation = vi.fn().mockResolvedValue({ success: true, trackingCode: 'TRK-987' });

    // First call: executes operation
    const firstCall = await IdempotencyLedger.execute(key, operation);
    expect(firstCall).toEqual({ success: true, trackingCode: 'TRK-987' });
    expect(operation).toHaveBeenCalledTimes(1);

    // Second call: returns cached result without running operation
    const secondCall = await IdempotencyLedger.execute(key, operation);
    expect(secondCall).toEqual({ success: true, trackingCode: 'TRK-987' });
    expect(operation).toHaveBeenCalledTimes(1);
  });

  it('should release lock to FAILED status when operation throws an unexpected error', async () => {
    const key = 'failing_operation_key';
    const faultyOperation = vi.fn().mockRejectedValue(new Error('Gateway timeout'));

    await expect(IdempotencyLedger.execute(key, faultyOperation)).rejects.toThrow('Gateway timeout');

    const stored = inMemoryDb.get(key);
    expect(stored.status).toBe('FAILED');
  });
});
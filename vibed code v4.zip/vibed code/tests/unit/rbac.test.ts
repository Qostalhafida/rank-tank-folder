import { describe, it, expect } from 'vitest';
import {
  hasPermission,
  hasAnyPermission,
  hasAllPermissions,
  getPermissionsForRole,
  ALL_PERMISSIONS,
} from '@/lib/auth/permissions';
import { UserRole, PermissionAction } from '@/types/rbac';

describe('RBAC Permission Matrix & Authorization System', () => {
  describe('AGENCY_SUPER_ADMIN Role', () => {
    const role: UserRole = 'AGENCY_SUPER_ADMIN';

    it('should possess all defined platform permissions', () => {
      const permissions = getPermissionsForRole(role);
      expect(permissions).toEqual(ALL_PERMISSIONS);
      expect(hasPermission(role, 'agency:manage_all')).toBe(true);
      expect(hasPermission(role, 'contacts:delete')).toBe(true);
      expect(hasPermission(role, 'settings:domains')).toBe(true);
    });

    it('should satisfy hasAllPermissions for any combination of permissions', () => {
      const checkActions: PermissionAction[] = [
        'agency:manage_all',
        'orders:write',
        'pipelines:move_stage',
        'workflows:execute',
      ];
      expect(hasAllPermissions(role, checkActions)).toBe(true);
    });
  });

  describe('AGENCY_ADMIN Role', () => {
    const role: UserRole = 'AGENCY_ADMIN';

    it('should have all permissions except agency:manage_all', () => {
      expect(hasPermission(role, 'agency:manage_all')).toBe(false);
      expect(hasPermission(role, 'contacts:read')).toBe(true);
      expect(hasPermission(role, 'orders:update_status')).toBe(true);
      expect(hasPermission(role, 'settings:domains')).toBe(true);
    });
  });

  describe('SUBACCOUNT_OWNER Role', () => {
    const role: UserRole = 'SUBACCOUNT_OWNER';

    it('should possess comprehensive subaccount operational permissions', () => {
      expect(hasPermission(role, 'contacts:write')).toBe(true);
      expect(hasPermission(role, 'contacts:delete')).toBe(true);
      expect(hasPermission(role, 'pipelines:move_stage')).toBe(true);
      expect(hasPermission(role, 'orders:print_waybills')).toBe(true);
      expect(hasPermission(role, 'team:manage')).toBe(true);
      expect(hasPermission(role, 'settings:domains')).toBe(true);
    });

    it('must not possess agency-level root management permissions', () => {
      expect(hasPermission(role, 'agency:manage_all')).toBe(false);
    });
  });

  describe('SUBACCOUNT_AGENT Role', () => {
    const role: UserRole = 'SUBACCOUNT_AGENT';

    it('should be permitted to handle CRM, pipelines, bookings, and order fulfillment', () => {
      expect(hasPermission(role, 'contacts:read')).toBe(true);
      expect(hasPermission(role, 'contacts:write')).toBe(true);
      expect(hasPermission(role, 'pipelines:move_stage')).toBe(true);
      expect(hasPermission(role, 'orders:update_status')).toBe(true);
      expect(hasPermission(role, 'orders:print_waybills')).toBe(true);
      expect(hasPermission(role, 'booking:read')).toBe(true);
      expect(hasPermission(role, 'booking:write')).toBe(true);
    });

    it('must not be permitted to manage team, delete deals, or configure custom domains', () => {
      expect(hasPermission(role, 'team:manage')).toBe(false);
      expect(hasPermission(role, 'pipelines:delete')).toBe(false);
      expect(hasPermission(role, 'contacts:delete')).toBe(false);
      expect(hasPermission(role, 'settings:domains')).toBe(false);
      expect(hasPermission(role, 'settings:webhooks')).toBe(false);
    });
  });

  describe('SUBACCOUNT_STAFF Role', () => {
    const role: UserRole = 'SUBACCOUNT_STAFF';

    it('should be restricted strictly to operational inspection and thermal waybill printing', () => {
      expect(hasPermission(role, 'orders:read')).toBe(true);
      expect(hasPermission(role, 'orders:update_status')).toBe(true);
      expect(hasPermission(role, 'orders:print_waybills')).toBe(true);
      expect(hasPermission(role, 'contacts:read')).toBe(true);
    });

    it('must be denied access to write contacts, modify pipelines, or trigger workflows', () => {
      expect(hasPermission(role, 'contacts:write')).toBe(false);
      expect(hasPermission(role, 'pipelines:move_stage')).toBe(false);
      expect(hasPermission(role, 'workflows:write')).toBe(false);
      expect(hasPermission(role, 'team:manage')).toBe(false);
    });
  });

  describe('Utility Helper Functions', () => {
    it('hasAnyPermission should return true if at least one permission matches', () => {
      const role: UserRole = 'SUBACCOUNT_STAFF';
      const actions: PermissionAction[] = ['team:manage', 'settings:domains', 'orders:print_waybills'];
      expect(hasAnyPermission(role, actions)).toBe(true);
    });

    it('hasAnyPermission should return false when no permissions match', () => {
      const role: UserRole = 'SUBACCOUNT_STAFF';
      const actions: PermissionAction[] = ['team:manage', 'settings:domains', 'workflows:write'];
      expect(hasAnyPermission(role, actions)).toBe(false);
    });

    it('hasAllPermissions should return false if any single permission is lacking', () => {
      const role: UserRole = 'SUBACCOUNT_AGENT';
      const actions: PermissionAction[] = ['contacts:read', 'orders:read', 'team:manage'];
      expect(hasAllPermissions(role, actions)).toBe(false);
    });

    it('should safely handle non-existent roles gracefully', () => {
      // @ts-expect-error Testing invalid runtime input
      expect(hasPermission('UNKNOWN_ROLE', 'contacts:read')).toBe(false);
      // @ts-expect-error Testing invalid runtime input
      expect(getPermissionsForRole('UNKNOWN_ROLE')).toEqual([]);
    });
  });
});
import { test, expect } from '@playwright/test';

test.describe('Kanban Optimistic Concurrency Control (OCC) & Presence Collisions', () => {
  test('should reject stale concurrent stage moves and roll back optimistic state', async ({
    browser,
  }) => {
    // 1. Create two isolated browser contexts simulating two concurrent team operators
    const contextA = await browser.newContext();
    const contextB = await browser.newContext();

    const pageA = await contextA.newPage();
    const pageB = await contextB.newPage();

    const pipelineUrl = '/tenant-demo/en/admin/pipelines';

    // Mock initial pipeline state for both operators: 1 deal in Stage 1 at version 1
    const initialPipelinePayload = {
      id: 'pipeline-1',
      name: 'Default Sales Pipeline',
      stages: [
        {
          id: 'stage-1',
          name: 'New Inquiries',
          color: '#3b82f6',
          opportunities: [
            {
              id: 'deal-101',
              title: 'Enterprise Software Deal',
              value: 5000,
              currency: 'USD',
              stage_id: 'stage-1',
              position: 0,
              version: 1, // OCC Version 1
            },
          ],
        },
        {
          id: 'stage-2',
          name: 'Order Confirmed',
          color: '#8b5cf6',
          opportunities: [],
        },
        {
          id: 'stage-3',
          name: 'Delivered / Won',
          color: '#10b981',
          opportunities: [],
        },
      ],
    };

    // Intercept Server Action pipeline reads
    await pageA.route('**/server/actions/pipelines*', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: initialPipelinePayload }),
      });
    });

    await pageB.route('**/server/actions/pipelines*', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, data: initialPipelinePayload }),
      });
    });

    // 2. Both operators load the Kanban Board
    await pageA.goto(pipelineUrl);
    await pageB.goto(pipelineUrl);

    // Verify Deal Card 101 is visible at version v1 on both screens
    const dealCardA = pageA.locator('text=Enterprise Software Deal');
    const dealCardB = pageB.locator('text=Enterprise Software Deal');

    await expect(dealCardA).toBeVisible();
    await expect(dealCardB).toBeVisible();
    await expect(pageA.locator('text=v1')).toBeVisible();
    await expect(pageB.locator('text=v1')).toBeVisible();

    // 3. Operator A moves Deal from Stage 1 to Stage 2 (Expected Version 1 -> Version 2)
    // Mock successful OCC update on server for Operator A
    await pageA.route('**/moveOpportunityStage*', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          data: {
            id: 'deal-101',
            stage_id: 'stage-2',
            position: 0,
            version: 2, // Version bumped to 2
          },
        }),
      });
    });

    const stage2DropTargetA = pageA.locator('text=Order Confirmed').locator('xpath=ancestor::div[contains(@class, "w-80")]');
    await dealCardA.dragTo(stage2DropTargetA);

    // Operator A's board confirms move and updates badge to v2
    await expect(pageA.locator('text=v2')).toBeVisible();

    // 4. Operator B (holding stale version 1) attempts to move the same deal to Stage 3
    // The server OCC guard detects version mismatch (DB is at v2, but Operator B passed expectedVersion: 1)
    await pageB.route('**/moveOpportunityStage*', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: false,
          isConflict: true,
          error:
            'Concurrent edit detected: This deal was updated by another team member. The board has been refreshed.',
        }),
      });
    });

    const stage3DropTargetB = pageB.locator('text=Delivered / Won').locator('xpath=ancestor::div[contains(@class, "w-80")]');
    await dealCardB.dragTo(stage3DropTargetB);

    // 5. Verify Operator B receives the OCC conflict alert and rolls back the deal to its initial stage
    const conflictBanner = pageB.locator('text=Concurrent edit detected');
    await expect(conflictBanner).toBeVisible();

    // The deal must roll back out of Stage 3 and remain in Stage 1 on Operator B's view
    const stage3Column = pageB.locator('text=Delivered / Won').locator('xpath=ancestor::div[contains(@class, "w-80")]');
    await expect(stage3Column.locator('text=Enterprise Software Deal')).not.toBeVisible();

    // Clean up contexts
    await contextA.close();
    await contextB.close();
  });
});
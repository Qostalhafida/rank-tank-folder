'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { requirePermission } from '@/lib/auth/rbac';
import { ActionResponse } from '@/server/actions/contacts';
import {
  Workflow,
  WorkflowCanvasEdge,
  WorkflowCanvasNode,
} from '@/types/workflows';
import { Json } from '@/types/database';

export interface SaveWorkflowInput {
  id?: string;
  name: string;
  is_active?: boolean;
  nodes: WorkflowCanvasNode[];
  edges: WorkflowCanvasEdge[];
}

/**
 * Retrieves all visual automation workflows for a subaccount.
 */
export async function getWorkflows(
  subaccountId: string
): Promise<ActionResponse<Workflow[]>> {
  try {
    await requirePermission(subaccountId, 'workflows:read');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('workflows')
      .select('*')
      .eq('subaccount_id', subaccountId)
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);

    const workflows: Workflow[] = (data || []).map((w: any) => ({
      ...w,
      nodes: (w.nodes as WorkflowCanvasNode[]) || [],
      edges: (w.edges as WorkflowCanvasEdge[]) || [],
    }));

    return { success: true, data: workflows };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve workflows',
    };
  }
}

/**
 * Retrieves a single workflow by ID.
 */
export async function getWorkflowById(
  subaccountId: string,
  workflowId: string
): Promise<ActionResponse<Workflow>> {
  try {
    await requirePermission(subaccountId, 'workflows:read');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('workflows')
      .select('*')
      .eq('id', workflowId)
      .eq('subaccount_id', subaccountId)
      .single();

    if (error || !data) {
      throw new Error(error?.message || 'Workflow not found');
    }

    const workflow: Workflow = {
      ...data,
      nodes: (data.nodes as WorkflowCanvasNode[]) || [],
      edges: (data.edges as WorkflowCanvasEdge[]) || [],
    };

    return { success: true, data: workflow };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve workflow',
    };
  }
}

/**
 * Saves, creates, or updates visual canvas automation nodes and edges.
 */
export async function saveWorkflow(
  subaccountId: string,
  input: SaveWorkflowInput
): Promise<ActionResponse<Workflow>> {
  try {
    await requirePermission(subaccountId, 'workflows:write');
    const supabase = await createServerClient();

    const nodesJson = input.nodes as unknown as Json;
    const edgesJson = input.edges as unknown as Json;

    if (input.id) {
      // Update existing workflow
      const { data, error } = await supabase
        .from('workflows')
        .update({
          name: input.name.trim(),
          is_active: input.is_active ?? false,
          nodes: nodesJson,
          edges: edgesJson,
          updated_at: new Date().toISOString(),
        })
        .eq('id', input.id)
        .eq('subaccount_id', subaccountId)
        .select('*')
        .single();

      if (error) throw new Error(error.message);

      revalidatePath(`/[subaccountSlug]/admin/workflows`, 'page');

      return {
        success: true,
        data: {
          ...data,
          nodes: data.nodes as WorkflowCanvasNode[],
          edges: data.edges as WorkflowCanvasEdge[],
        },
      };
    } else {
      // Create new workflow
      const { data, error } = await supabase
        .from('workflows')
        .insert({
          subaccount_id: subaccountId,
          name: input.name.trim(),
          is_active: input.is_active ?? false,
          nodes: nodesJson,
          edges: edgesJson,
        })
        .select('*')
        .single();

      if (error) throw new Error(error.message);

      revalidatePath(`/[subaccountSlug]/admin/workflows`, 'page');

      return {
        success: true,
        data: {
          ...data,
          nodes: data.nodes as WorkflowCanvasNode[],
          edges: data.edges as WorkflowCanvasEdge[],
        },
      };
    }
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to save workflow',
    };
  }
}

/**
 * Activates or pauses an automation workflow runner.
 */
export async function toggleWorkflowStatus(
  subaccountId: string,
  workflowId: string,
  isActive: boolean
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'workflows:write');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('workflows')
      .update({
        is_active: isActive,
        updated_at: new Date().toISOString(),
      })
      .eq('id', workflowId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/workflows`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to change workflow status',
    };
  }
}

/**
 * Deletes an automation workflow.
 */
export async function deleteWorkflow(
  subaccountId: string,
  workflowId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'workflows:write');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('workflows')
      .delete()
      .eq('id', workflowId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/workflows`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete workflow',
    };
  }
}
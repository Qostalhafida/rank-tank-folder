'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { requirePermission } from '@/lib/auth/rbac';
import { ActionResponse } from '@/server/actions/contacts';
import { Contact } from '@/types/crm';

export interface CaptureLeadInput {
  subaccountId: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  email?: string;
  sourceUrl?: string;
  funnelSlug?: string;
  productIntent?: {
    productId: string;
    productTitle: string;
    price: number;
    quantity: number;
  };
}

export interface AbandonedLeadRecord {
  id: string;
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  email: string | null;
  city: string | null;
  created_at: string;
  updated_at: string;
  product_intent?: CaptureLeadInput['productIntent'];
  funnel_slug?: string;
}

/**
 * Public action: Captures incomplete form fields on input blur.
 * Powers automated abandoned-form recovery workflows before final order submission.
 */
export async function capturePartialLead(
  input: CaptureLeadInput
): Promise<ActionResponse<{ leadId: string }>> {
  try {
    // Avoid saving empty blur events
    if (!input.phone && !input.email) {
      return { success: false, error: 'Phone or email required for lead capture' };
    }

    const supabase = createAdminClient();
    const normalizedPhone = input.phone?.replace(/[\s-]/g, '').trim() || null;
    const normalizedEmail = input.email?.toLowerCase().trim() || null;

    // 1. Check if contact already exists by phone or email
    let query = supabase
      .from('contacts')
      .select('id, first_name, last_name')
      .eq('subaccount_id', input.subaccountId);

    if (normalizedPhone) {
      query = query.eq('phone', normalizedPhone);
    } else if (normalizedEmail) {
      query = query.eq('email', normalizedEmail);
    }

    const { data: existingContact } = await query.maybeSingle();

    let leadContactId: string;

    if (existingContact) {
      leadContactId = existingContact.id;
      // Enrich contact profile with any new information captured
      await supabase
        .from('contacts')
        .update({
          ...(input.firstName && !existingContact.first_name ? { first_name: input.firstName } : {}),
          ...(input.lastName && !existingContact.last_name ? { last_name: input.lastName } : {}),
          ...(normalizedEmail ? { email: normalizedEmail } : {}),
          updated_at: new Date().toISOString(),
        })
        .eq('id', leadContactId);
    } else {
      const { data: newContact, error: insertError } = await supabase
        .from('contacts')
        .insert({
          subaccount_id: input.subaccountId,
          first_name: input.firstName?.trim() || null,
          last_name: input.lastName?.trim() || null,
          phone: normalizedPhone,
          email: normalizedEmail,
          lifetime_value: 0,
          orders_count: 0,
        })
        .select('id')
        .single();

      if (insertError || !newContact) {
        throw new Error(`Failed to initialize lead contact: ${insertError?.message}`);
      }
      leadContactId = newContact.id;
    }

    // 2. Ensure default "Abandoned Lead" tag exists and attach it
    const tagColor = '#f97316'; // Orange indicator
    const tagName = 'Abandoned Checkout';

    let { data: leadTag } = await supabase
      .from('tags')
      .select('id')
      .eq('subaccount_id', input.subaccountId)
      .eq('name', tagName)
      .maybeSingle();

    if (!leadTag) {
      const { data: createdTag } = await supabase
        .from('tags')
        .insert({
          subaccount_id: input.subaccountId,
          name: tagName,
          color: tagColor,
        })
        .select('id')
        .single();
      leadTag = createdTag;
    }

    if (leadTag) {
      await supabase
        .from('contact_tags')
        .upsert(
          {
            contact_id: leadContactId,
            tag_id: leadTag.id,
            subaccount_id: input.subaccountId,
          },
          { onConflict: 'contact_id,tag_id', ignoreDuplicates: true }
        );
    }

    return { success: true, data: { leadId: leadContactId } };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to capture partial lead',
    };
  }
}

/**
 * Admin action: Retrieves contacts tagged as abandoned leads with zero completed orders.
 */
export async function getAbandonedLeads(
  subaccountId: string,
  options: { page?: number; limit?: number } = {}
): Promise<ActionResponse<{ leads: Contact[]; totalCount: number }>> {
  try {
    await requirePermission(subaccountId, 'contacts:read');
    const supabase = await createServerClient();

    const page = options.page ?? 1;
    const limit = options.limit ?? 25;
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    const { data, count, error } = await supabase
      .from('contacts')
      .select(
        `
        *,
        contact_tags!inner (
          tags!inner (
            name,
            color
          )
        )
      `,
        { count: 'exact' }
      )
      .eq('subaccount_id', subaccountId)
      .eq('orders_count', 0)
      .order('updated_at', { ascending: false })
      .range(from, to);

    if (error) throw new Error(error.message);

    const formattedLeads: Contact[] = (data || []).map((row: any) => ({
      ...row,
      tags: row.contact_tags?.map((ct: any) => ct.tags).filter(Boolean) ?? [],
    }));

    return {
      success: true,
      data: {
        leads: formattedLeads,
        totalCount: count ?? 0,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve abandoned leads',
    };
  }
}

/**
 * Admin action: Dismisses an abandoned lead.
 */
export async function dismissAbandonedLead(
  subaccountId: string,
  contactId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'contacts:delete');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('contacts')
      .delete()
      .eq('id', contactId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/leads`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to dismiss lead',
    };
  }
}
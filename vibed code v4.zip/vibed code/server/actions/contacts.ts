'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { requirePermission } from '@/lib/auth/rbac';
import { Contact, ContactFilterParams } from '@/types/crm';
import { Database } from '@/types/database';

type ContactInsert = Database['public']['Tables']['contacts']['Insert'];
type ContactUpdate = Database['public']['Tables']['contacts']['Update'];

export interface ActionResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * Retrieves a paginated and filtered list of contacts for a subaccount.
 */
export async function getContacts(
  subaccountId: string,
  params: ContactFilterParams = {}
): Promise<ActionResponse<{ contacts: Contact[]; totalCount: number }>> {
  try {
    await requirePermission(subaccountId, 'contacts:read');
    const supabase = await createServerClient();

    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 25;
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase
      .from('contacts')
      .select(
        `
        *,
        contact_tags (
          tags (
            id,
            name,
            color
          )
        )
      `,
        { count: 'exact' }
      )
      .eq('subaccount_id', subaccountId);

    if (params.search) {
      const searchTerm = `%${params.search.trim()}%`;
      query = query.or(
        `first_name.ilike.${searchTerm},last_name.ilike.${searchTerm},email.ilike.${searchTerm},phone.ilike.${searchTerm}`
      );
    }

    if (params.minLtv !== undefined) {
      query = query.gte('lifetime_value', params.minLtv);
    }

    if (params.maxLtv !== undefined) {
      query = query.lte('lifetime_value', params.maxLtv);
    }

    const sortColumn = params.sortBy ?? 'created_at';
    const sortAscending = params.sortOrder === 'asc';
    query = query.order(sortColumn, { ascending: sortAscending }).range(from, to);

    const { data, count, error } = await query;

    if (error) throw new Error(error.message);

    const formattedContacts: Contact[] = (data || []).map((row: any) => ({
      ...row,
      tags: row.contact_tags?.map((ct: any) => ct.tags).filter(Boolean) ?? [],
    }));

    return {
      success: true,
      data: {
        contacts: formattedContacts,
        totalCount: count ?? 0,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve contacts',
    };
  }
}

/**
 * Creates a new contact record inside a subaccount CRM.
 */
export async function createContact(
  subaccountId: string,
  contactData: Omit<ContactInsert, 'id' | 'subaccount_id' | 'created_at' | 'updated_at'>
): Promise<ActionResponse<Contact>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('contacts')
      .insert({
        ...contactData,
        subaccount_id: subaccountId,
        lifetime_value: 0,
        orders_count: 0,
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');
    return { success: true, data: data as Contact };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to create contact',
    };
  }
}

/**
 * Updates an existing contact profile.
 */
export async function updateContact(
  subaccountId: string,
  contactId: string,
  updates: ContactUpdate
): Promise<ActionResponse<Contact>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('contacts')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', contactId)
      .eq('subaccount_id', subaccountId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');
    revalidatePath(`/[subaccountSlug]/admin/contacts/${contactId}`, 'page');
    return { success: true, data: data as Contact };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to update contact',
    };
  }
}

/**
 * Deletes a contact record and automatically cascades associated relations.
 */
export async function deleteContact(
  subaccountId: string,
  contactId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'contacts:delete');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('contacts')
      .delete()
      .eq('id', contactId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete contact',
    };
  }
}

/**
 * Associates an existing CRM tag to a contact.
 */
export async function attachTagToContact(
  subaccountId: string,
  contactId: string,
  tagId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { error } = await supabase.from('contact_tags').insert({
      contact_id: contactId,
      tag_id: tagId,
      subaccount_id: subaccountId,
    });

    if (error && error.code !== '23505') {
      // Ignore 23505 unique constraint violation (already attached)
      throw new Error(error.message);
    }

    revalidatePath(`/[subaccountSlug]/admin/contacts/${contactId}`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to attach tag',
    };
  }
}

/**
 * Detaches a tag from a contact.
 */
export async function removeTagFromContact(
  subaccountId: string,
  contactId: string,
  tagId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('contact_tags')
      .delete()
      .eq('contact_id', contactId)
      .eq('tag_id', tagId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/contacts/${contactId}`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to remove tag',
    };
  }
}
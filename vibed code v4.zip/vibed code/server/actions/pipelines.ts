'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { requirePermission } from '@/lib/auth/rbac';
import {
  ConcurrencyConflictError,
  MoveOpportunityInput,
  Opportunity,
  Pipeline,
} from '@/types/crm';
import { Database } from '@/types/database';

type OpportunityInsert = Database['public']['Tables']['opportunities']['Insert'];
type OpportunityUpdate = Database['public']['Tables']['opportunities']['Update'];

export interface ActionResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  isConflict?: boolean;
}

/**
 * Retrieves a full pipeline including its ordered stages and embedded opportunity cards.
 */
export async function getPipelineWithStages(
  subaccountId: string,
  pipelineId?: string
): Promise<ActionResponse<Pipeline>> {
  try {
    await requirePermission(subaccountId, 'pipelines:read');
    const supabase = await createServerClient();

    let pipelineQuery = supabase
      .from('pipelines')
      .select('*')
      .eq('subaccount_id', subaccountId);

    if (pipelineId) {
      pipelineQuery = pipelineQuery.eq('id', pipelineId);
    } else {
      pipelineQuery = pipelineQuery.order('position', { ascending: true }).limit(1);
    }

    const { data: pipelineData, error: pipelineError } = await pipelineQuery.maybeSingle();

    if (pipelineError || !pipelineData) {
      throw new Error(pipelineError?.message || 'Pipeline not found');
    }

    // Fetch stages ordered by position
    const { data: stagesData, error: stagesError } = await supabase
      .from('pipeline_stages')
      .select('*')
      .eq('pipeline_id', pipelineData.id)
      .eq('subaccount_id', subaccountId)
      .order('position', { ascending: true });

    if (stagesError) throw new Error(stagesError.message);

    // Fetch active opportunities with contact snapshots
    const { data: dealsData, error: dealsError } = await supabase
      .from('opportunities')
      .select(`
        *,
        contacts (
          id,
          first_name,
          last_name,
          email,
          phone
        )
      `)
      .eq('pipeline_id', pipelineData.id)
      .eq('subaccount_id', subaccountId)
      .order('position', { ascending: true });

    if (dealsError) throw new Error(dealsError.message);

    const formattedStages = (stagesData || []).map((stage) => {
      const stageDeals = (dealsData || [])
        .filter((deal) => deal.stage_id === stage.id)
        .map((deal: any) => ({
          ...deal,
          contact: deal.contacts ?? null,
        })) as Opportunity[];

      const totalValue = stageDeals.reduce((sum, deal) => sum + (deal.value || 0), 0);

      return {
        ...stage,
        opportunities: stageDeals,
        opportunities_count: stageDeals.length,
        total_value: totalValue,
      };
    });

    return {
      success: true,
      data: {
        ...pipelineData,
        stages: formattedStages,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve pipeline',
    };
  }
}

/**
 * Optimistic Concurrency Control (OCC) protected stage movement.
 * Fails if the deal was modified/dragged concurrently by another session.
 */
export async function moveOpportunityStage(
  input: MoveOpportunityInput
): Promise<ActionResponse<Opportunity>> {
  try {
    await requirePermission(input.subaccountId, 'pipelines:move_stage');
    const supabase = await createServerClient();

    // 1. OCC Atomic Guard Update: Match both ID and expected version
    const nextVersion = input.expectedVersion + 1;

    const { data, error } = await supabase
      .from('opportunities')
      .update({
        stage_id: input.targetStageId,
        position: input.targetPosition,
        version: nextVersion,
        updated_at: new Date().toISOString(),
      })
      .eq('id', input.opportunityId)
      .eq('subaccount_id', input.subaccountId)
      .eq('version', input.expectedVersion) // Concurrency check
      .select('*')
      .maybeSingle();

    if (error) {
      throw new Error(`Database error while moving opportunity: ${error.message}`);
    }

    // If 0 rows were updated, a concurrent modification happened
    if (!data) {
      throw new ConcurrencyConflictError(
        'Concurrent edit detected: This deal was updated by another team member. The board has been refreshed.'
      );
    }

    revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
    return {
      success: true,
      data: data as Opportunity,
    };
  } catch (err: unknown) {
    const isConflict = err instanceof ConcurrencyConflictError;
    return {
      success: false,
      isConflict,
      error: err instanceof Error ? err.message : 'Failed to move deal',
    };
  }
}

/**
 * Creates an opportunity card and assigns an initial version of 1.
 */
export async function createOpportunity(
  subaccountId: string,
  input: Omit<OpportunityInsert, 'id' | 'subaccount_id' | 'version' | 'created_at' | 'updated_at'>
): Promise<ActionResponse<Opportunity>> {
  try {
    await requirePermission(subaccountId, 'pipelines:write');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('opportunities')
      .insert({
        ...input,
        subaccount_id: subaccountId,
        version: 1,
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
    return { success: true, data: data as Opportunity };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to create opportunity',
    };
  }
}

/**
 * Deletes an opportunity from a pipeline stage.
 */
export async function deleteOpportunity(
  subaccountId: string,
  opportunityId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'pipelines:delete');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('opportunities')
      .delete()
      .eq('id', opportunityId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/pipelines`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete deal',
    };
  }
}
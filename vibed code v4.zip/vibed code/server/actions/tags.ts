'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { requirePermission } from '@/lib/auth/rbac';
import { Tag } from '@/types/crm';
import { ActionResponse } from '@/server/actions/contacts';

/**
 * Retrieves all CRM tags for a given subaccount along with tagged contact count.
 */
export async function getTags(subaccountId: string): Promise<ActionResponse<Tag[]>> {
  try {
    await requirePermission(subaccountId, 'contacts:read');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('tags')
      .select(`
        *,
        contact_tags (
          contact_id
        )
      `)
      .eq('subaccount_id', subaccountId)
      .order('name', { ascending: true });

    if (error) throw new Error(error.message);

    const formattedTags: Tag[] = (data || []).map((tag: any) => ({
      id: tag.id,
      subaccount_id: tag.subaccount_id,
      name: tag.name,
      color: tag.color,
      created_at: tag.created_at,
      contacts_count: tag.contact_tags ? tag.contact_tags.length : 0,
    }));

    return { success: true, data: formattedTags };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve tags',
    };
  }
}

/**
 * Creates a new tag within a subaccount.
 */
export async function createTag(
  subaccountId: string,
  payload: { name: string; color?: string }
): Promise<ActionResponse<Tag>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('tags')
      .insert({
        subaccount_id: subaccountId,
        name: payload.name.trim(),
        color: payload.color || '#3b82f6',
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/settings/tags`, 'page');
    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');

    return {
      success: true,
      data: {
        ...data,
        contacts_count: 0,
      } as Tag,
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to create tag',
    };
  }
}

/**
 * Updates an existing tag's name or color.
 */
export async function updateTag(
  subaccountId: string,
  tagId: string,
  payload: { name?: string; color?: string }
): Promise<ActionResponse<Tag>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('tags')
      .update({
        ...(payload.name ? { name: payload.name.trim() } : {}),
        ...(payload.color ? { color: payload.color } : {}),
      })
      .eq('id', tagId)
      .eq('subaccount_id', subaccountId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/settings/tags`, 'page');
    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');

    return { success: true, data: data as Tag };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to update tag',
    };
  }
}

/**
 * Deletes a tag and removes all contact associations.
 */
export async function deleteTag(
  subaccountId: string,
  tagId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('tags')
      .delete()
      .eq('id', tagId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/settings/tags`, 'page');
    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');

    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete tag',
    };
  }
}

/**
 * Batch-attaches a tag to multiple contacts in one atomic transaction.
 */
export async function batchTagContacts(
  subaccountId: string,
  contactIds: string[],
  tagId: string
): Promise<ActionResponse<{ taggedCount: number }>> {
  try {
    await requirePermission(subaccountId, 'contacts:write');
    const supabase = await createServerClient();

    if (!contactIds.length) {
      return { success: true, data: { taggedCount: 0 } };
    }

    const rows = contactIds.map((contactId) => ({
      subaccount_id: subaccountId,
      contact_id: contactId,
      tag_id: tagId,
    }));

    const { data, error } = await supabase
      .from('contact_tags')
      .upsert(rows, { onConflict: 'contact_id,tag_id', ignoreDuplicates: true })
      .select('contact_id');

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');

    return {
      success: true,
      data: { taggedCount: data ? data.length : contactIds.length },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to batch tag contacts',
    };
  }
}
'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { requirePermission } from '@/lib/auth/rbac';
import { IdempotencyLedger } from '@/lib/idempotency/ledger';
import { ActionResponse } from '@/server/actions/contacts';
import { Database, MultilingualText } from '@/types/database';

type OrderRow = Database['public']['Tables']['orders']['Row'];
type OrderStatus = OrderRow['status'];

export interface OrderItemInput {
  productId: string;
  quantity: number;
  unitPrice: number;
  productTitle: MultilingualText;
}

export interface CreateCodOrderInput {
  subaccountId: string;
  subaccountSlug: string;
  customer: {
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    province?: string;
    postalCode?: string;
    country?: string;
  };
  items: OrderItemInput[];
  shippingCost?: number;
  discountAmount?: number;
  idempotencyKey?: string;
  metadata?: Record<string, unknown>;
}

export interface UpsellAdditionInput {
  orderId: string;
  subaccountId: string;
  productId: string;
  quantity: number;
  unitPrice: number;
  productTitle: MultilingualText;
}

function generateOrderNumber(): string {
  const prefix = 'ORD';
  const timestamp = Date.now().toString(36).toUpperCase().slice(-4);
  const random = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${timestamp}-${random}`;
}

/**
 * Creates a Cash on Delivery (COD) order.
 * Safe for public checkout use via the elevated admin client with idempotency locking.
 */
export async function createCodOrder(
  input: CreateCodOrderInput
): Promise<ActionResponse<{ orderId: string; orderNumber: string }>> {
  const idempotencyKey = input.idempotencyKey || `cod_order_${input.subaccountId}_${input.customer.phone}_${Date.now()}`;

  try {
    return await IdempotencyLedger.execute(
      idempotencyKey,
      async () => {
        const supabase = createAdminClient();

        // 1. Find or create Contact in Subaccount CRM
        let contactId: string;
        const normalizedPhone = input.customer.phone.replace(/[\s-]/g, '').trim();

        const { data: existingContact } = await supabase
          .from('contacts')
          .select('id, lifetime_value, orders_count')
          .eq('subaccount_id', input.subaccountId)
          .eq('phone', normalizedPhone)
          .maybeSingle();

        if (existingContact) {
          contactId = existingContact.id;
          await supabase
            .from('contacts')
            .update({
              first_name: input.customer.firstName,
              last_name: input.customer.lastName,
              address_line1: input.customer.addressLine1,
              city: input.customer.city,
              country: input.customer.country || 'MA',
              updated_at: new Date().toISOString(),
            })
            .eq('id', contactId);
        } else {
          const { data: newContact, error: contactError } = await supabase
            .from('contacts')
            .insert({
              subaccount_id: input.subaccountId,
              first_name: input.customer.firstName,
              last_name: input.customer.lastName,
              phone: normalizedPhone,
              email: input.customer.email || null,
              address_line1: input.customer.addressLine1,
              address_line2: input.customer.addressLine2 || null,
              city: input.customer.city,
              province: input.customer.province || null,
              postal_code: input.customer.postalCode || null,
              country: input.customer.country || 'MA',
              lifetime_value: 0,
              orders_count: 0,
            })
            .select('id')
            .single();

          if (contactError || !newContact) {
            throw new Error(`Failed to create contact profile: ${contactError?.message}`);
          }
          contactId = newContact.id;
        }

        // 2. Calculate Financial Totals
        const subtotal = input.items.reduce(
          (sum, item) => sum + item.unitPrice * item.quantity,
          0
        );
        const shippingCost = input.shippingCost ?? 0;
        const discountAmount = input.discountAmount ?? 0;
        const totalAmount = Math.max(0, subtotal + shippingCost - discountAmount);
        const orderNumber = generateOrderNumber();

        // 3. Insert Order
        const { data: orderData, error: orderError } = await supabase
          .from('orders')
          .insert({
            subaccount_id: input.subaccountId,
            contact_id: contactId,
            order_number: orderNumber,
            status: 'PENDING',
            payment_method: 'COD',
            payment_status: 'UNPAID',
            currency: 'USD',
            subtotal,
            shipping_cost: shippingCost,
            discount_amount: discountAmount,
            total_amount: totalAmount,
            shipping_address: input.customer,
            metadata: input.metadata || {},
          })
          .select('id, order_number')
          .single();

        if (orderError || !orderData) {
          throw new Error(`Failed to record order: ${orderError?.message}`);
        }

        // 4. Insert Line Items
        const orderItemsPayload = input.items.map((item) => ({
          order_id: orderData.id,
          product_id: item.productId,
          subaccount_id: input.subaccountId,
          quantity: item.quantity,
          unit_price: item.unitPrice,
          total_price: item.unitPrice * item.quantity,
          product_title: item.productTitle,
        }));

        const { error: itemsError } = await supabase
          .from('order_items')
          .insert(orderItemsPayload);

        if (itemsError) {
          throw new Error(`Failed to attach order items: ${itemsError.message}`);
        }

        // 5. Update Contact CRM metrics
        const prevLtv = existingContact?.lifetime_value ?? 0;
        const prevOrders = existingContact?.orders_count ?? 0;

        await supabase
          .from('contacts')
          .update({
            lifetime_value: prevLtv + totalAmount,
            orders_count: prevOrders + 1,
            updated_at: new Date().toISOString(),
          })
          .eq('id', contactId);

        revalidatePath(`/[subaccountSlug]/admin/orders`, 'page');
        revalidatePath(`/[subaccountSlug]/admin/contacts`, 'page');

        return {
          success: true,
          data: {
            orderId: orderData.id,
            orderNumber: orderData.order_number,
          },
        };
      },
      { subaccountId: input.subaccountId, lockTtlSeconds: 60 }
    );
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Unable to complete COD checkout',
    };
  }
}

/**
 * 1-Click Post-Purchase Upsell: Attaches an add-on item directly to an existing COD order.
 */
export async function applyPostPurchaseUpsell(
  input: UpsellAdditionInput
): Promise<ActionResponse<boolean>> {
  try {
    const supabase = createAdminClient();

    // 1. Fetch current order
    const { data: order, error: orderErr } = await supabase
      .from('orders')
      .select('id, contact_id, subtotal, total_amount')
      .eq('id', input.orderId)
      .eq('subaccount_id', input.subaccountId)
      .single();

    if (orderErr || !order) {
      throw new Error('Order not found');
    }

    const additionalCost = input.unitPrice * input.quantity;

    // 2. Insert upsell item
    const { error: insertErr } = await supabase.from('order_items').insert({
      order_id: input.orderId,
      product_id: input.productId,
      subaccount_id: input.subaccountId,
      quantity: input.quantity,
      unit_price: input.unitPrice,
      total_price: additionalCost,
      product_title: input.productTitle,
    });

    if (insertErr) throw new Error(insertErr.message);

    // 3. Update order subtotal and total
    const newTotal = order.total_amount + additionalCost;
    const newSubtotal = order.subtotal + additionalCost;

    const { error: updateOrderErr } = await supabase
      .from('orders')
      .update({
        subtotal: newSubtotal,
        total_amount: newTotal,
        updated_at: new Date().toISOString(),
      })
      .eq('id', input.orderId);

    if (updateOrderErr) throw new Error(updateOrderErr.message);

    // 4. Update contact LTV
    const { data: contact } = await supabase
      .from('contacts')
      .select('lifetime_value')
      .eq('id', order.contact_id)
      .single();

    if (contact) {
      await supabase
        .from('contacts')
        .update({
          lifetime_value: contact.lifetime_value + additionalCost,
          updated_at: new Date().toISOString(),
        })
        .eq('id', order.contact_id);
    }

    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to apply upsell offer',
    };
  }
}

/**
 * Updates order delivery status and sets shipping tracking / waybill number (Admin RBAC).
 */
export async function updateOrderStatus(
  subaccountId: string,
  orderId: string,
  status: OrderStatus,
  waybillNumber?: string | null
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'orders:update_status');
    const supabase = await createServerClient();

    const updatePayload: Database['public']['Tables']['orders']['Update'] = {
      status,
      updated_at: new Date().toISOString(),
    };

    if (waybillNumber !== undefined) {
      updatePayload.waybill_number = waybillNumber;
    }

    const { error } = await supabase
      .from('orders')
      .update(updatePayload)
      .eq('id', orderId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/orders`, 'page');
    revalidatePath(`/[subaccountSlug]/admin/orders/${orderId}`, 'page');

    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to update order status',
    };
  }
}
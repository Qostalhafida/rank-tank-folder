'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { requirePermission } from '@/lib/auth/rbac';
import { calculateAvailableSlots, generateIcsCalendar } from '@/lib/booking/slots';
import { ActionResponse } from '@/server/actions/contacts';
import {
  Appointment,
  AvailableSlot,
  BookAppointmentInput,
  Calendar,
  WeeklySchedule,
} from '@/types/booking';
import { Json } from '@/types/database';

export interface ReservedAppointmentResult {
  appointment: Appointment;
  icsContent: string;
}

/**
 * Public resolver: Fetches a calendar configuration by subaccount and calendar slug.
 */
export async function getCalendarBySlug(
  subaccountSlug: string,
  calendarSlug: string
): Promise<ActionResponse<Calendar>> {
  try {
    const supabase = createAdminClient();

    const { data: subaccount, error: subaccountErr } = await supabase
      .from('subaccounts')
      .select('id')
      .eq('slug', subaccountSlug)
      .single();

    if (subaccountErr || !subaccount) throw new Error('Tenant subaccount not found');

    const { data: calendar, error: calendarErr } = await supabase
      .from('calendars')
      .select('*')
      .eq('subaccount_id', subaccount.id)
      .eq('slug', calendarSlug)
      .single();

    if (calendarErr || !calendar) throw new Error('Calendar not found');

    return {
      success: true,
      data: {
        ...calendar,
        weekly_schedule: calendar.weekly_schedule as unknown as WeeklySchedule,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve calendar',
    };
  }
}

/**
 * Calculates open booking slots for a calendar on a specific target date (YYYY-MM-DD).
 */
export async function getAvailableSlotsForDate(
  calendarId: string,
  dateStr: string
): Promise<ActionResponse<AvailableSlot[]>> {
  try {
    const supabase = createAdminClient();

    const { data: calendar, error: calErr } = await supabase
      .from('calendars')
      .select('*')
      .eq('id', calendarId)
      .single();

    if (calErr || !calendar) throw new Error('Calendar not found');

    const startOfDay = new Date(`${dateStr}T00:00:00.000Z`).toISOString();
    const endOfDay = new Date(`${dateStr}T23:59:59.999Z`).toISOString();

    const { data: appointments, error: apptErr } = await supabase
      .from('appointments')
      .select('start_time, end_time, status')
      .eq('calendar_id', calendarId)
      .gte('start_time', startOfDay)
      .lte('start_time', endOfDay)
      .neq('status', 'CANCELLED');

    if (apptErr) throw new Error(apptErr.message);

    const typedCalendar: Calendar = {
      ...calendar,
      weekly_schedule: calendar.weekly_schedule as unknown as WeeklySchedule,
    };

    const targetDate = new Date(`${dateStr}T12:00:00.000Z`);
    const slots = calculateAvailableSlots(typedCalendar, appointments || [], targetDate);

    return { success: true, data: slots };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to calculate available slots',
    };
  }
}

/**
 * Public action: Reserves an appointment, registers attendee in CRM, and produces an .ics invite.
 */
export async function reserveAppointment(
  input: BookAppointmentInput
): Promise<ActionResponse<ReservedAppointmentResult>> {
  try {
    const supabase = createAdminClient();

    // 1. Fetch Calendar details
    const { data: calendar, error: calErr } = await supabase
      .from('calendars')
      .select('*, subaccounts(name)')
      .eq('id', input.calendarId)
      .eq('subaccount_id', input.subaccountId)
      .single();

    if (calErr || !calendar) throw new Error('Calendar not found');

    const startTime = new Date(input.startTime);
    const endTime = new Date(startTime.getTime() + calendar.duration_minutes * 60000);

    // 2. Prevent race condition booking collision
    const { data: conflict } = await supabase
      .from('appointments')
      .select('id')
      .eq('calendar_id', input.calendarId)
      .neq('status', 'CANCELLED')
      .lt('start_time', endTime.toISOString())
      .gt('end_time', startTime.toISOString())
      .maybeSingle();

    if (conflict) {
      throw new Error('This time slot has just been reserved by someone else. Please choose another slot.');
    }

    // 3. Upsert Attendee Contact
    let contactId: string;
    const { data: existingContact } = await supabase
      .from('contacts')
      .select('id')
      .eq('subaccount_id', input.subaccountId)
      .eq('email', input.contact.email.toLowerCase().trim())
      .maybeSingle();

    if (existingContact) {
      contactId = existingContact.id;
    } else {
      const { data: newContact, error: contactErr } = await supabase
        .from('contacts')
        .insert({
          subaccount_id: input.subaccountId,
          first_name: input.contact.firstName.trim(),
          last_name: input.contact.lastName.trim(),
          email: input.contact.email.toLowerCase().trim(),
          phone: input.contact.phone?.trim() || null,
        })
        .select('id')
        .single();

      if (contactErr || !newContact) {
        throw new Error('Failed to record attendee profile in CRM');
      }
      contactId = newContact.id;
    }

    // 4. Create Appointment record
    const { data: appointment, error: apptErr } = await supabase
      .from('appointments')
      .insert({
        calendar_id: input.calendarId,
        subaccount_id: input.subaccountId,
        contact_id: contactId,
        start_time: startTime.toISOString(),
        end_time: endTime.toISOString(),
        status: 'SCHEDULED',
        notes: input.notes?.trim() || null,
      })
      .select('*')
      .single();

    if (apptErr || !appointment) {
      throw new Error(`Failed to schedule appointment: ${apptErr?.message}`);
    }

    // 5. Generate .ics file payload
    const organizerName = (calendar.subaccounts as any)?.name || 'Consultant';
    const icsContent = generateIcsCalendar({
      title: `${calendar.name} with ${input.contact.firstName} ${input.contact.lastName}`,
      description: input.notes || 'Scheduled appointment',
      startTime,
      endTime,
      organizerName,
      organizerEmail: 'appointments@notifications.platform',
      attendeeName: `${input.contact.firstName} ${input.contact.lastName}`,
      attendeeEmail: input.contact.email,
    });

    return {
      success: true,
      data: {
        appointment: {
          ...appointment,
          contact: {
            first_name: input.contact.firstName,
            last_name: input.contact.lastName,
            email: input.contact.email,
            phone: input.contact.phone || null,
          },
        } as Appointment,
        icsContent,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to complete appointment reservation',
    };
  }
}

/**
 * Admin action: Updates the working hours and weekly schedule of a calendar.
 */
export async function updateCalendarSchedule(
  subaccountId: string,
  calendarId: string,
  weeklySchedule: WeeklySchedule
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'booking:configure_schedule');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('calendars')
      .update({
        weekly_schedule: weeklySchedule as unknown as Json,
        updated_at: new Date().toISOString(),
      })
      .eq('id', calendarId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/calendars`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to update calendar schedule',
    };
  }
}
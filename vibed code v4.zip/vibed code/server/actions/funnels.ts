'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { requirePermission } from '@/lib/auth/rbac';
import { ActionResponse } from '@/server/actions/contacts';
import { Database, Json } from '@/types/database';

type FunnelRow = Database['public']['Tables']['funnels']['Row'];
type FunnelStepRow = Database['public']['Tables']['funnel_steps']['Row'];
type FunnelStepType = FunnelStepRow['step_type'];

export interface FunnelWithSteps extends FunnelRow {
  steps: FunnelStepRow[];
}

export interface FunnelStepInput {
  id?: string;
  step_type: FunnelStepType;
  position: number;
  settings: Record<string, unknown>;
}

export interface CreateFunnelInput {
  name: string;
  slug: string;
}

/**
 * Retrieves all sales funnels for a subaccount with their configured steps.
 */
export async function getFunnels(
  subaccountId: string
): Promise<ActionResponse<FunnelWithSteps[]>> {
  try {
    await requirePermission(subaccountId, 'funnels:read');
    const supabase = await createServerClient();

    const { data: funnels, error: funnelsError } = await supabase
      .from('funnels')
      .select('*')
      .eq('subaccount_id', subaccountId)
      .order('created_at', { ascending: false });

    if (funnelsError) throw new Error(funnelsError.message);

    const { data: steps, error: stepsError } = await supabase
      .from('funnel_steps')
      .select('*')
      .eq('subaccount_id', subaccountId)
      .order('position', { ascending: true });

    if (stepsError) throw new Error(stepsError.message);

    const funnelsWithSteps: FunnelWithSteps[] = (funnels || []).map((funnel) => ({
      ...funnel,
      steps: (steps || []).filter((s) => s.funnel_id === funnel.id),
    }));

    return { success: true, data: funnelsWithSteps };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve funnels',
    };
  }
}

/**
 * Fetches a funnel and its steps publicly by subaccount slug and funnel slug (for storefront funnel layout).
 */
export async function getFunnelBySlug(
  subaccountSlug: string,
  funnelSlug: string
): Promise<ActionResponse<FunnelWithSteps>> {
  try {
    const supabase = createAdminClient();

    // 1. Resolve subaccount
    const { data: subaccount, error: subaccountError } = await supabase
      .from('subaccounts')
      .select('id')
      .eq('slug', subaccountSlug)
      .single();

    if (subaccountError || !subaccount) {
      throw new Error('Tenant subaccount not found');
    }

    // 2. Fetch funnel
    const { data: funnel, error: funnelError } = await supabase
      .from('funnels')
      .select('*')
      .eq('subaccount_id', subaccount.id)
      .eq('slug', funnelSlug)
      .eq('is_active', true)
      .single();

    if (funnelError || !funnel) {
      throw new Error('Funnel not found or inactive');
    }

    // 3. Fetch steps
    const { data: steps, error: stepsError } = await supabase
      .from('funnel_steps')
      .select('*')
      .eq('funnel_id', funnel.id)
      .order('position', { ascending: true });

    if (stepsError) throw new Error(stepsError.message);

    return {
      success: true,
      data: {
        ...funnel,
        steps: steps || [],
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to fetch public funnel',
    };
  }
}

/**
 * Creates a new funnel shell within a subaccount.
 */
export async function createFunnel(
  subaccountId: string,
  input: CreateFunnelInput
): Promise<ActionResponse<FunnelRow>> {
  try {
    await requirePermission(subaccountId, 'funnels:write');
    const supabase = await createServerClient();

    const normalizedSlug = input.slug
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-');

    const { data, error } = await supabase
      .from('funnels')
      .insert({
        subaccount_id: subaccountId,
        name: input.name.trim(),
        slug: normalizedSlug,
        is_active: true,
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/funnels`, 'page');
    return { success: true, data };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to create funnel',
    };
  }
}

/**
 * Saves and updates the complete step sequence configuration for a sales funnel.
 */
export async function saveFunnelSteps(
  subaccountId: string,
  funnelId: string,
  steps: FunnelStepInput[]
): Promise<ActionResponse<FunnelStepRow[]>> {
  try {
    await requirePermission(subaccountId, 'funnels:write');
    const supabase = await createServerClient();

    // Verify ownership of the funnel
    const { data: funnel, error: funnelErr } = await supabase
      .from('funnels')
      .select('id')
      .eq('id', funnelId)
      .eq('subaccount_id', subaccountId)
      .single();

    if (funnelErr || !funnel) throw new Error('Funnel not found or access denied');

    // Remove existing steps to rewrite clean sequence
    const { error: deleteError } = await supabase
      .from('funnel_steps')
      .delete()
      .eq('funnel_id', funnelId)
      .eq('subaccount_id', subaccountId);

    if (deleteError) throw new Error(deleteError.message);

    if (!steps.length) {
      return { success: true, data: [] };
    }

    const payload = steps.map((s, idx) => ({
      funnel_id: funnelId,
      subaccount_id: subaccountId,
      step_type: s.step_type,
      position: idx,
      settings: s.settings as Json,
    }));

    const { data: insertedSteps, error: insertError } = await supabase
      .from('funnel_steps')
      .insert(payload)
      .select('*')
      .order('position', { ascending: true });

    if (insertError) throw new Error(insertError.message);

    revalidatePath(`/[subaccountSlug]/admin/funnels`, 'page');
    return { success: true, data: insertedSteps };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to save funnel steps',
    };
  }
}

/**
 * Deletes a funnel and all its configured steps.
 */
export async function deleteFunnel(
  subaccountId: string,
  funnelId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'funnels:write');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('funnels')
      .delete()
      .eq('id', funnelId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/funnels`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete funnel',
    };
  }
}
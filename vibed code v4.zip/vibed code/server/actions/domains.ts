'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { requirePermission } from '@/lib/auth/rbac';
import {
  createCustomHostname,
  deleteCustomHostname as deleteCloudflareHostname,
  getCustomHostname,
  CloudflareHostnameResult,
} from '@/lib/cloudflare/custom-hostnames';
import { cacheDomainMapping, invalidateDomainCache } from '@/lib/edge/domain-cache';
import { ActionResponse } from '@/server/actions/contacts';
import { Database } from '@/types/database';

type CustomDomainRow = Database['public']['Tables']['custom_domains']['Row'];

export interface DomainDetails extends CustomDomainRow {
  cloudflareData?: CloudflareHostnameResult;
}

/**
 * Retrieves the currently configured custom domain and its live Cloudflare verification status.
 */
export async function getCustomDomain(
  subaccountId: string
): Promise<ActionResponse<DomainDetails | null>> {
  try {
    await requirePermission(subaccountId, 'settings:domains');
    const supabase = await createServerClient();

    const { data: domainRow, error } = await supabase
      .from('custom_domains')
      .select('*')
      .eq('subaccount_id', subaccountId)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!domainRow) return { success: true, data: null };

    let cloudflareData: CloudflareHostnameResult | undefined;

    if (domainRow.cloudflare_hostname_id) {
      try {
        cloudflareData = await getCustomHostname(domainRow.cloudflare_hostname_id);
      } catch (cfErr) {
        console.warn('Failed to query live Cloudflare status:', cfErr);
      }
    }

    return {
      success: true,
      data: {
        ...domainRow,
        cloudflareData,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve custom domain',
    };
  }
}

/**
 * Provisions a new custom domain via Cloudflare for SaaS and registers it in the database.
 */
export async function provisionCustomDomain(
  subaccountId: string,
  hostnameInput: string
): Promise<ActionResponse<DomainDetails>> {
  try {
    await requirePermission(subaccountId, 'settings:domains');
    const supabase = await createServerClient();

    const normalizedHostname = hostnameInput
      .toLowerCase()
      .trim()
      .replace(/^https?:\/\//, '')
      .replace(/\/.*$/, '');

    // Basic domain validation pattern
    const domainRegex = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/i;
    if (!domainRegex.test(normalizedHostname)) {
      throw new Error('Invalid domain format. Example: store.yourbrand.com');
    }

    // 1. Provision via Cloudflare Custom Hostname API
    const cfResult = await createCustomHostname(normalizedHostname);

    // 2. Insert into custom_domains table
    const { data: domainRow, error } = await supabase
      .from('custom_domains')
      .insert({
        subaccount_id: subaccountId,
        hostname: normalizedHostname,
        cloudflare_hostname_id: cfResult.id,
        status: cfResult.status === 'active' ? 'ACTIVE' : 'PENDING',
        ssl_status: cfResult.sslStatus,
        verification_errors: cfResult.verificationErrors,
      })
      .select('*')
      .single();

    if (error) {
      // Attempt rollback in Cloudflare if DB insert fails
      await deleteCloudflareHostname(cfResult.id).catch(() => null);
      throw new Error(error.message);
    }

    revalidatePath(`/[subaccountSlug]/admin/settings/domains`, 'page');

    return {
      success: true,
      data: {
        ...domainRow,
        cloudflareData: cfResult,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to provision custom domain',
    };
  }
}

/**
 * Polls Cloudflare to re-verify domain ownership and SSL certificate issuance.
 */
export async function verifyCustomDomain(
  subaccountId: string,
  domainId: string
): Promise<ActionResponse<DomainDetails>> {
  try {
    await requirePermission(subaccountId, 'settings:domains');
    const supabase = await createServerClient();

    const { data: domainRow, error: fetchErr } = await supabase
      .from('custom_domains')
      .select(`
        *,
        subaccounts (
          slug
        )
      `)
      .eq('id', domainId)
      .eq('subaccount_id', subaccountId)
      .single();

    if (fetchErr || !domainRow?.cloudflare_hostname_id) {
      throw new Error('Domain record not found or unlinked');
    }

    const cfResult = await getCustomHostname(domainRow.cloudflare_hostname_id);
    const newStatus = cfResult.status === 'active' ? 'ACTIVE' : 'PENDING';

    const { data: updatedRow, error: updateErr } = await supabase
      .from('custom_domains')
      .update({
        status: newStatus,
        ssl_status: cfResult.sslStatus,
        verification_errors: cfResult.verificationErrors,
        updated_at: new Date().toISOString(),
      })
      .eq('id', domainId)
      .select('*')
      .single();

    if (updateErr) throw new Error(updateErr.message);

    // Warm Edge KV cache when domain becomes active
    if (newStatus === 'ACTIVE') {
      const subaccount = Array.isArray(domainRow.subaccounts)
        ? domainRow.subaccounts[0]
        : domainRow.subaccounts;

      if (subaccount?.slug) {
        await cacheDomainMapping(domainRow.hostname, {
          subaccountId,
          slug: subaccount.slug,
          status: 'ACTIVE',
        });
      }
    }

    revalidatePath(`/[subaccountSlug]/admin/settings/domains`, 'page');

    return {
      success: true,
      data: {
        ...updatedRow,
        cloudflareData: cfResult,
      },
    };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to verify custom domain',
    };
  }
}

/**
 * Removes a custom domain from Cloudflare, clears Edge KV cache, and deletes from DB.
 */
export async function deleteCustomDomain(
  subaccountId: string,
  domainId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'settings:domains');
    const supabase = await createServerClient();

    const { data: domainRow, error: fetchErr } = await supabase
      .from('custom_domains')
      .select('hostname, cloudflare_hostname_id')
      .eq('id', domainId)
      .eq('subaccount_id', subaccountId)
      .single();

    if (fetchErr || !domainRow) {
      throw new Error('Custom domain not found');
    }

    // 1. Delete from Cloudflare
    if (domainRow.cloudflare_hostname_id) {
      await deleteCloudflareHostname(domainRow.cloudflare_hostname_id).catch((err) => {
        console.warn('Cloudflare deletion warning:', err);
      });
    }

    // 2. Invalidate Edge KV Cache
    await invalidateDomainCache(domainRow.hostname).catch(() => null);

    // 3. Delete from DB
    const { error: deleteErr } = await supabase
      .from('custom_domains')
      .delete()
      .eq('id', domainId)
      .eq('subaccount_id', subaccountId);

    if (deleteErr) throw new Error(deleteErr.message);

    revalidatePath(`/[subaccountSlug]/admin/settings/domains`, 'page');

    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to delete domain',
    };
  }
}
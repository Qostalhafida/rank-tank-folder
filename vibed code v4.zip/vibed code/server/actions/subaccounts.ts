'use server';

import { revalidatePath } from 'next/cache';
import { createServerClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { requireAgencyRole, requirePermission } from '@/lib/auth/rbac';
import { ActionResponse } from '@/server/actions/contacts';
import {
  CreateSubaccountInput,
  InviteSubaccountMemberInput,
  Subaccount,
  SubaccountMember,
  UpdateSubaccountInput,
} from '@/types/subaccount';
import { Json } from '@/types/database';

/**
 * Retrieves all subaccounts under an agency (Agency Super Admin / Admin only).
 */
export async function getAgencySubaccounts(
  agencyId: string
): Promise<ActionResponse<Subaccount[]>> {
  try {
    await requireAgencyRole();
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('subaccounts')
      .select('*')
      .eq('agency_id', agencyId)
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);

    return { success: true, data: data as unknown as Subaccount[] };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to retrieve subaccounts',
    };
  }
}

/**
 * Retrieves a single subaccount by slug or ID.
 */
export async function getSubaccount(
  identifier: string,
  by: 'id' | 'slug' = 'slug'
): Promise<ActionResponse<Subaccount>> {
  try {
    const supabase = createAdminClient();

    const query = supabase
      .from('subaccounts')
      .select('*')
      .eq(by, identifier)
      .single();

    const { data, error } = await query;

    if (error || !data) {
      throw new Error(error?.message || 'Subaccount not found');
    }

    return { success: true, data: data as unknown as Subaccount };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Subaccount lookup failed',
    };
  }
}

/**
 * Provisions a new tenant subaccount, establishes default pipelines, and mounts settings.
 */
export async function createSubaccount(
  input: CreateSubaccountInput
): Promise<ActionResponse<Subaccount>> {
  try {
    const session = await requireAgencyRole();
    const supabase = await createServerClient();

    const normalizedSlug = input.slug
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-');

    // 1. Create Subaccount Record
    const { data: subaccount, error: subaccountError } = await supabase
      .from('subaccounts')
      .insert({
        agency_id: input.agencyId,
        name: input.name.trim(),
        slug: normalizedSlug,
        default_locale: input.defaultLocale || 'en',
        supported_locales: input.supportedLocales || ['en', 'ar', 'fr'],
        mode: input.mode || 'COD',
        currency: input.currency || 'USD',
        theme: (input.theme as Json) || {
          primaryColor: '#2563eb',
          borderRadius: 'md',
          fontFamily: 'sans',
        },
      })
      .select('*')
      .single();

    if (subaccountError || !subaccount) {
      throw new Error(`Failed to create subaccount: ${subaccountError?.message}`);
    }

    // 2. Link agency creator as Subaccount Owner
    await supabase.from('subaccount_members').insert({
      subaccount_id: subaccount.id,
      user_id: session.userId,
      role: 'SUBACCOUNT_OWNER',
    });

    // 3. Seed Default Sales Pipeline and Stages
    const { data: pipeline } = await supabase
      .from('pipelines')
      .insert({
        subaccount_id: subaccount.id,
        name: 'Default Sales Pipeline',
        position: 0,
      })
      .select('id')
      .single();

    if (pipeline) {
      const defaultStages = [
        { name: 'New Inquiries', position: 0, color: '#3b82f6' },
        { name: 'Contacted', position: 1, color: '#f59e0b' },
        { name: 'Order Confirmed', position: 2, color: '#8b5cf6' },
        { name: 'Delivered / Won', position: 3, color: '#10b981' },
      ];

      await supabase.from('pipeline_stages').insert(
        defaultStages.map((stage) => ({
          pipeline_id: pipeline.id,
          subaccount_id: subaccount.id,
          ...stage,
        }))
      );
    }

    revalidatePath('/agency/subaccounts', 'page');
    return { success: true, data: subaccount as unknown as Subaccount };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to provision subaccount',
    };
  }
}

/**
 * Updates operational parameters, branding theme, or operational mode (COD / Online / Hybrid).
 */
export async function updateSubaccount(
  subaccountId: string,
  input: UpdateSubaccountInput
): Promise<ActionResponse<Subaccount>> {
  try {
    await requirePermission(subaccountId, 'settings:write');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('subaccounts')
      .update({
        ...(input.name ? { name: input.name.trim() } : {}),
        ...(input.mode ? { mode: input.mode } : {}),
        ...(input.currency ? { currency: input.currency } : {}),
        ...(input.defaultLocale ? { default_locale: input.defaultLocale } : {}),
        ...(input.supportedLocales ? { supported_locales: input.supportedLocales } : {}),
        ...(input.theme ? { theme: input.theme as Json } : {}),
        updated_at: new Date().toISOString(),
      })
      .eq('id', subaccountId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/settings`, 'page');
    return { success: true, data: data as unknown as Subaccount };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to update subaccount settings',
    };
  }
}

/**
 * Retrieves members assigned to a specific subaccount.
 */
export async function getSubaccountMembers(
  subaccountId: string
): Promise<ActionResponse<SubaccountMember[]>> {
  try {
    await requirePermission(subaccountId, 'team:manage');
    const supabase = await createServerClient();

    const { data, error } = await supabase
      .from('subaccount_members')
      .select('*')
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    return { success: true, data: data as unknown as SubaccountMember[] };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to fetch team members',
    };
  }
}

/**
 * Invites or attaches a team member to a subaccount with an assigned RBAC role.
 */
export async function inviteSubaccountMember(
  input: InviteSubaccountMemberInput
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(input.subaccountId, 'team:manage');
    const adminSupabase = createAdminClient();

    // 1. Look up user by email via admin auth API
    const { data: userLookup, error: userError } =
      await adminSupabase.auth.admin.listUsers();

    if (userError) throw new Error(userError.message);

    const targetUser = userLookup.users.find(
      (u) => u.email?.toLowerCase() === input.email.toLowerCase().trim()
    );

    if (!targetUser) {
      throw new Error(`User with email "${input.email}" must register before being assigned to this subaccount`);
    }

    // 2. Attach user to subaccount
    const { error: memberError } = await adminSupabase
      .from('subaccount_members')
      .upsert(
        {
          subaccount_id: input.subaccountId,
          user_id: targetUser.id,
          role: input.role,
        },
        { onConflict: 'subaccount_id,user_id' }
      );

    if (memberError) throw new Error(memberError.message);

    revalidatePath(`/[subaccountSlug]/admin/settings/team`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to assign team member',
    };
  }
}

/**
 * Removes a member from a subaccount.
 */
export async function removeSubaccountMember(
  subaccountId: string,
  memberId: string
): Promise<ActionResponse<boolean>> {
  try {
    await requirePermission(subaccountId, 'team:manage');
    const supabase = await createServerClient();

    const { error } = await supabase
      .from('subaccount_members')
      .delete()
      .eq('id', memberId)
      .eq('subaccount_id', subaccountId);

    if (error) throw new Error(error.message);

    revalidatePath(`/[subaccountSlug]/admin/settings/team`, 'page');
    return { success: true, data: true };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Failed to remove team member',
    };
  }
}
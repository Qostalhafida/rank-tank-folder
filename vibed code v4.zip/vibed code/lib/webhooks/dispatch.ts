import { createHmac } from 'crypto';

export interface WebhookEventPayload<T = Record<string, unknown>> {
  id: string;
  event: string;
  subaccountId: string;
  timestamp: number;
  data: T;
}

export interface DispatchWebhookOptions<T = Record<string, unknown>> {
  url: string;
  secret: string;
  subaccountId: string;
  event: string;
  data: T;
  maxRetries?: number;
  timeoutMs?: number;
}

export interface DispatchWebhookResult {
  success: boolean;
  statusCode?: number;
  attempts: number;
  error?: string;
}

/**
 * Computes an HMAC SHA-256 signature for webhook payload verification.
 */
export function signWebhookPayload(
  payloadString: string,
  secret: string,
  timestamp: number
): string {
  const signaturePayload = `${timestamp}.${payloadString}`;
  return createHmac('sha256', secret)
    .update(signaturePayload)
    .digest('hex');
}

/**
 * Dispatches an authenticated webhook payload to external automation services (e.g., n8n).
 * Incorporates HMAC signing and exponential backoff retry logic.
 */
export async function dispatchWebhook<T = Record<string, unknown>>({
  url,
  secret,
  subaccountId,
  event,
  data,
  maxRetries = 3,
  timeoutMs = 5000,
}: DispatchWebhookOptions<T>): Promise<DispatchWebhookResult> {
  const timestamp = Math.floor(Date.now() / 1000);
  const eventId = crypto.randomUUID();

  const payload: WebhookEventPayload<T> = {
    id: eventId,
    event,
    subaccountId,
    timestamp,
    data,
  };

  const payloadString = JSON.stringify(payload);
  const signature = signWebhookPayload(payloadString, secret, timestamp);

  let attempts = 0;
  let lastError: string | undefined;

  while (attempts < maxRetries) {
    attempts++;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Signature': `t=${timestamp},v1=${signature}`,
          'X-Webhook-Timestamp': timestamp.toString(),
          'X-Webhook-Event': event,
          'X-Webhook-ID': eventId,
          'X-Subaccount-ID': subaccountId,
          'User-Agent': 'Ecommerce-Platform-Webhook-Engine/1.0',
        },
        body: payloadString,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        return {
          success: true,
          statusCode: response.status,
          attempts,
        };
      }

      lastError = `Target endpoint returned status code ${response.status}: ${response.statusText}`;

      // Non-transient 4xx client errors (excluding rate limit 429) do not warrant a retry
      if (response.status >= 400 && response.status < 500 && response.status !== 429) {
        return {
          success: false,
          statusCode: response.status,
          attempts,
          error: lastError,
        };
      }
    } catch (err: unknown) {
      lastError = err instanceof Error ? err.message : 'Unknown network failure';
    }

    // Exponential backoff delay before the next retry (e.g., 500ms, 1000ms, 2000ms)
    if (attempts < maxRetries) {
      const backoffDelay = Math.pow(2, attempts - 1) * 500;
      await new Promise((resolve) => setTimeout(resolve, backoffDelay));
    }
  }

  return {
    success: false,
    attempts,
    error: lastError,
  };
}
import { createAdminClient } from '@/lib/supabase/admin';
import {
  IdempotencyConflictError,
  IdempotencyOptions,
  IdempotencyRecord,
} from '@/types/idempotency';
import { Json } from '@/types/database';

const DEFAULT_LOCK_TTL_SECONDS = 120; // 2 minutes
const DEFAULT_RETENTION_SECONDS = 86400; // 24 hours

export class IdempotencyLedger {
  /**
   * Attempts to acquire an atomic lock for an idempotency key.
   * If already resolved, returns the cached response payload.
   * If currently processing within the lock TTL, throws an IdempotencyConflictError.
   */
  static async acquireLock<T = Json>(
    key: string,
    options: IdempotencyOptions = {}
  ): Promise<{ acquired: boolean; cachedData?: T }> {
    const supabase = createAdminClient();
    const now = new Date();
    const lockTtl = options.lockTtlSeconds ?? DEFAULT_LOCK_TTL_SECONDS;
    const expiresAt = new Date(now.getTime() + lockTtl * 1000).toISOString();
    const lockedAt = now.toISOString();

    const { data: existing, error: selectError } = await supabase
      .from('idempotency_keys')
      .select('*')
      .eq('key', key)
      .maybeSingle();

    if (selectError) {
      throw new Error(`Failed to query idempotency ledger: ${selectError.message}`);
    }

    if (existing) {
      const record = existing as IdempotencyRecord<T>;

      // 1. Return cached payload if already resolved
      if (record.status === 'RESOLVED') {
        return { acquired: false, cachedData: record.response_payload as T };
      }

      // 2. Reject concurrent duplicate requests if lock is still active
      const isLockActive = new Date(record.expires_at).getTime() > now.getTime();
      if (record.status === 'PROCESSING' && isLockActive) {
        throw new IdempotencyConflictError(
          `Request with key '${key}' is currently being processed by another worker`
        );
      }

      // 3. Lock has expired or previous attempt failed: re-acquire lock
      const { error: updateError } = await supabase
        .from('idempotency_keys')
        .update({
          status: 'PROCESSING',
          subaccount_id: options.subaccountId ?? record.subaccount_id,
          locked_at: lockedAt,
          expires_at: expiresAt,
          response_payload: null,
        })
        .eq('id', record.id);

      if (updateError) {
        throw new Error(`Failed to re-acquire idempotency lock: ${updateError.message}`);
      }

      return { acquired: true };
    }

    // 4. Initial insert to acquire lock
    const { error: insertError } = await supabase
      .from('idempotency_keys')
      .insert({
        key,
        subaccount_id: options.subaccountId ?? null,
        status: 'PROCESSING',
        locked_at: lockedAt,
        expires_at: expiresAt,
        response_payload: null,
      });

    if (insertError) {
      // Handle unique constraint conflict race condition
      if (insertError.code === '23505') {
        throw new IdempotencyConflictError(
          `Concurrent acquisition detected for key '${key}'`
        );
      }
      throw new Error(`Failed to acquire idempotency lock: ${insertError.message}`);
    }

    return { acquired: true };
  }

  /**
   * Finalizes the operation by recording the resolved response payload.
   */
  static async resolveLock<T = Json>(
    key: string,
    payload: T,
    options: IdempotencyOptions = {}
  ): Promise<void> {
    const supabase = createAdminClient();
    const retentionSeconds = options.retentionSeconds ?? DEFAULT_RETENTION_SECONDS;
    const expiresAt = new Date(Date.now() + retentionSeconds * 1000).toISOString();

    const { error } = await supabase
      .from('idempotency_keys')
      .update({
        status: 'RESOLVED',
        response_payload: payload as unknown as Json,
        expires_at: expiresAt,
      })
      .eq('key', key);

    if (error) {
      throw new Error(`Failed to resolve idempotency lock for key '${key}': ${error.message}`);
    }
  }

  /**
   * Releases an acquired lock on unexpected failure, enabling subsequent retries.
   */
  static async releaseLock(key: string): Promise<void> {
    const supabase = createAdminClient();

    const { error } = await supabase
      .from('idempotency_keys')
      .update({
        status: 'FAILED',
        expires_at: new Date().toISOString(),
      })
      .eq('key', key);

    if (error) {
      console.error(`Failed to release idempotency lock for key '${key}':`, error.message);
    }
  }

  /**
   * Executes an async operation with end-to-end idempotency protection.
   */
  static async execute<T extends Json>(
    key: string,
    operation: () => Promise<T>,
    options: IdempotencyOptions = {}
  ): Promise<T> {
    const { acquired, cachedData } = await this.acquireLock<T>(key, options);

    if (!acquired && cachedData !== undefined) {
      return cachedData;
    }

    try {
      const result = await operation();
      await this.resolveLock<T>(key, result, options);
      return result;
    } catch (error) {
      await this.releaseLock(key);
      throw error;
    }
  }
}
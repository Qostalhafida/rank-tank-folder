import { createAdminClient } from '@/lib/supabase/admin';

interface ResolvedDomainData {
  subaccountId: string;
  slug: string;
  status: string;
}

const DEFAULT_CACHE_TTL_SECONDS = 3600; // 1 hour

/**
 * Resolves a custom hostname to its corresponding subaccount slug.
 * Utilizes an Edge KV store (e.g., Upstash / Vercel KV) when available,
 * falling back to the database with cache warming.
 */
export async function resolveDomainSlug(hostname: string): Promise<string | null> {
  const normalizedHost = hostname.toLowerCase().trim();
  const kvUrl = process.env.KV_REST_API_URL;
  const kvToken = process.env.KV_REST_API_TOKEN;

  // 1. Attempt lookup from Edge KV via REST
  if (kvUrl && kvToken) {
    try {
      const kvRes = await fetch(`${kvUrl}/get/domain:${normalizedHost}`, {
        headers: {
          Authorization: `Bearer ${kvToken}`,
        },
        next: { revalidate: 300 }, // In-memory edge cache revalidation window
      });

      if (kvRes.ok) {
        const json = await kvRes.json();
        if (json.result) {
          const parsed: ResolvedDomainData = typeof json.result === 'string'
            ? JSON.parse(json.result)
            : json.result;
          return parsed.slug;
        }
      }
    } catch (err) {
      console.warn('Edge KV read error, falling back to database query:', err);
    }
  }

  // 2. Database Fallback (Admin client bypasses RLS)
  const supabase = createAdminClient();

  const { data, error } = await supabase
    .from('custom_domains')
    .select(`
      subaccount_id,
      status,
      subaccounts (
        slug
      )
    `)
    .eq('hostname', normalizedHost)
    .eq('status', 'ACTIVE')
    .maybeSingle();

  if (error || !data || !data.subaccounts) {
    return null;
  }

  const subaccount = Array.isArray(data.subaccounts)
    ? data.subaccounts[0]
    : data.subaccounts;

  if (!subaccount?.slug) {
    return null;
  }

  const resolvedData: ResolvedDomainData = {
    subaccountId: data.subaccount_id,
    slug: subaccount.slug,
    status: data.status,
  };

  // 3. Asynchronously warm the KV cache for subsequent Edge requests
  if (kvUrl && kvToken) {
    cacheDomainMapping(normalizedHost, resolvedData).catch((err) => {
      console.error('Failed to warm Edge KV cache:', err);
    });
  }

  return resolvedData.slug;
}

/**
 * Stores the domain-to-slug mapping in the Edge KV store.
 */
export async function cacheDomainMapping(
  hostname: string,
  data: ResolvedDomainData,
  ttlSeconds = DEFAULT_CACHE_TTL_SECONDS
): Promise<void> {
  const kvUrl = process.env.KV_REST_API_URL;
  const kvToken = process.env.KV_REST_API_TOKEN;

  if (!kvUrl || !kvToken) return;

  const normalizedHost = hostname.toLowerCase().trim();

  await fetch(`${kvUrl}/set/domain:${normalizedHost}?ex=${ttlSeconds}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${kvToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
}

/**
 * Invalidates the cached domain mapping upon domain deletion or updates.
 */
export async function invalidateDomainCache(hostname: string): Promise<void> {
  const kvUrl = process.env.KV_REST_API_URL;
  const kvToken = process.env.KV_REST_API_TOKEN;

  if (!kvUrl || !kvToken) return;

  const normalizedHost = hostname.toLowerCase().trim();

  await fetch(`${kvUrl}/del/domain:${normalizedHost}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${kvToken}`,
    },
  });
}
import { createServerClient } from '@/lib/supabase/server';
import { hasPermission } from '@/lib/auth/permissions';
import { AuthUserSession, PermissionAction, UserRole } from '@/types/rbac';

export class AuthenticationError extends Error {
  constructor(message = 'Authentication required') {
    super(message);
    this.name = 'AuthenticationError';
  }
}

export class AuthorizationError extends Error {
  constructor(message = 'Forbidden: Insufficient permissions') {
    super(message);
    this.name = 'AuthorizationError';
  }
}

/**
 * Retrieves the currently authenticated user and resolves their tenant context and permissions.
 */
export async function getSessionContext(subaccountId?: string): Promise<AuthUserSession> {
  const supabase = await createServerClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    throw new AuthenticationError('Invalid or expired authentication session');
  }

  // 1. Check if user is an Agency Super Admin / Agency Member
  const { data: agencyMember } = await supabase
    .from('agency_members')
    .select('agency_id, role')
    .eq('user_id', user.id)
    .maybeSingle();

  if (agencyMember) {
    const role = agencyMember.role as UserRole;
    return {
      userId: user.id,
      email: user.email ?? '',
      agencyId: agencyMember.agency_id,
      subaccountId,
      role,
      permissions: (await import('@/lib/auth/permissions')).getPermissionsForRole(role) as PermissionAction[],
    };
  }

  // 2. If subaccountId is provided, resolve subaccount-scoped membership
  if (subaccountId) {
    const { data: subaccountMember, error: subaccountError } = await supabase
      .from('subaccount_members')
      .select('subaccount_id, role')
      .eq('user_id', user.id)
      .eq('subaccount_id', subaccountId)
      .single();

    if (subaccountError || !subaccountMember) {
      throw new AuthorizationError('You do not have access to this subaccount');
    }

    const role = subaccountMember.role as UserRole;
    return {
      userId: user.id,
      email: user.email ?? '',
      subaccountId: subaccountMember.subaccount_id,
      role,
      permissions: (await import('@/lib/auth/permissions')).getPermissionsForRole(role) as PermissionAction[],
    };
  }

  // 3. Fallback for users without an explicit subaccount scope in request
  const { data: defaultMembership } = await supabase
    .from('subaccount_members')
    .select('subaccount_id, role')
    .eq('user_id', user.id)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();

  if (!defaultMembership) {
    throw new AuthorizationError('No assigned agency or subaccount found for user');
  }

  const role = defaultMembership.role as UserRole;
  return {
    userId: user.id,
    email: user.email ?? '',
    subaccountId: defaultMembership.subaccount_id,
    role,
    permissions: (await import('@/lib/auth/permissions')).getPermissionsForRole(role) as PermissionAction[],
  };
}

/**
 * Server Action Guard: Enforces authentication and specific permission within a subaccount context.
 */
export async function requirePermission(
  subaccountId: string,
  permission: PermissionAction
): Promise<AuthUserSession> {
  const session = await getSessionContext(subaccountId);

  // Agency super admins bypass subaccount-level restrictions
  if (session.role === 'AGENCY_SUPER_ADMIN') {
    return session;
  }

  const permitted = hasPermission(session.role, permission);
  if (!permitted) {
    throw new AuthorizationError(
      `Permission denied: Requires "${permission}" (Current role: ${session.role})`
    );
  }

  return session;
}

/**
 * Server Action Guard: Enforces Agency-level access.
 */
export async function requireAgencyRole(
  allowedRoles: UserRole[] = ['AGENCY_SUPER_ADMIN', 'AGENCY_ADMIN']
): Promise<AuthUserSession> {
  const session = await getSessionContext();

  if (!allowedRoles.includes(session.role)) {
    throw new AuthorizationError('Restricted to Agency Administrators');
  }

  return session;
}
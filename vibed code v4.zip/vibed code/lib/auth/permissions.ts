import { UserRole, PermissionAction } from '@/types/rbac';

export const ALL_PERMISSIONS: readonly PermissionAction[] = [
  'contacts:read',
  'contacts:write',
  'contacts:delete',
  'contacts:export',
  'pipelines:read',
  'pipelines:write',
  'pipelines:move_stage',
  'pipelines:delete',
  'orders:read',
  'orders:write',
  'orders:update_status',
  'orders:cancel',
  'orders:print_waybills',
  'funnels:read',
  'funnels:write',
  'funnels:publish',
  'storefront:read',
  'storefront:write',
  'products:read',
  'products:write',
  'products:delete',
  'digital:upload',
  'digital:manage_keys',
  'booking:read',
  'booking:write',
  'booking:configure_schedule',
  'workflows:read',
  'workflows:write',
  'workflows:execute',
  'settings:read',
  'settings:write',
  'settings:domains',
  'settings:pixels',
  'settings:webhooks',
  'team:manage',
  'agency:manage_all',
] as const;

export const ROLE_PERMISSIONS: Record<UserRole, readonly PermissionAction[]> = {
  AGENCY_SUPER_ADMIN: ALL_PERMISSIONS,

  AGENCY_ADMIN: ALL_PERMISSIONS.filter(
    (permission) => permission !== 'agency:manage_all'
  ),

  AGENCY_ACCOUNT_MANAGER: [
    'contacts:read',
    'contacts:write',
    'contacts:export',
    'pipelines:read',
    'pipelines:write',
    'pipelines:move_stage',
    'orders:read',
    'orders:write',
    'orders:update_status',
    'orders:print_waybills',
    'funnels:read',
    'funnels:write',
    'funnels:publish',
    'storefront:read',
    'storefront:write',
    'products:read',
    'products:write',
    'booking:read',
    'booking:write',
    'workflows:read',
    'workflows:write',
    'settings:read',
  ],

  SUBACCOUNT_OWNER: [
    'contacts:read',
    'contacts:write',
    'contacts:delete',
    'contacts:export',
    'pipelines:read',
    'pipelines:write',
    'pipelines:move_stage',
    'pipelines:delete',
    'orders:read',
    'orders:write',
    'orders:update_status',
    'orders:cancel',
    'orders:print_waybills',
    'funnels:read',
    'funnels:write',
    'funnels:publish',
    'storefront:read',
    'storefront:write',
    'products:read',
    'products:write',
    'products:delete',
    'digital:upload',
    'digital:manage_keys',
    'booking:read',
    'booking:write',
    'booking:configure_schedule',
    'workflows:read',
    'workflows:write',
    'workflows:execute',
    'settings:read',
    'settings:write',
    'settings:domains',
    'settings:pixels',
    'settings:webhooks',
    'team:manage',
  ],

  SUBACCOUNT_ADMIN: [
    'contacts:read',
    'contacts:write',
    'contacts:delete',
    'contacts:export',
    'pipelines:read',
    'pipelines:write',
    'pipelines:move_stage',
    'pipelines:delete',
    'orders:read',
    'orders:write',
    'orders:update_status',
    'orders:cancel',
    'orders:print_waybills',
    'funnels:read',
    'funnels:write',
    'funnels:publish',
    'storefront:read',
    'storefront:write',
    'products:read',
    'products:write',
    'digital:upload',
    'digital:manage_keys',
    'booking:read',
    'booking:write',
    'booking:configure_schedule',
    'workflows:read',
    'workflows:write',
    'settings:read',
    'settings:write',
    'settings:pixels',
    'settings:webhooks',
    'team:manage',
  ],

  SUBACCOUNT_AGENT: [
    'contacts:read',
    'contacts:write',
    'pipelines:read',
    'pipelines:write',
    'pipelines:move_stage',
    'orders:read',
    'orders:write',
    'orders:update_status',
    'orders:print_waybills',
    'booking:read',
    'booking:write',
    'products:read',
  ],

  SUBACCOUNT_STAFF: [
    'contacts:read',
    'orders:read',
    'orders:update_status',
    'orders:print_waybills',
    'products:read',
    'booking:read',
  ],
};

export function getPermissionsForRole(role: UserRole): readonly PermissionAction[] {
  return ROLE_PERMISSIONS[role] ?? [];
}

export function hasPermission(role: UserRole, action: PermissionAction): boolean {
  const permissions = ROLE_PERMISSIONS[role];
  if (!permissions) return false;
  return permissions.includes(action);
}

export function hasAnyPermission(role: UserRole, actions: PermissionAction[]): boolean {
  const permissions = ROLE_PERMISSIONS[role];
  if (!permissions) return false;
  return actions.some((action) => permissions.includes(action));
}

export function hasAllPermissions(role: UserRole, actions: PermissionAction[]): boolean {
  const permissions = ROLE_PERMISSIONS[role];
  if (!permissions) return false;
  return actions.every((action) => permissions.includes(action));
}
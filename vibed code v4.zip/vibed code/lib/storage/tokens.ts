import { createHmac, timingSafeEqual } from 'crypto';
import { createAdminClient } from '@/lib/supabase/admin';
import { SecureDownloadTokenPayload } from '@/types/digital';

const TOKEN_SECRET = process.env.DOWNLOAD_TOKEN_SECRET || 'secure-download-token-secret-key-32-chars';
const DEFAULT_DOWNLOAD_TTL_SECONDS = 86400; // 24 hours
const PRIVATE_BUCKET_NAME = 'subaccount-digital-vault';

export class InvalidTokenError extends Error {
  constructor(message = 'Invalid or expired download token') {
    super(message);
    this.name = 'InvalidTokenError';
  }
}

/**
 * Encodes and signs a secure download token payload.
 */
export function generateDownloadToken(
  params: Omit<SecureDownloadTokenPayload, 'token_id' | 'expires_at'> & {
    ttlSeconds?: number;
  }
): string {
  const tokenId = crypto.randomUUID();
  const ttl = params.ttlSeconds ?? DEFAULT_DOWNLOAD_TTL_SECONDS;
  const expiresAt = Math.floor(Date.now() / 1000) + ttl;

  const payload: SecureDownloadTokenPayload = {
    token_id: tokenId,
    subaccount_id: params.subaccount_id,
    order_id: params.order_id,
    asset_id: params.asset_id,
    contact_id: params.contact_id,
    max_downloads: params.max_downloads,
    download_count: params.download_count,
    expires_at: expiresAt,
  };

  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = createHmac('sha256', TOKEN_SECRET)
    .update(encodedPayload)
    .digest('base64url');

  return `${encodedPayload}.${signature}`;
}

/**
 * Validates token signature, checks expiration, and returns payload.
 */
export function verifyDownloadToken(tokenString: string): SecureDownloadTokenPayload {
  const parts = tokenString.split('.');
  if (parts.length !== 2) {
    throw new InvalidTokenError('Malformed token structure');
  }

  const [encodedPayload, signature] = parts;

  // Verify HMAC signature
  const expectedSignature = createHmac('sha256', TOKEN_SECRET)
    .update(encodedPayload)
    .digest('base64url');

  const signatureBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expectedSignature);

  if (
    signatureBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(signatureBuffer, expectedBuffer)
  ) {
    throw new InvalidTokenError('Digital token signature validation failed');
  }

  try {
    const jsonString = Buffer.from(encodedPayload, 'base64url').toString('utf-8');
    const payload: SecureDownloadTokenPayload = JSON.parse(jsonString);

    const now = Math.floor(Date.now() / 1000);
    if (payload.expires_at < now) {
      throw new InvalidTokenError('Download link has expired');
    }

    if (payload.max_downloads > 0 && payload.download_count >= payload.max_downloads) {
      throw new InvalidTokenError('Maximum download allowance reached');
    }

    return payload;
  } catch (err) {
    if (err instanceof InvalidTokenError) throw err;
    throw new InvalidTokenError('Failed to parse token payload');
  }
}

/**
 * Creates a short-lived signed URL for direct streaming from the Supabase private vault.
 */
export async function createSignedVaultUrl(
  storagePath: string,
  expiresInSeconds = 60
): Promise<string> {
  const supabase = createAdminClient();

  const { data, error } = await supabase.storage
    .from(PRIVATE_BUCKET_NAME)
    .createSignedUrl(storagePath, expiresInSeconds);

  if (error || !data?.signedUrl) {
    throw new Error(`Failed to generate signed URL for vault asset: ${error?.message}`);
  }

  return data.signedUrl;
}
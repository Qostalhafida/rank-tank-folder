import { createClient } from '@supabase/supabase-js';
import { Database } from '@/types/database';

let adminClient: ReturnType<typeof createClient<Database>> | undefined;

/**
 * Creates or returns an elevated Supabase client authenticated via the Service Role Key.
 * Bypasses Row-Level Security (RLS).
 *
 * CAUTION: Use strictly within trusted server environments (e.g., Inngest jobs,
 * background webhooks, and idempotent transaction processing).
 */
export function createAdminClient() {
  if (adminClient) return adminClient;

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error(
      'Missing environment variables: NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required for admin operations'
    );
  }

  adminClient = createClient<Database>(supabaseUrl, serviceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  return adminClient;
}
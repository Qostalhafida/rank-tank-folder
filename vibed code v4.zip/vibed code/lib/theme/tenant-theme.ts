import { SupportedLocale, TenantThemeConfig } from '@/types/subaccount';

const RTL_LOCALES: readonly SupportedLocale[] = ['ar'];

/**
 * Determines text direction (LTR or RTL) based on locale.
 */
export function getLocaleDirection(locale: string): 'rtl' | 'ltr' {
  return RTL_LOCALES.includes(locale as SupportedLocale) ? 'rtl' : 'ltr';
}

/**
 * Converts a 6-character hex color code into RGB numbers.
 */
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const sanitized = hex.replace('#', '').trim();
  const fullHex = sanitized.length === 3
    ? sanitized.split('').map((char) => char + char).join('')
    : sanitized;

  const num = parseInt(fullHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

/**
 * Calculates luminance to determine optimal foreground contrast (black or white).
 */
function getContrastForeground(hex: string): string {
  try {
    const { r, g, b } = hexToRgb(hex);
    // Relative luminance formula per WCAG 2.1
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.55 ? '#0f172a' : '#ffffff';
  } catch {
    return '#ffffff';
  }
}

/**
 * Maps the theme border radius config to a CSS length string.
 */
function getBorderRadiusValue(radius?: TenantThemeConfig['borderRadius']): string {
  switch (radius) {
    case 'none':
      return '0rem';
    case 'sm':
      return '0.25rem';
    case 'lg':
      return '0.75rem';
    case 'full':
      return '9999px';
    case 'md':
    default:
      return '0.5rem';
  }
}

/**
 * Generates an inline CSS variable string dynamically bound to the tenant configuration.
 * Directly integrates with Tailwind CSS CSS variable conventions.
 */
export function generateTenantThemeStyles(theme?: Partial<TenantThemeConfig> | null): string {
  const primary = theme?.primaryColor || '#2563eb';
  const secondary = theme?.secondaryColor || '#64748b';
  const accent = theme?.accentColor || '#f59e0b';
  const radius = getBorderRadiusValue(theme?.borderRadius);

  const primaryForeground = getContrastForeground(primary);
  const secondaryForeground = getContrastForeground(secondary);
  const accentForeground = getContrastForeground(accent);

  return `
    :root {
      --primary: ${primary};
      --primary-foreground: ${primaryForeground};
      --secondary: ${secondary};
      --secondary-foreground: ${secondaryForeground};
      --accent: ${accent};
      --accent-foreground: ${accentForeground};
      --radius: ${radius};
    }
  `.replace(/\s+/g, ' ').trim();
}
import {
  Calendar,
  Appointment,
  AvailableSlot,
  DayOfWeek,
  CalendarIcsData,
} from '@/types/booking';

const DAY_MAP: Record<number, DayOfWeek> = {
  0: 'sunday',
  1: 'monday',
  2: 'tuesday',
  3: 'wednesday',
  4: 'thursday',
  5: 'friday',
  6: 'saturday',
};

function parseTimeToMinutes(timeStr: string): number {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return hours * 60 + minutes;
}

/**
 * Computes available booking time slots for a specific target date
 * based on calendar working hours, buffers, and existing appointments.
 */
export function calculateAvailableSlots(
  calendar: Calendar,
  existingAppointments: Pick<Appointment, 'start_time' | 'end_time' | 'status'>[],
  targetDate: Date
): AvailableSlot[] {
  const dayOfWeek = DAY_MAP[targetDate.getUTCDay()];
  const scheduleForDay = calendar.weekly_schedule[dayOfWeek];

  if (!scheduleForDay || !scheduleForDay.isOpen || !scheduleForDay.windows.length) {
    return [];
  }

  const activeAppointments = existingAppointments.filter(
    (app) => app.status !== 'CANCELLED'
  );

  const year = targetDate.getUTCFullYear();
  const month = targetDate.getUTCMonth();
  const day = targetDate.getUTCDate();

  const totalSlotDuration = calendar.duration_minutes;
  const bufferBefore = calendar.buffer_before || 0;
  const bufferAfter = calendar.buffer_after || 0;
  const stepMinutes = totalSlotDuration + bufferAfter;

  const slots: AvailableSlot[] = [];

  for (const window of scheduleForDay.windows) {
    const windowStartMinutes = parseTimeToMinutes(window.start) + bufferBefore;
    const windowEndMinutes = parseTimeToMinutes(window.end);

    let currentStartMinutes = windowStartMinutes;

    while (currentStartMinutes + totalSlotDuration <= windowEndMinutes) {
      const slotStart = new Date(Date.UTC(year, month, day, 0, currentStartMinutes, 0, 0));
      const slotEnd = new Date(Date.UTC(year, month, day, 0, currentStartMinutes + totalSlotDuration, 0, 0));

      // Check collision with existing appointments (including their respective buffers)
      const hasConflict = activeAppointments.some((appt) => {
        const apptStart = new Date(appt.start_time).getTime();
        const apptEnd = new Date(appt.end_time).getTime();

        return slotStart.getTime() < apptEnd && slotEnd.getTime() > apptStart;
      });

      slots.push({
        startTime: slotStart.toISOString(),
        endTime: slotEnd.toISOString(),
        available: !hasConflict,
      });

      currentStartMinutes += stepMinutes;
    }
  }

  return slots;
}

/**
 * Formats a Date object into an iCalendar (RFC 5545) UTC date-time string.
 * Example: 20260928T140000Z
 */
function formatIcsDateTime(date: Date): string {
  return date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

/**
 * Generates an RFC 5545 compliant .ics calendar event content string for download and export.
 */
export function generateIcsCalendar(data: CalendarIcsData): string {
  const uid = `${Date.now()}-${crypto.randomUUID()}@platform`;
  const dtStamp = formatIcsDateTime(new Date());
  const dtStart = formatIcsDateTime(data.startTime);
  const dtEnd = formatIcsDateTime(data.endTime);

  const cleanDescription = (data.description || '')
    .replace(/\n/g, '\\n')
    .replace(/,/g, '\\,');

  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//MultiTenant E-commerce Platform//Native Booking//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:REQUEST',
    'BEGIN:VEVENT',
    `UID:${uid}`,
    `DTSTAMP:${dtStamp}`,
    `DTSTART:${dtStart}`,
    `DTEND:${dtEnd}`,
    `SUMMARY:${data.title}`,
    `DESCRIPTION:${cleanDescription}`,
    `ORGANIZER;CN=${data.organizerName}:mailto:${data.organizerEmail}`,
    `ATTENDEE;CUTYPE=INDIVIDUAL;ROLE=REQ-PARTICIPANT;PARTSTAT=ACCEPTED;CN=${data.attendeeName}:mailto:${data.attendeeEmail}`,
    'STATUS:CONFIRMED',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}
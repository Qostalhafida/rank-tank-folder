export interface CloudflareDnsRecord {
  type: 'CNAME' | 'TXT';
  name: string;
  value: string;
}

export interface CloudflareHostnameResult {
  id: string;
  hostname: string;
  status: 'pending' | 'active' | 'pending_deletion' | 'moved' | 'blocked';
  sslStatus: 'initializing' | 'pending_validation' | 'active' | 'expired' | 'deleted';
  ownershipVerification: CloudflareDnsRecord | null;
  sslVerification: CloudflareDnsRecord | null;
  cnameTarget: string;
  verificationErrors: string[];
}

interface CloudflareApiResponse<T> {
  success: boolean;
  errors: { code: number; message: string }[];
  messages: string[];
  result: T;
}

interface RawCloudflareHostname {
  id: string;
  hostname: string;
  status: 'pending' | 'active' | 'pending_deletion' | 'moved' | 'blocked';
  verification_errors?: string[];
  ownership_verification?: {
    type: 'txt' | 'cname';
    name: string;
    value: string;
  };
  ssl?: {
    status: 'initializing' | 'pending_validation' | 'active' | 'expired' | 'deleted';
    method?: string;
    type?: string;
    txt_name?: string;
    txt_value?: string;
    cname?: string;
    cname_target?: string;
  };
}

const CLOUDFLARE_API_URL = 'https://api.cloudflare.com/client/v4';

function getCredentials() {
  const apiToken = process.env.CLOUDFLARE_API_TOKEN;
  const zoneId = process.env.CLOUDFLARE_ZONE_ID;
  const cnameTarget = process.env.NEXT_PUBLIC_CNAME_TARGET || 'cname.yourplatform.com';

  if (!apiToken || !zoneId) {
    throw new Error('Missing Cloudflare configuration: CLOUDFLARE_API_TOKEN or CLOUDFLARE_ZONE_ID');
  }

  return { apiToken, zoneId, cnameTarget };
}

function parseCloudflareResult(
  data: RawCloudflareHostname,
  cnameTarget: string
): CloudflareHostnameResult {
  let ownershipVerification: CloudflareDnsRecord | null = null;
  if (data.ownership_verification) {
    ownershipVerification = {
      type: data.ownership_verification.type.toUpperCase() as 'CNAME' | 'TXT',
      name: data.ownership_verification.name,
      value: data.ownership_verification.value,
    };
  }

  let sslVerification: CloudflareDnsRecord | null = null;
  if (data.ssl?.txt_name && data.ssl?.txt_value) {
    sslVerification = {
      type: 'TXT',
      name: data.ssl.txt_name,
      value: data.ssl.txt_value,
    };
  } else if (data.ssl?.cname && data.ssl?.cname_target) {
    sslVerification = {
      type: 'CNAME',
      name: data.ssl.cname,
      value: data.ssl.cname_target,
    };
  }

  return {
    id: data.id,
    hostname: data.hostname,
    status: data.status,
    sslStatus: data.ssl?.status ?? 'initializing',
    ownershipVerification,
    sslVerification,
    cnameTarget,
    verificationErrors: data.verification_errors ?? [],
  };
}

/**
 * Creates and registers a custom hostname under Cloudflare for SaaS.
 */
export async function createCustomHostname(hostname: string): Promise<CloudflareHostnameResult> {
  const { apiToken, zoneId, cnameTarget } = getCredentials();

  const response = await fetch(`${CLOUDFLARE_API_URL}/zones/${zoneId}/custom_hostnames`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      hostname,
      ssl: {
        method: 'txt',
        type: 'dv',
        settings: {
          min_tls_version: '1.2',
          http2: 'on',
        },
      },
    }),
  });

  const payload: CloudflareApiResponse<RawCloudflareHostname> = await response.json();

  if (!payload.success || !payload.result) {
    const errorMsg = payload.errors.map((e) => e.message).join(', ');
    throw new Error(`Cloudflare custom hostname creation failed: ${errorMsg}`);
  }

  return parseCloudflareResult(payload.result, cnameTarget);
}

/**
 * Retrieves the verification status and required DNS records for an existing custom hostname.
 */
export async function getCustomHostname(hostnameId: string): Promise<CloudflareHostnameResult> {
  const { apiToken, zoneId, cnameTarget } = getCredentials();

  const response = await fetch(
    `${CLOUDFLARE_API_URL}/zones/${zoneId}/custom_hostnames/${hostnameId}`,
    {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${apiToken}`,
        'Content-Type': 'application/json',
      },
      next: { revalidate: 0 },
    }
  );

  const payload: CloudflareApiResponse<RawCloudflareHostname> = await response.json();

  if (!payload.success || !payload.result) {
    const errorMsg = payload.errors.map((e) => e.message).join(', ');
    throw new Error(`Failed to fetch Cloudflare custom hostname: ${errorMsg}`);
  }

  return parseCloudflareResult(payload.result, cnameTarget);
}

/**
 * Removes a custom hostname from Cloudflare.
 */
export async function deleteCustomHostname(hostnameId: string): Promise<void> {
  const { apiToken, zoneId } = getCredentials();

  const response = await fetch(
    `${CLOUDFLARE_API_URL}/zones/${zoneId}/custom_hostnames/${hostnameId}`,
    {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${apiToken}`,
        'Content-Type': 'application/json',
      },
    }
  );

  const payload: CloudflareApiResponse<{ id: string }> = await response.json();

  if (!payload.success) {
    const errorMsg = payload.errors.map((e) => e.message).join(', ');
    throw new Error(`Failed to delete Cloudflare custom hostname: ${errorMsg}`);
  }
}
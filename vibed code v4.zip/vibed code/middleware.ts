import { NextResponse, type NextRequest } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { SupportedLocale } from '@/types/subaccount';

const SUPPORTED_LOCALES: SupportedLocale[] = ['en', 'ar', 'fr', 'es', 'pt', 'it'];
const DEFAULT_LOCALE: SupportedLocale = 'en';

/**
 * Extracts preferred locale from the Accept-Language header.
 */
function getPreferredLocale(request: NextRequest): SupportedLocale {
  const acceptLanguage = request.headers.get('accept-language');
  if (!acceptLanguage) return DEFAULT_LOCALE;

  const detected = acceptLanguage
    .split(',')
    .map((lang) => lang.split(';')[0].trim().toLowerCase().slice(0, 2))
    .find((code): code is SupportedLocale =>
      SUPPORTED_LOCALES.includes(code as SupportedLocale)
    );

  return detected ?? DEFAULT_LOCALE;
}

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  });

  const { pathname } = request.nextUrl;
  const hostname = request.headers.get('host') || '';

  // 1. Refresh Supabase Session Cookies at the Edge
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (supabaseUrl && supabaseAnonKey) {
    const supabase = createServerClient(supabaseUrl, supabaseAnonKey, {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          );
          response = NextResponse.next({
            request,
          });
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          );
        },
      },
    });

    await supabase.auth.getUser();
  }

  // 2. Bypass static assets, internal paths, and API routes
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.includes('.')
  ) {
    return response;
  }

  // 3. Agency Super-Admin Routing (Agency domain / root agency paths)
  const isAgencyHost =
    hostname === process.env.NEXT_PUBLIC_AGENCY_DOMAIN ||
    hostname.startsWith('admin.') ||
    pathname.startsWith('/agency') ||
    pathname.startsWith('/login');

  if (isAgencyHost && (pathname.startsWith('/agency') || pathname.startsWith('/login'))) {
    return response;
  }

  // 4. Custom Domain Resolution via Edge Header or KV
  // Cloudflare for SaaS passes original custom domain in `host`
  const appDomain = process.env.NEXT_PUBLIC_APP_DOMAIN || 'localhost:3000';
  const isCustomDomain =
    hostname !== appDomain &&
    !hostname.endsWith(`.${appDomain.replace(/:.*/, '')}`);

  let subaccountSlug: string | null = null;

  if (isCustomDomain) {
    // Resolved from Edge KV cache header or edge resolver fallback
    subaccountSlug = request.headers.get('x-subaccount-slug');

    if (!subaccountSlug) {
      // Query fallback domain-to-slug mapping if not pre-populated by Cloudflare Worker
      try {
        const domainLookupUrl = new URL(
          `/api/edge/resolve-domain?host=${encodeURIComponent(hostname)}`,
          request.url
        );
        const lookupRes = await fetch(domainLookupUrl.toString(), {
          headers: { 'x-internal-secret': process.env.INTERNAL_SERVICE_KEY || '' },
        });
        if (lookupRes.ok) {
          const data = await lookupRes.json();
          subaccountSlug = data.slug ?? null;
        }
      } catch {
        subaccountSlug = null;
      }
    }
  }

  const segments = pathname.split('/').filter(Boolean);

  // 5. Handle Custom Domain Path Rewriting: (domain.com/cart -> /[slug]/[locale]/cart)
  if (isCustomDomain && subaccountSlug) {
    const hasLocale = SUPPORTED_LOCALES.includes(segments[0] as SupportedLocale);
    const activeLocale = hasLocale ? (segments[0] as SupportedLocale) : getPreferredLocale(request);
    const restPath = hasLocale
      ? `/${segments.slice(1).join('/')}`
      : pathname;

    return NextResponse.rewrite(
      new URL(`/${subaccountSlug}/${activeLocale}${restPath}`, request.url),
      {
        headers: {
          'x-subaccount-slug': subaccountSlug,
          'x-active-locale': activeLocale,
        },
      }
    );
  }

  // 6. Handle Multi-Tenant Subpath Routing: /[subaccountSlug]/[locale]/...
  if (segments.length >= 1) {
    const candidateSlug = segments[0];
    const candidateLocale = segments[1];

    const isLocalePresent = SUPPORTED_LOCALES.includes(
      candidateLocale as SupportedLocale
    );

    // If /[subaccountSlug] without locale, redirect to /[subaccountSlug]/[defaultLocale]
    if (!isLocalePresent && !SUPPORTED_LOCALES.includes(candidateSlug as SupportedLocale)) {
      const preferredLocale = getPreferredLocale(request);
      return NextResponse.redirect(
        new URL(`/${candidateSlug}/${preferredLocale}${pathname.slice(candidateSlug.length + 1)}`, request.url)
      );
    }
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public files (images, assets)
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
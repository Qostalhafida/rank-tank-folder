export interface Tag {
  id: string;
  subaccount_id: string;
  name: string;
  color: string;
  created_at: string;
  contacts_count?: number;
}

export interface Contact {
  id: string;
  subaccount_id: string;
  first_name: string | null;
  last_name: string | null;
  email: string | null;
  phone: string | null;
  address_line1: string | null;
  address_line2: string | null;
  city: string | null;
  province: string | null;
  postal_code: string | null;
  country: string | null;
  lifetime_value: number;
  orders_count: number;
  created_at: string;
  updated_at: string;
  tags?: Tag[];
}

export type OpportunityStatus = 'OPEN' | 'WON' | 'LOST' | 'ABANDONED';

export interface Opportunity {
  id: string;
  subaccount_id: string;
  pipeline_id: string;
  stage_id: string;
  contact_id: string;
  title: string;
  value: number;
  currency: string;
  status: OpportunityStatus;
  position: number;
  /**
   * Monotonically increasing version number for Optimistic Concurrency Control (OCC).
   * Prevents race conditions during simultaneous drag-and-drop actions.
   */
  version: number;
  created_at: string;
  updated_at: string;
  contact?: Pick<Contact, 'id' | 'first_name' | 'last_name' | 'email' | 'phone'>;
  locked_by?: {
    user_id: string;
    user_name: string;
    locked_at: string;
  } | null;
}

export interface PipelineStage {
  id: string;
  pipeline_id: string;
  subaccount_id: string;
  name: string;
  position: number;
  color: string;
  created_at: string;
  updated_at: string;
  opportunities?: Opportunity[];
  total_value?: number;
  opportunities_count?: number;
}

export interface Pipeline {
  id: string;
  subaccount_id: string;
  name: string;
  position: number;
  stages: PipelineStage[];
  created_at: string;
  updated_at: string;
}

export interface MoveOpportunityInput {
  opportunityId: string;
  subaccountId: string;
  targetStageId: string;
  targetPosition: number;
  /**
   * The version known by the client before the move.
   * If the version in the database is higher, the OCC guard rejects the move.
   */
  expectedVersion: number;
}

export interface ContactFilterParams {
  search?: string;
  tagIds?: string[];
  minLtv?: number;
  maxLtv?: number;
  page?: number;
  pageSize?: number;
  sortBy?: 'created_at' | 'lifetime_value' | 'orders_count' | 'first_name';
  sortOrder?: 'asc' | 'desc';
}

export class ConcurrencyConflictError extends Error {
  constructor(
    message = 'The deal was modified by another user. Please refresh and try again.'
  ) {
    super(message);
    this.name = 'ConcurrencyConflictError';
  }
}
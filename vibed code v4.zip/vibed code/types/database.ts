export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type MultilingualText = {
  en?: string;
  ar?: string;
  fr?: string;
  es?: string;
  pt?: string;
  it?: string;
  [locale: string]: string | undefined;
};

export interface Database {
  public: {
    Tables: {
      agencies: {
        Row: {
          id: string;
          name: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      agency_members: {
        Row: {
          id: string;
          agency_id: string;
          user_id: string;
          role: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          agency_id: string;
          user_id: string;
          role: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          agency_id?: string;
          user_id?: string;
          role?: string;
          created_at?: string;
        };
      };
      subaccounts: {
        Row: {
          id: string;
          agency_id: string;
          name: string;
          slug: string;
          default_locale: string;
          supported_locales: string[];
          mode: 'COD' | 'ONLINE' | 'HYBRID';
          currency: string;
          theme: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          agency_id: string;
          name: string;
          slug: string;
          default_locale?: string;
          supported_locales?: string[];
          mode?: 'COD' | 'ONLINE' | 'HYBRID';
          currency?: string;
          theme?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          agency_id?: string;
          name?: string;
          slug?: string;
          default_locale?: string;
          supported_locales?: string[];
          mode?: 'COD' | 'ONLINE' | 'HYBRID';
          currency?: string;
          theme?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      subaccount_members: {
        Row: {
          id: string;
          subaccount_id: string;
          user_id: string;
          role: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          user_id: string;
          role: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          user_id?: string;
          role?: string;
          created_at?: string;
        };
      };
      contacts: {
        Row: {
          id: string;
          subaccount_id: string;
          first_name: string | null;
          last_name: string | null;
          email: string | null;
          phone: string | null;
          address_line1: string | null;
          address_line2: string | null;
          city: string | null;
          province: string | null;
          postal_code: string | null;
          country: string | null;
          lifetime_value: number;
          orders_count: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          first_name?: string | null;
          last_name?: string | null;
          email?: string | null;
          phone?: string | null;
          address_line1?: string | null;
          address_line2?: string | null;
          city?: string | null;
          province?: string | null;
          postal_code?: string | null;
          country?: string | null;
          lifetime_value?: number;
          orders_count?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          first_name?: string | null;
          last_name?: string | null;
          email?: string | null;
          phone?: string | null;
          address_line1?: string | null;
          address_line2?: string | null;
          city?: string | null;
          province?: string | null;
          postal_code?: string | null;
          country?: string | null;
          lifetime_value?: number;
          orders_count?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      tags: {
        Row: {
          id: string;
          subaccount_id: string;
          name: string;
          color: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          name: string;
          color?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          name?: string;
          color?: string;
          created_at?: string;
        };
      };
      contact_tags: {
        Row: {
          contact_id: string;
          tag_id: string;
          subaccount_id: string;
          created_at: string;
        };
        Insert: {
          contact_id: string;
          tag_id: string;
          subaccount_id: string;
          created_at?: string;
        };
        Update: {
          contact_id?: string;
          tag_id?: string;
          subaccount_id?: string;
          created_at?: string;
        };
      };
      pipelines: {
        Row: {
          id: string;
          subaccount_id: string;
          name: string;
          position: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          name: string;
          position?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          name?: string;
          position?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      pipeline_stages: {
        Row: {
          id: string;
          pipeline_id: string;
          subaccount_id: string;
          name: string;
          position: number;
          color: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          pipeline_id: string;
          subaccount_id: string;
          name: string;
          position?: number;
          color?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          pipeline_id?: string;
          subaccount_id?: string;
          name?: string;
          position?: number;
          color?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      opportunities: {
        Row: {
          id: string;
          subaccount_id: string;
          pipeline_id: string;
          stage_id: string;
          contact_id: string;
          title: string;
          value: number;
          currency: string;
          status: 'OPEN' | 'WON' | 'LOST' | 'ABANDONED';
          position: number;
          version: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          pipeline_id: string;
          stage_id: string;
          contact_id: string;
          title: string;
          value?: number;
          currency?: string;
          status?: 'OPEN' | 'WON' | 'LOST' | 'ABANDONED';
          position?: number;
          version?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          pipeline_id?: string;
          stage_id?: string;
          contact_id?: string;
          title?: string;
          value?: number;
          currency?: string;
          status?: 'OPEN' | 'WON' | 'LOST' | 'ABANDONED';
          position?: number;
          version?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      products: {
        Row: {
          id: string;
          subaccount_id: string;
          title: MultilingualText;
          description: MultilingualText;
          slug: string;
          type: 'PHYSICAL' | 'DIGITAL';
          price: number;
          compare_at_price: number | null;
          cost_per_item: number | null;
          sku: string | null;
          stock_quantity: number | null;
          is_active: boolean;
          images: string[];
          metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          title: MultilingualText;
          description?: MultilingualText;
          slug: string;
          type?: 'PHYSICAL' | 'DIGITAL';
          price: number;
          compare_at_price?: number | null;
          cost_per_item?: number | null;
          sku?: string | null;
          stock_quantity?: number | null;
          is_active?: boolean;
          images?: string[];
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          title?: MultilingualText;
          description?: MultilingualText;
          slug?: string;
          type?: 'PHYSICAL' | 'DIGITAL';
          price?: number;
          compare_at_price?: number | null;
          cost_per_item?: number | null;
          sku?: string | null;
          stock_quantity?: number | null;
          is_active?: boolean;
          images?: string[];
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      orders: {
        Row: {
          id: string;
          subaccount_id: string;
          contact_id: string;
          order_number: string;
          status: 'PENDING' | 'CONFIRMED' | 'DISPATCHED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED';
          payment_method: 'COD' | 'STRIPE' | 'PAYPAL' | 'MANUAL';
          payment_status: 'UNPAID' | 'PAID' | 'REFUNDED';
          currency: string;
          subtotal: number;
          shipping_cost: number;
          discount_amount: number;
          total_amount: number;
          waybill_number: string | null;
          shipping_address: Json;
          metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          contact_id: string;
          order_number: string;
          status?: 'PENDING' | 'CONFIRMED' | 'DISPATCHED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED';
          payment_method?: 'COD' | 'STRIPE' | 'PAYPAL' | 'MANUAL';
          payment_status?: 'UNPAID' | 'PAID' | 'REFUNDED';
          currency?: string;
          subtotal: number;
          shipping_cost?: number;
          discount_amount?: number;
          total_amount: number;
          waybill_number?: string | null;
          shipping_address: Json;
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          contact_id?: string;
          order_number?: string;
          status?: 'PENDING' | 'CONFIRMED' | 'DISPATCHED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED';
          payment_method?: 'COD' | 'STRIPE' | 'PAYPAL' | 'MANUAL';
          payment_status?: 'UNPAID' | 'PAID' | 'REFUNDED';
          currency?: string;
          subtotal?: number;
          shipping_cost?: number;
          discount_amount?: number;
          total_amount?: number;
          waybill_number?: string | null;
          shipping_address?: Json;
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string;
          subaccount_id: string;
          quantity: number;
          unit_price: number;
          total_price: number;
          product_title: MultilingualText;
          created_at: string;
        };
        Insert: {
          id?: string;
          order_id: string;
          product_id: string;
          subaccount_id: string;
          quantity: number;
          unit_price: number;
          total_price: number;
          product_title: MultilingualText;
          created_at?: string;
        };
        Update: {
          id?: string;
          order_id?: string;
          product_id?: string;
          subaccount_id?: string;
          quantity?: number;
          unit_price?: number;
          total_price?: number;
          product_title?: MultilingualText;
          created_at?: string;
        };
      };
      funnels: {
        Row: {
          id: string;
          subaccount_id: string;
          name: string;
          slug: string;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          name: string;
          slug: string;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          name?: string;
          slug?: string;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      funnel_steps: {
        Row: {
          id: string;
          funnel_id: string;
          subaccount_id: string;
          step_type: 'LANDING' | 'CHECKOUT' | 'UPSELL' | 'DOWNSELL' | 'THANK_YOU';
          position: number;
          settings: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          funnel_id: string;
          subaccount_id: string;
          step_type: 'LANDING' | 'CHECKOUT' | 'UPSELL' | 'DOWNSELL' | 'THANK_YOU';
          position: number;
          settings?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          funnel_id?: string;
          subaccount_id?: string;
          step_type?: 'LANDING' | 'CHECKOUT' | 'UPSELL' | 'DOWNSELL' | 'THANK_YOU';
          position?: number;
          settings?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      calendars: {
        Row: {
          id: string;
          subaccount_id: string;
          name: string;
          slug: string;
          duration_minutes: number;
          buffer_before: number;
          buffer_after: number;
          weekly_schedule: Json;
          timezone: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          name: string;
          slug: string;
          duration_minutes?: number;
          buffer_before?: number;
          buffer_after?: number;
          weekly_schedule: Json;
          timezone?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          name?: string;
          slug?: string;
          duration_minutes?: number;
          buffer_before?: number;
          buffer_after?: number;
          weekly_schedule?: Json;
          timezone?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      appointments: {
        Row: {
          id: string;
          calendar_id: string;
          subaccount_id: string;
          contact_id: string;
          start_time: string;
          end_time: string;
          status: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          calendar_id: string;
          subaccount_id: string;
          contact_id: string;
          start_time: string;
          end_time: string;
          status?: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          calendar_id?: string;
          subaccount_id?: string;
          contact_id?: string;
          start_time?: string;
          end_time?: string;
          status?: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      workflows: {
        Row: {
          id: string;
          subaccount_id: string;
          name: string;
          is_active: boolean;
          nodes: Json;
          edges: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          name: string;
          is_active?: boolean;
          nodes?: Json;
          edges?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          name?: string;
          is_active?: boolean;
          nodes?: Json;
          edges?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      custom_domains: {
        Row: {
          id: string;
          subaccount_id: string;
          hostname: string;
          cloudflare_hostname_id: string | null;
          status: 'PENDING' | 'ACTIVE' | 'ERROR';
          ssl_status: string;
          verification_errors: Json | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subaccount_id: string;
          hostname: string;
          cloudflare_hostname_id?: string | null;
          status?: 'PENDING' | 'ACTIVE' | 'ERROR';
          ssl_status?: string;
          verification_errors?: Json | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subaccount_id?: string;
          hostname?: string;
          cloudflare_hostname_id?: string | null;
          status?: 'PENDING' | 'ACTIVE' | 'ERROR';
          ssl_status?: string;
          verification_errors?: Json | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      idempotency_keys: {
        Row: {
          id: string;
          key: string;
          subaccount_id: string | null;
          status: 'PROCESSING' | 'RESOLVED' | 'FAILED';
          response_payload: Json | null;
          locked_at: string;
          expires_at: string;
        };
        Insert: {
          id?: string;
          key: string;
          subaccount_id?: string | null;
          status?: 'PROCESSING' | 'RESOLVED' | 'FAILED';
          response_payload?: Json | null;
          locked_at?: string;
          expires_at: string;
        };
        Update: {
          id?: string;
          key?: string;
          subaccount_id?: string | null;
          status?: 'PROCESSING' | 'RESOLVED' | 'FAILED';
          response_payload?: Json | null;
          locked_at?: string;
          expires_at?: string;
        };
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
}
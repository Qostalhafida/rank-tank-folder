export type DayOfWeek =
  | 'monday'
  | 'tuesday'
  | 'wednesday'
  | 'thursday'
  | 'friday'
  | 'saturday'
  | 'sunday';

export interface TimeWindow {
  /** 24-hour format string, e.g., "09:00" */
  start: string;
  /** 24-hour format string, e.g., "17:00" */
  end: string;
}

export interface DaySchedule {
  isOpen: boolean;
  windows: TimeWindow[];
}

export type WeeklySchedule = Record<DayOfWeek, DaySchedule>;

export interface Calendar {
  id: string;
  subaccount_id: string;
  name: string;
  slug: string;
  duration_minutes: number;
  buffer_before: number;
  buffer_after: number;
  weekly_schedule: WeeklySchedule;
  timezone: string;
  created_at: string;
  updated_at: string;
}

export type AppointmentStatus =
  | 'SCHEDULED'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'NO_SHOW';

export interface Appointment {
  id: string;
  calendar_id: string;
  subaccount_id: string;
  contact_id: string;
  start_time: string; // ISO 8601 string
  end_time: string;   // ISO 8601 string
  status: AppointmentStatus;
  notes: string | null;
  created_at: string;
  updated_at: string;
  contact?: {
    first_name: string | null;
    last_name: string | null;
    email: string | null;
    phone: string | null;
  };
}

export interface AvailableSlot {
  startTime: string; // ISO 8601 string
  endTime: string;   // ISO 8601 string
  available: boolean;
}

export interface BookAppointmentInput {
  calendarId: string;
  subaccountId: string;
  startTime: string;
  notes?: string;
  contact: {
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
  };
}

export interface CalendarAvailabilityQuery {
  calendarId: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  clientTimezone?: string;
}

export interface CalendarIcsData {
  title: string;
  description?: string;
  startTime: Date;
  endTime: Date;
  organizerName: string;
  organizerEmail: string;
  attendeeName: string;
  attendeeEmail: string;
}
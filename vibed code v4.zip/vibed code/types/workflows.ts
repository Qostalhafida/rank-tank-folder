export type WorkflowTriggerType =
  | 'ORDER_CREATED'
  | 'ORDER_STATUS_UPDATED'
  | 'LEAD_CAPTURED'
  | 'CONTACT_TAGGED'
  | 'OPPORTUNITY_STAGE_CHANGED'
  | 'APPOINTMENT_SCHEDULED';

export type WorkflowActionType =
  | 'SEND_EMAIL'
  | 'SEND_SMS'
  | 'ADD_TAG'
  | 'REMOVE_TAG'
  | 'MOVE_PIPELINE_STAGE'
  | 'DISPATCH_WEBHOOK'
  | 'DISPENSE_LICENSE_KEY';

export type WorkflowConditionOperator =
  | 'EQUALS'
  | 'NOT_EQUALS'
  | 'CONTAINS'
  | 'GREATER_THAN'
  | 'LESS_THAN';

export interface WorkflowCondition {
  field: string;
  operator: WorkflowConditionOperator;
  value: string | number | boolean;
}

export interface WorkflowDelayConfig {
  amount: number;
  unit: 'minutes' | 'hours' | 'days';
}

export type WorkflowNodeType = 'TRIGGER' | 'ACTION' | 'CONDITION' | 'DELAY';

export interface WorkflowNodeData {
  label: string;
  triggerType?: WorkflowTriggerType;
  actionType?: WorkflowActionType;
  delayConfig?: WorkflowDelayConfig;
  conditions?: WorkflowCondition[];
  configPayload?: Record<string, unknown>;
}

export interface WorkflowCanvasNode {
  id: string;
  type: WorkflowNodeType;
  position: { x: number; y: number };
  data: WorkflowNodeData;
}

export interface WorkflowCanvasEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string | null;
  targetHandle?: string | null;
  label?: string;
}

export interface Workflow {
  id: string;
  subaccount_id: string;
  name: string;
  is_active: boolean;
  nodes: WorkflowCanvasNode[];
  edges: WorkflowCanvasEdge[];
  created_at: string;
  updated_at: string;
}

export interface WorkflowExecutionContext {
  workflowId: string;
  subaccountId: string;
  contactId?: string;
  orderId?: string;
  opportunityId?: string;
  appointmentId?: string;
  eventPayload: Record<string, unknown>;
}
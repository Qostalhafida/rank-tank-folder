import { Json } from '@/types/database';

export type IdempotencyStatus = 'PROCESSING' | 'RESOLVED' | 'FAILED';

export interface IdempotencyRecord<T = Json> {
  id: string;
  key: string;
  subaccount_id: string | null;
  status: IdempotencyStatus;
  response_payload: T | null;
  locked_at: string;
  expires_at: string;
}

export interface IdempotencyOptions {
  /**
   * Time in seconds before an unresolved or processing key lock expires.
   * Default: 120 seconds (2 minutes).
   */
  lockTtlSeconds?: number;

  /**
   * Time in seconds to persist the cached resolved response payload.
   * Default: 86400 seconds (24 hours).
   */
  retentionSeconds?: number;

  /**
   * Scope of the operation for multi-tenant isolation.
   */
  subaccountId?: string;
}

export type IdempotentExecutionOutcome<T> =
  | { status: 'CACHED'; data: T }
  | { status: 'EXECUTED'; data: T }
  | { status: 'CONCURRENT_IN_PROGRESS' };

export class IdempotencyConflictError extends Error {
  constructor(message = 'Another process is currently handling this request') {
    super(message);
    this.name = 'IdempotencyConflictError';
  }
}
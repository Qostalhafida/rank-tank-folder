export type AgencyRole = 'AGENCY_SUPER_ADMIN' | 'AGENCY_ADMIN' | 'AGENCY_ACCOUNT_MANAGER';

export type SubaccountRole = 
  | 'SUBACCOUNT_OWNER'
  | 'SUBACCOUNT_ADMIN'
  | 'SUBACCOUNT_AGENT'
  | 'SUBACCOUNT_STAFF';

export type UserRole = AgencyRole | SubaccountRole;

export type PermissionAction =
  // Contact & CRM Permissions
  | 'contacts:read'
  | 'contacts:write'
  | 'contacts:delete'
  | 'contacts:export'

  // Pipeline & Opportunities (OCC)
  | 'pipelines:read'
  | 'pipelines:write'
  | 'pipelines:move_stage'
  | 'pipelines:delete'

  // Orders & Cash On Delivery (COD)
  | 'orders:read'
  | 'orders:write'
  | 'orders:update_status'
  | 'orders:cancel'
  | 'orders:print_waybills'

  // Funnels & Storefront
  | 'funnels:read'
  | 'funnels:write'
  | 'funnels:publish'
  | 'storefront:read'
  | 'storefront:write'

  // Products & Digital Assets
  | 'products:read'
  | 'products:write'
  | 'products:delete'
  | 'digital:upload'
  | 'digital:manage_keys'

  // Bookings & Availability
  | 'booking:read'
  | 'booking:write'
  | 'booking:configure_schedule'

  // Automations & Workflows
  | 'workflows:read'
  | 'workflows:write'
  | 'workflows:execute'

  // Infrastructure & Agency Settings
  | 'settings:read'
  | 'settings:write'
  | 'settings:domains'
  | 'settings:pixels'
  | 'settings:webhooks'
  | 'team:manage'
  | 'agency:manage_all';

export interface RoleDefinition {
  name: UserRole;
  description: string;
  inherits?: UserRole[];
  permissions: PermissionAction[];
}

export interface AuthUserSession {
  userId: string;
  email: string;
  agencyId?: string;
  subaccountId?: string;
  role: UserRole;
  permissions: PermissionAction[];
}
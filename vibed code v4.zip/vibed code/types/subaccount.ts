import { SubaccountRole } from '@/types/rbac';

export type SubaccountMode = 'COD' | 'ONLINE' | 'HYBRID';

export type SupportedLocale = 'en' | 'ar' | 'fr' | 'es' | 'pt' | 'it';

export interface TenantThemeConfig {
  primaryColor: string;
  secondaryColor?: string;
  accentColor?: string;
  borderRadius: 'none' | 'sm' | 'md' | 'lg' | 'full';
  fontFamily: 'sans' | 'serif' | 'mono';
  brandLogoUrl?: string;
  brandFaviconUrl?: string;
}

export interface Subaccount {
  id: string;
  agency_id: string;
  name: string;
  slug: string;
  default_locale: SupportedLocale;
  supported_locales: SupportedLocale[];
  mode: SubaccountMode;
  currency: string;
  theme: TenantThemeConfig;
  created_at: string;
  updated_at: string;
}

export interface SubaccountMember {
  id: string;
  subaccount_id: string;
  user_id: string;
  role: SubaccountRole;
  created_at: string;
  user?: {
    email: string;
    first_name?: string | null;
    last_name?: string | null;
    avatar_url?: string | null;
  };
}

export interface CreateSubaccountInput {
  agencyId: string;
  name: string;
  slug: string;
  defaultLocale?: SupportedLocale;
  supportedLocales?: SupportedLocale[];
  mode?: SubaccountMode;
  currency?: string;
  theme?: Partial<TenantThemeConfig>;
}

export interface UpdateSubaccountInput {
  name?: string;
  slug?: string;
  defaultLocale?: SupportedLocale;
  supportedLocales?: SupportedLocale[];
  mode?: SubaccountMode;
  currency?: string;
  theme?: Partial<TenantThemeConfig>;
}

export interface InviteSubaccountMemberInput {
  subaccountId: string;
  email: string;
  role: SubaccountRole;
}
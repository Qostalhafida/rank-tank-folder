export type DigitalAssetType = 'FILE' | 'LICENSE_KEY' | 'COURSE_ACCESS';

export interface DigitalAsset {
  id: string;
  subaccount_id: string;
  product_id: string;
  asset_type: DigitalAssetType;
  file_name: string;
  storage_path: string;
  file_size_bytes: number;
  mime_type: string;
  download_limit: number | null;
  created_at: string;
  updated_at: string;
}

export type LicenseKeyStatus = 'AVAILABLE' | 'ASSIGNED' | 'REVOKED';

export interface LicenseKey {
  id: string;
  subaccount_id: string;
  product_id: string;
  license_key: string;
  status: LicenseKeyStatus;
  order_id: string | null;
  contact_id: string | null;
  assigned_at: string | null;
  created_at: string;
}

export interface SecureDownloadTokenPayload {
  token_id: string;
  subaccount_id: string;
  order_id: string;
  asset_id: string;
  contact_id: string;
  max_downloads: number;
  download_count: number;
  expires_at: number; // Unix timestamp in seconds
}

export interface Lesson {
  id: string;
  course_id: string;
  title: string;
  slug: string;
  video_url: string | null;
  content_markdown: string | null;
  duration_seconds: number;
  position: number;
  is_free_preview: boolean;
  created_at: string;
  updated_at: string;
}

export interface Course {
  id: string;
  subaccount_id: string;
  product_id: string;
  title: string;
  slug: string;
  description: string | null;
  thumbnail_url: string | null;
  lessons?: Lesson[];
  created_at: string;
  updated_at: string;
}

export interface LessonProgress {
  contact_id: string;
  lesson_id: string;
  completed: boolean;
  completed_at: string | null;
  watch_time_seconds: number;
}
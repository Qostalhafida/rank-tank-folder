'use client';

import React, { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { createCodOrder, CreateCodOrderInput } from '@/server/actions/orders';
import { capturePartialLead } from '@/server/actions/leads';
import { MultilingualText } from '@/types/database';

interface ProductPreset {
  id: string;
  title: MultilingualText;
  price: number;
  image?: string;
}

interface CodCheckoutFormProps {
  subaccountId: string;
  subaccountSlug: string;
  locale: string;
  currency: string;
  product: ProductPreset;
  funnelSlug?: string;
  onSuccessRedirectUrl?: string;
}

export function CodCheckoutForm({
  subaccountId,
  subaccountSlug,
  locale,
  currency,
  product,
  funnelSlug,
  onSuccessRedirectUrl,
}: CodCheckoutFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const localizedTitle = product.title[locale] || product.title.en || 'Selected Product';
  const unitPrice = product.price;
  const subtotal = unitPrice * quantity;
  const shippingCost = 0; // Free shipping standard for COD offers
  const totalAmount = subtotal + shippingCost;

  // Abandoned Lead Capture on Field Blur
  const handleBlurCapture = () => {
    if (phone.trim().length >= 8 || fullName.trim().length > 2) {
      const [firstName, ...lastNameParts] = fullName.trim().split(' ');
      capturePartialLead({
        subaccountId,
        firstName: firstName || undefined,
        lastName: lastNameParts.join(' ') || undefined,
        phone: phone || undefined,
        funnelSlug,
        productIntent: {
          productId: product.id,
          productTitle: localizedTitle,
          price: unitPrice,
          quantity,
        },
      }).catch(() => null); // Silent background lead capture
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!fullName.trim() || !phone.trim() || !addressLine1.trim() || !city.trim()) {
      setErrorMsg('Please complete all required shipping fields');
      return;
    }

    setErrorMsg(null);
    const [firstName, ...lastNameParts] = fullName.trim().split(' ');

    startTransition(async () => {
      const orderPayload: CreateCodOrderInput = {
        subaccountId,
        subaccountSlug,
        customer: {
          firstName: firstName || 'Customer',
          lastName: lastNameParts.join(' ') || '',
          phone: phone.trim(),
          addressLine1: addressLine1.trim(),
          city: city.trim(),
        },
        items: [
          {
            productId: product.id,
            quantity,
            unitPrice,
            productTitle: product.title,
          },
        ],
        shippingCost,
        metadata: {
          funnelSlug,
          sourceLocale: locale,
        },
      };

      const res = await createCodOrder(orderPayload);

      if (res.success && res.data) {
        // Dispatch CAPI Purchase Event in Background
        fetch('/api/tracking/capi', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subaccountId,
            eventName: 'Purchase',
            eventId: `order_${res.data.orderId}`,
            eventSourceUrl: window.location.href,
            userData: {
              phone: phone.trim(),
              firstName,
              city: city.trim(),
            },
            customData: {
              currency,
              value: totalAmount,
              contentName: localizedTitle,
              contentIds: [product.id],
              orderId: res.data.orderNumber,
            },
          }),
        }).catch(() => null);

        // Redirect to upsell or thank you page
        const destination =
          onSuccessRedirectUrl ||
          `/${subaccountSlug}/${locale}/checkout/success?order=${encodeURIComponent(
            res.data.orderNumber
          )}`;
        router.push(destination);
      } else {
        setErrorMsg(res.error || 'Failed to place your order. Please check your information.');
      }
    });
  };

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, { style: 'currency', currency }).format(val);

  return (
    <div className="w-full max-w-xl mx-auto bg-card border border-border rounded-xl p-6 shadow-sm">
      {/* Product Summary Header */}
      <div className="flex items-center gap-4 pb-4 border-b border-border">
        {product.image && (
          <img
            src={product.image}
            alt={localizedTitle}
            className="w-16 h-16 rounded-md object-cover border border-border"
          />
        )}
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm text-foreground truncate">{localizedTitle}</h3>
          <p className="text-xs text-muted-foreground mt-0.5">{formatPrice(unitPrice)} per unit</p>
        </div>
      </div>

      {/* Quantity Tier Selector */}
      <div className="my-5">
        <label className="block text-xs font-semibold text-foreground uppercase tracking-wider mb-2">
          Select Quantity
        </label>
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3].map((qty) => (
            <button
              key={qty}
              type="button"
              onClick={() => setQuantity(qty)}
              className={`p-3 border rounded-lg text-center transition-all ${
                quantity === qty
                  ? 'border-primary ring-2 ring-primary/20 bg-primary/5 text-primary font-bold'
                  : 'border-border bg-background hover:bg-muted/40 text-foreground'
              }`}
            >
              <div className="text-sm font-semibold">{qty} Piece{qty > 1 ? 's' : ''}</div>
              <div className="text-xs text-muted-foreground mt-0.5 font-mono">
                {formatPrice(unitPrice * qty)}
              </div>
            </button>
          ))}
        </div>
      </div>

      {errorMsg && (
        <div className="mb-4 p-3 bg-destructive/10 text-destructive text-xs rounded-md border border-destructive/20">
          {errorMsg}
        </div>
      )}

      {/* Fast COD Checkout Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-foreground mb-1">
            Full Name *
          </label>
          <input
            type="text"
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            onBlur={handleBlurCapture}
            placeholder="John Doe"
            className="w-full px-3.5 py-2.5 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-foreground mb-1">
            Phone Number (For Delivery Confirmation) *
          </label>
          <input
            type="tel"
            required
            dir="ltr"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            onBlur={handleBlurCapture}
            placeholder="+1 234 567 8900"
            className="w-full px-3.5 py-2.5 text-sm bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-foreground mb-1">
              City / Province *
            </label>
            <input
              type="text"
              required
              value={city}
              onChange={(e) => setCity(e.target.value)}
              onBlur={handleBlurCapture}
              placeholder="Casablanca, Dubai, Paris..."
              className="w-full px-3.5 py-2.5 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-foreground mb-1">
              Delivery Address *
            </label>
            <input
              type="text"
              required
              value={addressLine1}
              onChange={(e) => setAddressLine1(e.target.value)}
              onBlur={handleBlurCapture}
              placeholder="Street name, Building number..."
              className="w-full px-3.5 py-2.5 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
        </div>

        {/* Pricing Summary */}
        <div className="pt-3 border-t border-border space-y-1.5 text-xs text-muted-foreground">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span className="font-mono text-foreground font-medium">{formatPrice(subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span>Express Shipping</span>
            <span className="font-medium text-emerald-600 uppercase text-[11px]">Free</span>
          </div>
          <div className="flex justify-between text-sm font-bold text-foreground pt-1 border-t border-border/60">
            <span>Total to Pay Upon Delivery</span>
            <span className="font-mono text-primary">{formatPrice(totalAmount)}</span>
          </div>
        </div>

        {/* Submit COD Button */}
        <button
          type="submit"
          disabled={isPending}
          className="w-full mt-2 py-3.5 px-4 bg-primary text-primary-foreground font-bold text-sm rounded-lg hover:bg-primary/90 transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isPending ? (
            <span className="animate-spin">⟳ Processing...</span>
          ) : (
            <>
              <span>📦 Confirm Order — Pay on Delivery</span>
            </>
          )}
        </button>

        <p className="text-[11px] text-center text-muted-foreground mt-2">
          🔒 Secure order. You only pay in cash when the delivery agent delivers your package.
        </p>
      </form>
    </div>
  );
}
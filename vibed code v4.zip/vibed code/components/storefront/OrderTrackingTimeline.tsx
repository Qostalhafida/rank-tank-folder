'use client';

import React, { useState } from 'react';
import { Database, MultilingualText } from '@/types/database';

type OrderStatus = Database['public']['Tables']['orders']['Row']['status'];

export interface TrackingOrderDetails {
  orderNumber: string;
  status: OrderStatus;
  paymentMethod: 'COD' | 'STRIPE' | 'PAYPAL' | 'MANUAL';
  paymentStatus: 'UNPAID' | 'PAID' | 'REFUNDED';
  waybillNumber?: string | null;
  createdAt: string;
  totalAmount: number;
  currency: string;
  items?: {
    id: string;
    productTitle: MultilingualText;
    quantity: number;
    unitPrice: number;
  }[];
}

interface OrderTrackingTimelineProps {
  order: TrackingOrderDetails;
  locale: string;
}

interface TimelineStep {
  key: OrderStatus;
  title: string;
  description: string;
}

const TIMELINE_STEPS: TimelineStep[] = [
  {
    key: 'PENDING',
    title: 'Order Placed',
    description: 'We have received your order and are preparing it for confirmation.',
  },
  {
    key: 'CONFIRMED',
    title: 'Order Confirmed',
    description: 'Your details and items have been verified and packaged.',
  },
  {
    key: 'DISPATCHED',
    title: 'Dispatched & On the Way',
    description: 'Handed over to our courier. Out for delivery to your address.',
  },
  {
    key: 'DELIVERED',
    title: 'Delivered',
    description: 'Package successfully delivered to recipient.',
  },
];

const STATUS_PROGRESSION: Record<string, number> = {
  PENDING: 0,
  CONFIRMED: 1,
  DISPATCHED: 2,
  DELIVERED: 3,
};

export function OrderTrackingTimeline({ order, locale }: OrderTrackingTimelineProps) {
  const [copiedWaybill, setCopiedWaybill] = useState(false);

  const isCancelled = order.status === 'CANCELLED';
  const isReturned = order.status === 'RETURNED';
  const currentStepIndex = STATUS_PROGRESSION[order.status] ?? 0;

  const handleCopyWaybill = () => {
    if (!order.waybillNumber) return;
    navigator.clipboard.writeText(order.waybillNumber);
    setCopiedWaybill(true);
    setTimeout(() => setCopiedWaybill(false), 2000);
  };

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: order.currency || 'USD',
    }).format(val);

  return (
    <div className="w-full max-w-2xl mx-auto bg-card border border-border rounded-xl p-6 shadow-sm space-y-6">
      {/* Order Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-5 border-b border-border">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-foreground">
              Order #{order.orderNumber}
            </h2>
            <span
              className={`text-[11px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                order.paymentMethod === 'COD'
                  ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                  : 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
              }`}
            >
              {order.paymentMethod === 'COD' ? 'Cash on Delivery' : 'Prepaid'}
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Placed on {new Date(order.createdAt).toLocaleDateString()}
          </p>
        </div>

        {order.waybillNumber && (
          <div className="flex items-center gap-2 bg-muted/40 border border-border px-3 py-1.5 rounded-md self-start sm:self-auto font-mono text-xs">
            <span className="text-muted-foreground">Waybill:</span>
            <span className="font-semibold text-foreground">{order.waybillNumber}</span>
            <button
              onClick={handleCopyWaybill}
              className="text-primary hover:underline text-[11px] ml-1"
            >
              {copiedWaybill ? '✓ Copied' : 'Copy'}
            </button>
          </div>
        )}
      </div>

      {/* Exception Status Banner (Cancelled / Returned) */}
      {isCancelled && (
        <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-xs text-destructive flex items-center gap-3">
          <span className="text-lg">✕</span>
          <div>
            <p className="font-bold">Order Cancelled</p>
            <p className="opacity-90">This order was cancelled and will not be delivered.</p>
          </div>
        </div>
      )}

      {isReturned && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-700 flex items-center gap-3">
          <span className="text-lg">↩</span>
          <div>
            <p className="font-bold">Returned Parcel</p>
            <p className="opacity-90">The courier returned this shipment to the fulfillment warehouse.</p>
          </div>
        </div>
      )}

      {/* Standard Fulfillment Timeline */}
      {!isCancelled && !isReturned && (
        <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-[11px] sm:before:left-[15px] before:top-2 before:bottom-2 before:w-0.5 before:bg-border">
          {TIMELINE_STEPS.map((step, idx) => {
            const isCompleted = idx <= currentStepIndex;
            const isCurrent = idx === currentStepIndex;

            return (
              <div key={step.key} className="relative group">
                {/* Milestone Node */}
                <div
                  className={`absolute -left-[23px] sm:-left-[31px] top-0.5 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                    isCompleted
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'bg-muted border border-border text-muted-foreground'
                  } ${isCurrent ? 'ring-4 ring-primary/20' : ''}`}
                >
                  {isCompleted ? '✓' : idx + 1}
                </div>

                {/* Milestone Info */}
                <div className="space-y-0.5">
                  <h4
                    className={`text-sm font-semibold tracking-tight ${
                      isCompleted ? 'text-foreground' : 'text-muted-foreground'
                    }`}
                  >
                    {step.title}
                  </h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Order Package Contents Summary */}
      {order.items && order.items.length > 0 && (
        <div className="pt-4 border-t border-border space-y-3">
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Items in Shipment
          </h4>
          <div className="divide-y divide-border/60">
            {order.items.map((item) => {
              const itemTitle =
                typeof item.productTitle === 'string'
                  ? item.productTitle
                  : item.productTitle[locale] || item.productTitle.en || 'Product';

              return (
                <div key={item.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-foreground font-mono">
                      x{item.quantity}
                    </span>
                    <span className="text-foreground">{itemTitle}</span>
                  </div>
                  <span className="font-mono text-muted-foreground">
                    {formatPrice(item.unitPrice * item.quantity)}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="pt-2 flex justify-between items-center text-sm font-bold border-t border-border">
            <span>Total Payable</span>
            <span className="font-mono text-primary text-base">
              {formatPrice(order.totalAmount)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
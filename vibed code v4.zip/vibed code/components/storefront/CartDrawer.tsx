'use client';

import React, { useEffect } from 'react';
import Link from 'next/link';
import { useCartStore } from '@/stores/cart-store';

interface CartDrawerProps {
  subaccountSlug: string;
  locale: string;
  currency: string;
}

export function CartDrawer({
  subaccountSlug,
  locale,
  currency,
}: CartDrawerProps) {
  const {
    isOpen,
    closeCart,
    items,
    updateQuantity,
    removeItem,
    getSubtotal,
    getTotalCount,
  } = useCartStore();

  // Close drawer on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeCart();
    };

    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, closeCart]);

  if (!isOpen) return null;

  const totalCount = getTotalCount();
  const subtotal = getSubtotal();

  const formatPrice = (amount: number) =>
    new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
    }).format(amount);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={closeCart}
        className="absolute inset-0 bg-background/80 backdrop-blur-sm transition-opacity animate-in fade-in"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-card border-l border-border shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-200">
          {/* Drawer Header */}
          <div className="p-4 border-b border-border flex items-center justify-between bg-muted/20">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-foreground">Shopping Cart</h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-mono font-medium">
                {totalCount}
              </span>
            </div>
            <button
              onClick={closeCart}
              className="text-muted-foreground hover:text-foreground p-1 text-sm font-semibold rounded-md transition-colors"
            >
              ✕
            </button>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {items.length > 0 ? (
              items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 p-3 bg-background border border-border rounded-lg shadow-sm"
                >
                  {item.image && (
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-16 h-16 rounded-md object-cover border border-border shrink-0"
                    />
                  )}

                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div className="flex justify-between items-start gap-2">
                      <h4 className="text-xs font-semibold text-foreground truncate">
                        {item.title}
                      </h4>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                      >
                        ×
                      </button>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      {/* Quantity Stepper */}
                      <div className="flex items-center border border-border rounded-md bg-muted/30">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="px-2 py-0.5 text-xs text-muted-foreground hover:text-foreground"
                        >
                          −
                        </button>
                        <span className="px-2 text-xs font-mono font-medium text-foreground">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="px-2 py-0.5 text-xs text-muted-foreground hover:text-foreground"
                        >
                          +
                        </button>
                      </div>

                      <span className="text-xs font-bold font-mono text-foreground">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
                <span className="text-3xl">🛒</span>
                <p className="text-sm font-medium text-foreground">Your cart is empty</p>
                <p className="text-xs text-muted-foreground max-w-xs">
                  Discover our exclusive catalog and add products to start shopping.
                </p>
                <button
                  onClick={closeCart}
                  className="mt-2 px-4 py-2 bg-secondary text-secondary-foreground text-xs font-medium rounded-md hover:bg-secondary/90 transition-colors"
                >
                  Continue Shopping
                </button>
              </div>
            )}
          </div>

          {/* Drawer Footer */}
          {items.length > 0 && (
            <div className="p-4 border-t border-border bg-muted/20 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-mono font-bold text-sm text-foreground">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground">
                Shipping and taxes calculated at checkout.
              </p>

              <div className="space-y-2">
                <Link
                  href={`/${subaccountSlug}/${locale}/cart`}
                  onClick={closeCart}
                  className="w-full block py-2.5 px-4 bg-primary text-primary-foreground font-semibold text-xs text-center rounded-md hover:bg-primary/90 transition-all shadow-sm"
                >
                  Review Cart & Checkout
                </Link>
                <button
                  onClick={closeCart}
                  className="w-full py-2 px-4 bg-background text-foreground font-medium text-xs rounded-md border border-border hover:bg-muted/50 transition-colors"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
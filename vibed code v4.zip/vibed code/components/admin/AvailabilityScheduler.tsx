'use client';

import React, { useState, useTransition } from 'react';
import { DayOfWeek, TimeWindow, WeeklySchedule } from '@/types/booking';
import { updateCalendarSchedule } from '@/server/actions/booking';

const DAYS_ORDER: { key: DayOfWeek; label: string }[] = [
  { key: 'monday', label: 'Monday' },
  { key: 'tuesday', label: 'Tuesday' },
  { key: 'wednesday', label: 'Wednesday' },
  { key: 'thursday', label: 'Thursday' },
  { key: 'friday', label: 'Friday' },
  { key: 'saturday', label: 'Saturday' },
  { key: 'sunday', label: 'Sunday' },
];

interface AvailabilitySchedulerProps {
  subaccountId: string;
  calendarId: string;
  initialSchedule: WeeklySchedule;
  timezone: string;
}

export function AvailabilityScheduler({
  subaccountId,
  calendarId,
  initialSchedule,
  timezone,
}: AvailabilitySchedulerProps) {
  const [schedule, setSchedule] = useState<WeeklySchedule>(initialSchedule);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleToggleDay = (day: DayOfWeek) => {
    setSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        isOpen: !prev[day].isOpen,
        windows:
          !prev[day].isOpen && prev[day].windows.length === 0
            ? [{ start: '09:00', end: '17:00' }]
            : prev[day].windows,
      },
    }));
  };

  const handleTimeChange = (
    day: DayOfWeek,
    index: number,
    field: 'start' | 'end',
    value: string
  ) => {
    setSchedule((prev) => {
      const updatedWindows = [...prev[day].windows];
      updatedWindows[index] = {
        ...updatedWindows[index],
        [field]: value,
      };
      return {
        ...prev,
        [day]: {
          ...prev[day],
          windows: updatedWindows,
        },
      };
    });
  };

  const handleAddWindow = (day: DayOfWeek) => {
    setSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        windows: [...prev[day].windows, { start: '09:00', end: '17:00' }],
      },
    }));
  };

  const handleRemoveWindow = (day: DayOfWeek, index: number) => {
    setSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        windows: prev[day].windows.filter((_, i) => i !== index),
      },
    }));
  };

  const handleSave = () => {
    setStatusMessage(null);
    startTransition(async () => {
      const res = await updateCalendarSchedule(subaccountId, calendarId, schedule);
      if (res.success) {
        setStatusMessage({ type: 'success', text: 'Working hours updated successfully' });
        setTimeout(() => setStatusMessage(null), 4000);
      } else {
        setStatusMessage({ type: 'error', text: res.error || 'Failed to update schedule' });
      }
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-sm max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pb-4 border-b border-border">
        <div>
          <h3 className="text-base font-semibold text-foreground">Weekly Availability</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Configure default working hours and available time windows. Timezone: <span className="font-mono text-foreground">{timezone}</span>
          </p>
        </div>

        <button
          onClick={handleSave}
          disabled={isPending}
          className="px-4 py-2 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50 self-start sm:self-auto flex items-center gap-2"
        >
          {isPending && <span className="animate-spin">⟳</span>}
          Save Schedule
        </button>
      </div>

      {statusMessage && (
        <div
          className={`p-3 rounded-md text-xs border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
              : 'bg-destructive/10 text-destructive border-destructive/20'
          }`}
        >
          {statusMessage.text}
        </div>
      )}

      {/* 7-Day Configuration Grid */}
      <div className="space-y-4">
        {DAYS_ORDER.map(({ key, label }) => {
          const dayConfig = schedule[key] ?? { isOpen: false, windows: [] };

          return (
            <div
              key={key}
              className={`p-4 rounded-lg border transition-colors ${
                dayConfig.isOpen ? 'bg-background border-border' : 'bg-muted/20 border-border/50 opacity-70'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                {/* Day Toggle Switch */}
                <div className="flex items-center gap-3 w-40 shrink-0">
                  <input
                    type="checkbox"
                    id={`toggle-${key}`}
                    checked={dayConfig.isOpen}
                    onChange={() => handleToggleDay(key)}
                    className="w-4 h-4 rounded text-primary focus:ring-primary/40 border-border"
                  />
                  <label
                    htmlFor={`toggle-${key}`}
                    className="text-sm font-medium text-foreground cursor-pointer"
                  >
                    {label}
                  </label>
                </div>

                {/* Windows Manager */}
                <div className="flex-1 space-y-2.5">
                  {dayConfig.isOpen ? (
                    dayConfig.windows.map((window, idx) => (
                      <div key={idx} className="flex items-center gap-2 flex-wrap">
                        <input
                          type="time"
                          value={window.start}
                          onChange={(e) => handleTimeChange(key, idx, 'start', e.target.value)}
                          className="px-2.5 py-1.5 text-xs bg-card border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                        />
                        <span className="text-xs text-muted-foreground">to</span>
                        <input
                          type="time"
                          value={window.end}
                          onChange={(e) => handleTimeChange(key, idx, 'end', e.target.value)}
                          className="px-2.5 py-1.5 text-xs bg-card border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
                        />

                        {dayConfig.windows.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveWindow(key, idx)}
                            className="text-xs text-destructive hover:underline px-1.5"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    ))
                  ) : (
                    <span className="text-xs text-muted-foreground italic">Unavailable / Closed</span>
                  )}
                </div>

                {/* Add Window Button */}
                {dayConfig.isOpen && (
                  <button
                    type="button"
                    onClick={() => handleAddWindow(key)}
                    className="text-xs text-primary font-medium hover:underline self-start shrink-0"
                  >
                    + Add Hours
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
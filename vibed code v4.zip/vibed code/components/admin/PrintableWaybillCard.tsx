'use client';

import React from 'react';

export interface WaybillOrderData {
  orderNumber: string;
  waybillNumber: string;
  createdAt: string;
  totalAmount: number;
  currency: string;
  paymentMethod: 'COD' | 'STRIPE' | 'PAYPAL' | 'MANUAL';
  customer: {
    name: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    province?: string;
    country?: string;
  };
  items: {
    title: string;
    quantity: number;
    unitPrice: number;
  }[];
  storeName: string;
  storePhone?: string;
}

interface PrintableWaybillCardProps {
  order: WaybillOrderData;
}

export function PrintableWaybillCard({ order }: PrintableWaybillCardProps) {
  const isCod = order.paymentMethod === 'COD';

  const formattedTotal = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: order.currency || 'USD',
  }).format(order.totalAmount);

  return (
    <div className="w-[105mm] h-[148mm] p-4 bg-white text-black font-sans border-2 border-dashed border-neutral-300 print:border-none print:m-0 print:p-3 print:w-[105mm] print:h-[148mm] print:break-after-page flex flex-col justify-between box-border text-[11px] leading-tight select-none">
      {/* 1. Header: Store branding & Courier Badge */}
      <div className="border-b-2 border-black pb-2 flex items-center justify-between">
        <div>
          <h2 className="font-extrabold text-sm uppercase tracking-tight">{order.storeName}</h2>
          {order.storePhone && (
            <p className="text-[10px] text-neutral-600 font-mono">Tel: {order.storePhone}</p>
          )}
        </div>
        <div className="text-right">
          <span
            className={`inline-block px-2 py-1 text-xs font-black uppercase tracking-wider border-2 border-black ${
              isCod ? 'bg-black text-white' : 'bg-transparent text-black'
            }`}
          >
            {isCod ? 'C.O.D. PARCEL' : 'PREPAID'}
          </span>
        </div>
      </div>

      {/* 2. Tracking & Barcode Simulation */}
      <div className="my-2 p-2 border border-black rounded text-center">
        <div className="font-mono text-xs font-black tracking-widest uppercase">
          WAYBILL: {order.waybillNumber}
        </div>
        {/* Vector SVG Barcode */}
        <div className="flex justify-center my-1.5 h-10 w-full overflow-hidden">
          <svg className="w-56 h-10" viewBox="0 0 200 40">
            <rect x="0" y="0" width="4" height="40" fill="black" />
            <rect x="6" y="0" width="2" height="40" fill="black" />
            <rect x="11" y="0" width="6" height="40" fill="black" />
            <rect x="20" y="0" width="3" height="40" fill="black" />
            <rect x="26" y="0" width="7" height="40" fill="black" />
            <rect x="36" y="0" width="2" height="40" fill="black" />
            <rect x="42" y="0" width="5" height="40" fill="black" />
            <rect x="50" y="0" width="8" height="40" fill="black" />
            <rect x="61" y="0" width="3" height="40" fill="black" />
            <rect x="67" y="0" width="6" height="40" fill="black" />
            <rect x="76" y="0" width="2" height="40" fill="black" />
            <rect x="81" y="0" width="9" height="40" fill="black" />
            <rect x="93" y="0" width="3" height="40" fill="black" />
            <rect x="99" y="0" width="5" height="40" fill="black" />
            <rect x="107" y="0" width="7" height="40" fill="black" />
            <rect x="117" y="0" width="2" height="40" fill="black" />
            <rect x="122" y="0" width="6" height="40" fill="black" />
            <rect x="131" y="0" width="4" height="40" fill="black" />
            <rect x="138" y="0" width="7" height="40" fill="black" />
            <rect x="148" y="0" width="3" height="40" fill="black" />
            <rect x="154" y="0" width="6" height="40" fill="black" />
            <rect x="163" y="0" width="4" height="40" fill="black" />
            <rect x="170" y="0" width="8" height="40" fill="black" />
            <rect x="181" y="0" width="3" height="40" fill="black" />
            <rect x="187" y="0" width="5" height="40" fill="black" />
            <rect x="195" y="0" width="4" height="40" fill="black" />
          </svg>
        </div>
        <div className="font-mono text-[9px] text-neutral-600">
          ORDER #{order.orderNumber} • {new Date(order.createdAt).toLocaleDateString()}
        </div>
      </div>

      {/* 3. Recipient Destination Details */}
      <div className="border border-black p-2 rounded my-1">
        <div className="text-[9px] uppercase font-bold text-neutral-500 tracking-wider">
          SHIP TO / RECIPIENT
        </div>
        <div className="text-xs font-black uppercase text-black mt-0.5">
          {order.customer.name}
        </div>
        <div className="font-mono font-bold text-sm text-black mt-0.5">
          {order.customer.phone}
        </div>
        <div className="mt-1 text-[11px] font-medium leading-tight">
          {order.customer.addressLine1}
          {order.customer.addressLine2 ? `, ${order.customer.addressLine2}` : ''}
        </div>
        <div className="font-bold text-xs uppercase mt-0.5">
          {order.customer.city}
          {order.customer.province ? `, ${order.customer.province}` : ''}
          {order.customer.country ? ` (${order.customer.country})` : ''}
        </div>
      </div>

      {/* 4. Package Contents Breakdown */}
      <div className="my-1 border border-neutral-300 rounded p-1.5 flex-1 max-h-24 overflow-hidden">
        <div className="text-[9px] font-bold text-neutral-500 uppercase border-b pb-0.5 mb-1 flex justify-between">
          <span>Item</span>
          <span>Qty</span>
        </div>
        <div className="space-y-1">
          {order.items.map((item, idx) => (
            <div key={idx} className="flex justify-between text-[10px]">
              <span className="truncate max-w-[210px]">{item.title}</span>
              <span className="font-mono font-bold">x{item.quantity}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Cash Collection Box (Crucial for COD Couriers) */}
      <div className="border-2 border-black p-2 mt-1 rounded bg-neutral-50 flex items-center justify-between">
        <div>
          <span className="block text-[9px] font-extrabold uppercase tracking-wide">
            {isCod ? 'AMOUNT TO COLLECT (COD)' : 'TOTAL PAID'}
          </span>
          <span className="text-[9px] text-neutral-500">
            {isCod ? 'Collect cash before delivery handoff' : 'Prepaid online — Do not collect'}
          </span>
        </div>
        <div className="text-right">
          <span className="font-mono font-black text-lg text-black tracking-tight">
            {formattedTotal}
          </span>
        </div>
      </div>
    </div>
  );
}
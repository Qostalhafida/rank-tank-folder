'use client';

import React, { useState, useTransition } from 'react';
import {
  DomainDetails,
  provisionCustomDomain,
  verifyCustomDomain,
  deleteCustomDomain,
} from '@/server/actions/domains';

interface CloudflareDnsCardProps {
  subaccountId: string;
  initialDomain: DomainDetails | null;
}

export function CloudflareDnsCard({
  subaccountId,
  initialDomain,
}: CloudflareDnsCardProps) {
  const [domain, setDomain] = useState<DomainDetails | null>(initialDomain);
  const [hostnameInput, setHostnameInput] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleProvision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hostnameInput.trim()) return;

    setErrorMsg(null);
    startTransition(async () => {
      const res = await provisionCustomDomain(subaccountId, hostnameInput);
      if (res.success && res.data) {
        setDomain(res.data);
        setHostnameInput('');
      } else {
        setErrorMsg(res.error || 'Failed to register domain');
      }
    });
  };

  const handleVerify = () => {
    if (!domain) return;
    setErrorMsg(null);
    startTransition(async () => {
      const res = await verifyCustomDomain(subaccountId, domain.id);
      if (res.success && res.data) {
        setDomain(res.data);
      } else {
        setErrorMsg(res.error || 'Verification check failed');
      }
    });
  };

  const handleDelete = () => {
    if (!domain || !confirm('Are you sure you want to disconnect this domain?')) return;
    setErrorMsg(null);
    startTransition(async () => {
      const res = await deleteCustomDomain(subaccountId, domain.id);
      if (res.success) {
        setDomain(null);
      } else {
        setErrorMsg(res.error || 'Failed to remove domain');
      }
    });
  };

  const isActive = domain?.status === 'ACTIVE' && domain?.ssl_status === 'active';

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-sm max-w-3xl">
      <div className="flex items-center justify-between pb-4 border-b border-border">
        <div>
          <h3 className="text-base font-semibold text-foreground">Custom Domain & SSL</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Connect your branded domain via Cloudflare Enterprise Edge.
          </p>
        </div>

        {domain && (
          <span
            className={`text-xs px-2.5 py-1 rounded-full font-medium ${
              isActive
                ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                : 'bg-amber-500/10 text-amber-600 border border-amber-500/20 animate-pulse'
            }`}
          >
            {isActive ? 'Active & SSL Secured' : 'Pending DNS Propagation'}
          </span>
        )}
      </div>

      {errorMsg && (
        <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 text-destructive text-xs rounded-md">
          {errorMsg}
        </div>
      )}

      {!domain ? (
        <form onSubmit={handleProvision} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-foreground mb-1.5">
              Domain or Subdomain
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="store.yourbrand.com"
                value={hostnameInput}
                onChange={(e) => setHostnameInput(e.target.value)}
                disabled={isPending}
                className="flex-1 px-3.5 py-2 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={isPending || !hostnameInput.trim()}
                className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                {isPending ? 'Provisioning...' : 'Add Domain'}
              </button>
            </div>
          </div>
        </form>
      ) : (
        <div className="mt-5 space-y-6">
          <div className="flex items-center justify-between bg-muted/30 p-3 rounded-md border border-border">
            <span className="font-mono text-sm font-medium text-foreground">
              {domain.hostname}
            </span>
            <button
              onClick={handleDelete}
              disabled={isPending}
              className="text-xs text-destructive hover:underline"
            >
              Disconnect
            </button>
          </div>

          {!isActive && (
            <div className="space-y-4">
              <p className="text-xs text-muted-foreground">
                Configure the following DNS records at your DNS registrar (Namecheap, GoDaddy, Cloudflare, etc.):
              </p>

              {/* CNAME Routing Record */}
              <div className="p-3 bg-background border border-border rounded-md text-xs space-y-2">
                <span className="font-semibold text-foreground uppercase tracking-wider text-[10px]">
                  1. Traffic Routing (CNAME)
                </span>
                <div className="grid grid-cols-12 gap-2 items-center font-mono">
                  <div className="col-span-3 text-muted-foreground">CNAME</div>
                  <div className="col-span-4 truncate text-foreground font-semibold">
                    {domain.hostname}
                  </div>
                  <div className="col-span-4 truncate text-foreground">
                    {domain.cloudflareData?.cnameTarget || 'cname.yourplatform.com'}
                  </div>
                  <div className="col-span-1 text-right">
                    <button
                      onClick={() =>
                        handleCopy(
                          domain.cloudflareData?.cnameTarget || 'cname.yourplatform.com',
                          'cname'
                        )
                      }
                      className="text-primary hover:underline text-[11px]"
                    >
                      {copiedKey === 'cname' ? '✓' : 'Copy'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Ownership Verification TXT */}
              {domain.cloudflareData?.ownershipVerification && (
                <div className="p-3 bg-background border border-border rounded-md text-xs space-y-2">
                  <span className="font-semibold text-foreground uppercase tracking-wider text-[10px]">
                    2. Domain Ownership Verification
                  </span>
                  <div className="grid grid-cols-12 gap-2 items-center font-mono">
                    <div className="col-span-2 text-muted-foreground">
                      {domain.cloudflareData.ownershipVerification.type}
                    </div>
                    <div className="col-span-4 truncate text-foreground font-semibold">
                      {domain.cloudflareData.ownershipVerification.name}
                    </div>
                    <div className="col-span-5 truncate text-foreground">
                      {domain.cloudflareData.ownershipVerification.value}
                    </div>
                    <div className="col-span-1 text-right">
                      <button
                        onClick={() =>
                          handleCopy(
                            domain.cloudflareData!.ownershipVerification!.value,
                            'ownership'
                          )
                        }
                        className="text-primary hover:underline text-[11px]"
                      >
                        {copiedKey === 'ownership' ? '✓' : 'Copy'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* SSL Certificate Issuance TXT / CNAME */}
              {domain.cloudflareData?.sslVerification && (
                <div className="p-3 bg-background border border-border rounded-md text-xs space-y-2">
                  <span className="font-semibold text-foreground uppercase tracking-wider text-[10px]">
                    3. SSL Certificate Issuance
                  </span>
                  <div className="grid grid-cols-12 gap-2 items-center font-mono">
                    <div className="col-span-2 text-muted-foreground">
                      {domain.cloudflareData.sslVerification.type}
                    </div>
                    <div className="col-span-4 truncate text-foreground font-semibold">
                      {domain.cloudflareData.sslVerification.name}
                    </div>
                    <div className="col-span-5 truncate text-foreground">
                      {domain.cloudflareData.sslVerification.value}
                    </div>
                    <div className="col-span-1 text-right">
                      <button
                        onClick={() =>
                          handleCopy(
                            domain.cloudflareData!.sslVerification!.value,
                            'ssl'
                          )
                        }
                        className="text-primary hover:underline text-[11px]"
                      >
                        {copiedKey === 'ssl' ? '✓' : 'Copy'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleVerify}
                  disabled={isPending}
                  className="px-4 py-2 bg-secondary text-secondary-foreground text-xs font-medium rounded-md hover:bg-secondary/90 transition-colors disabled:opacity-50 flex items-center gap-2"
                >
                  {isPending && <span className="animate-spin">⟳</span>}
                  Check DNS & SSL Verification
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
'use client';

import React, { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { applyPostPurchaseUpsell } from '@/server/actions/orders';
import { MultilingualText } from '@/types/database';

interface UpsellProduct {
  id: string;
  title: MultilingualText;
  description?: MultilingualText;
  price: number;
  compareAtPrice?: number | null;
  image?: string;
}

interface PostPurchaseUpsellCardProps {
  orderId: string;
  orderNumber: string;
  subaccountId: string;
  subaccountSlug: string;
  locale: string;
  currency: string;
  product: UpsellProduct;
  nextStepUrl: string;
  downsellUrl?: string;
}

export function PostPurchaseUpsellCard({
  orderId,
  orderNumber,
  subaccountId,
  subaccountSlug,
  locale,
  currency,
  product,
  nextStepUrl,
  downsellUrl,
}: PostPurchaseUpsellCardProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const localizedTitle =
    product.title[locale] || product.title.en || 'Special Exclusive Offer';
  const localizedDescription =
    product.description?.[locale] ||
    product.description?.en ||
    'Take advantage of this exclusive post-purchase offer added directly to your package.';

  const discountPercentage =
    product.compareAtPrice && product.compareAtPrice > product.price
      ? Math.round(
          ((product.compareAtPrice - product.price) / product.compareAtPrice) * 100
        )
      : null;

  const formatPrice = (val: number) =>
    new Intl.NumberFormat(locale, { style: 'currency', currency }).format(val);

  const handleAcceptUpsell = () => {
    setErrorMsg(null);
    startTransition(async () => {
      const res = await applyPostPurchaseUpsell({
        orderId,
        subaccountId,
        productId: product.id,
        quantity: 1,
        unitPrice: product.price,
        productTitle: product.title,
      });

      if (res.success) {
        // Dispatch CAPI tracking event in background
        fetch('/api/tracking/capi', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subaccountId,
            eventName: 'Purchase',
            eventId: `upsell_${orderId}_${product.id}`,
            eventSourceUrl: window.location.href,
            customData: {
              currency,
              value: product.price,
              contentName: localizedTitle,
              contentIds: [product.id],
              orderId: orderNumber,
            },
          }),
        }).catch(() => null);

        router.push(nextStepUrl);
      } else {
        setErrorMsg(res.error || 'Failed to attach upsell to your order.');
      }
    });
  };

  const handleDecline = () => {
    const destination = downsellUrl || nextStepUrl;
    router.push(destination);
  };

  return (
    <div className="w-full max-w-xl mx-auto bg-card border-2 border-primary/30 rounded-2xl p-6 sm:p-8 shadow-xl text-center space-y-6">
      {/* Urgency Badge */}
      <div className="inline-block px-3 py-1 bg-amber-500/10 text-amber-600 border border-amber-500/30 rounded-full text-xs font-bold uppercase tracking-wider animate-pulse">
        ⚡ Special One-Time Offer — Do Not Refresh
      </div>

      {/* Main Pitch */}
      <div className="space-y-2">
        <h2 className="text-xl sm:text-2xl font-extrabold text-foreground tracking-tight">
          Wait! Complete Your Package with This Special Deal
        </h2>
        <p className="text-xs sm:text-sm text-muted-foreground max-w-md mx-auto">
          Your initial order is confirmed! As a thank you, get this complementary item at a steep discount with free combined shipping.
        </p>
      </div>

      {/* Product Showcase */}
      <div className="p-4 bg-muted/30 border border-border rounded-xl flex flex-col sm:flex-row items-center gap-5 text-left">
        {product.image && (
          <img
            src={product.image}
            alt={localizedTitle}
            className="w-28 h-28 sm:w-32 sm:h-32 object-cover rounded-lg border border-border shrink-0 shadow-sm"
          />
        )}
        <div className="space-y-1.5 flex-1 min-w-0">
          {discountPercentage && (
            <span className="inline-block px-2 py-0.5 bg-emerald-500 text-white text-[10px] font-black uppercase rounded">
              Save {discountPercentage}% OFF
            </span>
          )}
          <h3 className="font-bold text-sm sm:text-base text-foreground line-clamp-2">
            {localizedTitle}
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-2">
            {localizedDescription}
          </p>

          <div className="flex items-baseline gap-2 pt-1 font-mono">
            <span className="text-lg font-extrabold text-primary">
              {formatPrice(product.price)}
            </span>
            {product.compareAtPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {formatPrice(product.compareAtPrice)}
              </span>
            )}
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-destructive/10 text-destructive text-xs rounded-md border border-destructive/20 text-left">
          {errorMsg}
        </div>
      )}

      {/* 1-Click Action Buttons */}
      <div className="space-y-3 pt-2">
        <button
          type="button"
          onClick={handleAcceptUpsell}
          disabled={isPending}
          className="w-full py-4 px-6 bg-primary text-primary-foreground font-black text-sm sm:text-base rounded-xl hover:bg-primary/90 transition-all shadow-lg hover:shadow-primary/25 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isPending ? (
            <span className="animate-spin">⟳ Adding to your order...</span>
          ) : (
            <>
              <span>✓ Yes! Add This to My Order for Just {formatPrice(product.price)}</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={handleDecline}
          disabled={isPending}
          className="text-xs text-muted-foreground hover:text-foreground underline transition-colors"
        >
          No thank you, I want to pass on this offer and proceed to confirmation
        </button>
      </div>

      <div className="pt-2 border-t border-border flex items-center justify-center gap-4 text-[11px] text-muted-foreground">
        <span>🚚 Shipped together with zero extra shipping fees</span>
        <span>•</span>
        <span>📦 Added to Order #{orderNumber}</span>
      </div>
    </div>
  );
}
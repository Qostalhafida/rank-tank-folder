'use client';

import React, { useEffect, useState, useTransition } from 'react';
import { createOpportunity } from '@/server/actions/pipelines';
import { getContacts } from '@/server/actions/contacts';
import { Contact, Opportunity, PipelineStage } from '@/types/crm';

interface CreateOpportunityModalProps {
  subaccountId: string;
  pipelineId: string;
  stages: PipelineStage[];
  isOpen: boolean;
  onClose: () => void;
  onCreated?: (opportunity: Opportunity) => void;
}

export function CreateOpportunityModal({
  subaccountId,
  pipelineId,
  stages,
  isOpen,
  onClose,
  onCreated,
}: CreateOpportunityModalProps) {
  const [title, setTitle] = useState('');
  const [value, setValue] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [stageId, setStageId] = useState(stages[0]?.id || '');
  const [contactId, setContactId] = useState('');
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  // Load available contacts for association
  useEffect(() => {
    if (isOpen && subaccountId) {
      getContacts(subaccountId, { pageSize: 50 }).then((res) => {
        if (res.success && res.data) {
          setContacts(res.data.contacts);
          if (res.data.contacts[0] && !contactId) {
            setContactId(res.data.contacts[0].id);
          }
        }
      });
    }
  }, [isOpen, subaccountId, contactId]);

  useEffect(() => {
    if (stages[0] && !stageId) {
      setStageId(stages[0].id);
    }
  }, [stages, stageId]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !contactId || !stageId) {
      setErrorMsg('Please complete all required deal fields.');
      return;
    }

    setErrorMsg(null);
    startTransition(async () => {
      const res = await createOpportunity(subaccountId, {
        pipeline_id: pipelineId,
        stage_id: stageId,
        contact_id: contactId,
        title: title.trim(),
        value: parseFloat(value) || 0,
        currency,
        status: 'OPEN',
        position: 0,
      });

      if (res.success && res.data) {
        onCreated?.(res.data);
        setTitle('');
        setValue('');
        onClose();
      } else {
        setErrorMsg(res.error || 'Failed to create opportunity deal.');
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-md bg-card border border-border rounded-xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-border bg-muted/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-base">💼</span>
            <h3 className="text-sm font-bold text-foreground">Create Deal Opportunity</h3>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground text-xs p-1 rounded"
          >
            ✕
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 mx-4 mt-3 bg-destructive/10 text-destructive text-xs rounded-md border border-destructive/20">
            {errorMsg}
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div>
            <label className="block text-xs font-medium text-foreground mb-1">
              Deal Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Q4 Wholesale Order - 50 Units"
              className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Estimated Value ($) *
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="1500.00"
                className="w-full px-3 py-2 bg-background border border-input rounded-md font-mono focus:outline-none focus:ring-2 focus:ring-primary/40 text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-foreground mb-1">
                Currency
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full px-3 py-2 bg-background border border-input rounded-md font-mono focus:outline-none text-xs"
              >
                <option value="USD">USD ($)</option>
                <option value="MAD">MAD (DH)</option>
                <option value="EUR">EUR (€)</option>
                <option value="SAR">SAR (ر.س)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-foreground mb-1">
              Initial Pipeline Stage *
            </label>
            <select
              value={stageId}
              onChange={(e) => setStageId(e.target.value)}
              className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none text-xs font-medium"
            >
              {stages.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-foreground mb-1">
              Associated CRM Contact *
            </label>
            <select
              value={contactId}
              onChange={(e) => setContactId(e.target.value)}
              className="w-full px-3 py-2 bg-background border border-input rounded-md focus:outline-none text-xs"
            >
              {contacts.length > 0 ? (
                contacts.map((c) => {
                  const fullName = `${c.first_name ?? ''} ${c.last_name ?? ''}`.trim() || c.phone || 'Contact';
                  return (
                    <option key={c.id} value={c.id}>
                      {fullName} {c.email ? `(${c.email})` : ''}
                    </option>
                  );
                })
              ) : (
                <option value="">No contacts found in CRM</option>
              )}
            </select>
          </div>

          {/* Modal Actions */}
          <div className="pt-3 border-t border-border flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 bg-muted text-muted-foreground hover:text-foreground text-xs rounded-md transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isPending}
              className="px-4 py-1.5 bg-primary text-primary-foreground font-semibold text-xs rounded-md hover:bg-primary/90 transition-colors shadow-sm disabled:opacity-50 flex items-center gap-1.5"
            >
              {isPending && <span className="animate-spin">⟳</span>}
              Create Deal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
'use client';

import React, { useEffect, useState } from 'react';
import { useCrmStore } from '@/stores/crm-store';
import { createClient } from '@/lib/supabase/client';
import { moveOpportunityStage } from '@/server/actions/pipelines';
import { Opportunity, Pipeline } from '@/types/crm';
import { KanbanColumn } from './KanbanColumn';

interface KanbanBoardProps {
  initialPipeline: Pipeline;
  subaccountId: string;
  currentUserId: string;
  currentUserName: string;
}

export function KanbanBoard({
  initialPipeline,
  subaccountId,
  currentUserId,
  currentUserName,
}: KanbanBoardProps) {
  const {
    pipeline,
    setPipeline,
    optimisticMoveOpportunity,
    rollbackStages,
    confirmOptimisticMove,
    applyRemoteOpportunityUpdate,
    setPresenceLock,
  } = useCrmStore();

  const [activeDraggingId, setActiveDraggingId] = useState<string | null>(null);
  const [conflictNotification, setConflictNotification] = useState<string | null>(null);

  // 1. Initialize Pipeline State
  useEffect(() => {
    setPipeline(initialPipeline);
  }, [initialPipeline, setPipeline]);

  // 2. Realtime Concurrency & Presence Sync via Supabase
  useEffect(() => {
    const supabase = createClient();
    const channelName = `crm-pipeline:${initialPipeline.id}`;

    const channel = supabase.channel(channelName, {
      config: {
        presence: { key: currentUserId },
      },
    });

    // Realtime Database Changes listener for Opportunities
    channel
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'opportunities',
          filter: `subaccount_id=eq.${subaccountId}`,
        },
        (payload) => {
          if (payload.eventType === 'UPDATE' || payload.eventType === 'INSERT') {
            applyRemoteOpportunityUpdate(payload.new as Opportunity);
          }
        }
      )
      // Realtime Presence tracking for visual card locks
      .on('presence', { event: 'sync' }, () => {
        const presenceState = channel.presenceState<{
          draggingCardId?: string;
          userName: string;
        }>();

        Object.entries(presenceState).forEach(([userId, presences]) => {
          if (userId === currentUserId) return;
          const latest = presences[0];
          if (latest?.draggingCardId) {
            setPresenceLock(latest.draggingCardId, {
              userId,
              userName: latest.userName,
              lockedAt: new Date().toISOString(),
            });
          }
        });
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({
            userName: currentUserName,
            draggingCardId: null,
          });
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [
    initialPipeline.id,
    subaccountId,
    currentUserId,
    currentUserName,
    applyRemoteOpportunityUpdate,
    setPresenceLock,
  ]);

  // 3. Handle OCC-Protected Drag and Drop
  const handleDragStart = (e: React.DragEvent, opportunityId: string) => {
    e.dataTransfer.setData('text/plain', opportunityId);
    setActiveDraggingId(opportunityId);

    // Broadcast active card lock to team
    const supabase = createClient();
    supabase.channel(`crm-pipeline:${initialPipeline.id}`).track({
      userName: currentUserName,
      draggingCardId: opportunityId,
    });
  };

  const handleDragEnd = () => {
    setActiveDraggingId(null);
    const supabase = createClient();
    supabase.channel(`crm-pipeline:${initialPipeline.id}`).track({
      userName: currentUserName,
      draggingCardId: null,
    });
  };

  const handleDropOpportunity = async (
    targetStageId: string,
    targetPosition: number
  ) => {
    if (!activeDraggingId) return;

    // Apply optimistic move in local Zustand state
    const moveContext = optimisticMoveOpportunity(
      activeDraggingId,
      targetStageId,
      targetPosition
    );

    if (!moveContext) return;

    const { expectedVersion } = moveContext;

    // Execute OCC-protected Server Action
    const result = await moveOpportunityStage({
      opportunityId: activeDraggingId,
      subaccountId,
      targetStageId,
      targetPosition,
      expectedVersion,
    });

    if (result.success && result.data) {
      confirmOptimisticMove(activeDraggingId, result.data.version);
    } else {
      // Revert optimistic changes on OCC conflict or network failure
      rollbackStages();

      if (result.isConflict) {
        setConflictNotification(
          result.error ||
            'Conflict detected: Another team member updated this deal simultaneously. Your board has refreshed.'
        );
        setTimeout(() => setConflictNotification(null), 6000);
      }
    }

    setActiveDraggingId(null);
  };

  const currentPipeline = pipeline || initialPipeline;

  return (
    <div className="relative flex flex-col h-full w-full select-none">
      {/* Concurrency Conflict Banner */}
      {conflictNotification && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-destructive text-destructive-foreground text-sm font-medium rounded-md shadow-lg flex items-center gap-2 animate-bounce">
          <span>⚠️ {conflictNotification}</span>
        </div>
      )}

      {/* Kanban Stages Grid */}
      <div className="flex flex-1 gap-4 overflow-x-auto p-4 items-start min-h-[calc(100vh-140px)]">
        {currentPipeline.stages.map((stage) => (
          <KanbanColumn
            key={stage.id}
            stage={stage}
            activeDraggingId={activeDraggingId}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            onDropOpportunity={handleDropOpportunity}
          />
        ))}
      </div>
    </div>
  );
}
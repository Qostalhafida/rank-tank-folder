'use client';

import React, { useState } from 'react';
import { PipelineStage } from '@/types/crm';
import { OpportunityCard } from './OpportunityCard';

interface KanbanColumnProps {
  stage: PipelineStage;
  activeDraggingId: string | null;
  onDragStart: (e: React.DragEvent, opportunityId: string) => void;
  onDragEnd: () => void;
  onDropOpportunity: (targetStageId: string, targetPosition: number) => void;
}

export function KanbanColumn({
  stage,
  activeDraggingId,
  onDragStart,
  onDragEnd,
  onDropOpportunity,
}: KanbanColumnProps) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (!isDragOver) setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    // Only toggle off if leaving the column boundary
    if (!e.currentTarget.contains(e.relatedTarget as Node)) {
      setIsDragOver(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    const opportunityId = e.dataTransfer.getData('text/plain');
    if (!opportunityId) return;

    // Drop at the end of the stage column by default
    const targetPosition = stage.opportunities?.length ?? 0;
    onDropOpportunity(stage.id, targetPosition);
  };

  const formattedTotalValue = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(stage.total_value ?? 0);

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`flex flex-col w-80 min-w-[20rem] max-w-[20rem] bg-muted/40 border rounded-lg p-3 transition-colors duration-150 ${
        isDragOver ? 'border-primary/60 bg-muted/70 ring-2 ring-primary/20' : 'border-border'
      }`}
    >
      {/* Column Header */}
      <div className="flex items-center justify-between pb-3 border-b border-border/60">
        <div className="flex items-center gap-2">
          <span
            className="w-2.5 h-2.5 rounded-full"
            style={{ backgroundColor: stage.color || '#3b82f6' }}
          />
          <h3 className="font-semibold text-sm tracking-tight truncate max-w-[130px]">
            {stage.name}
          </h3>
          <span className="text-xs px-2 py-0.5 rounded-full bg-background/80 text-muted-foreground font-mono font-medium border border-border">
            {stage.opportunities_count ?? stage.opportunities?.length ?? 0}
          </span>
        </div>

        <span className="text-xs font-semibold text-muted-foreground font-mono">
          {formattedTotalValue}
        </span>
      </div>

      {/* Opportunity Cards List */}
      <div className="flex flex-col gap-2.5 mt-3 overflow-y-auto max-h-[calc(100vh-230px)] pr-1">
        {stage.opportunities && stage.opportunities.length > 0 ? (
          stage.opportunities.map((opportunity, index) => (
            <OpportunityCard
              key={opportunity.id}
              opportunity={opportunity}
              index={index}
              isDragging={activeDraggingId === opportunity.id}
              onDragStart={onDragStart}
              onDragEnd={onDragEnd}
            />
          ))
        ) : (
          <div
            className={`flex items-center justify-center h-28 border border-dashed rounded-md text-xs text-muted-foreground transition-colors ${
              isDragOver ? 'border-primary/50 text-primary' : 'border-border/60'
            }`}
          >
            {isDragOver ? 'Drop deal here' : 'No deals in this stage'}
          </div>
        )}
      </div>
    </div>
  );
}
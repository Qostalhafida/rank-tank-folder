'use client';

import React from 'react';
import { Opportunity } from '@/types/crm';
import { useCrmStore } from '@/stores/crm-store';

interface OpportunityCardProps {
  opportunity: Opportunity;
  index: number;
  isDragging: boolean;
  onDragStart: (e: React.DragEvent, opportunityId: string) => void;
  onDragEnd: () => void;
}

export function OpportunityCard({
  opportunity,
  isDragging,
  onDragStart,
  onDragEnd,
}: OpportunityCardProps) {
  const { presenceLocks, setActiveOpportunity } = useCrmStore();
  const lock = presenceLocks[opportunity.id];

  const formattedValue = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: opportunity.currency || 'USD',
    maximumFractionDigits: 0,
  }).format(opportunity.value || 0);

  const contactName = opportunity.contact
    ? `${opportunity.contact.first_name ?? ''} ${opportunity.contact.last_name ?? ''}`.trim()
    : 'Unknown Contact';

  const isLockedByOther = Boolean(lock);

  return (
    <div
      draggable={!isLockedByOther}
      onDragStart={(e) => {
        if (!isLockedByOther) onDragStart(e, opportunity.id);
      }}
      onDragEnd={onDragEnd}
      onClick={() => setActiveOpportunity(opportunity.id)}
      className={`group relative p-3.5 bg-card border rounded-md shadow-sm transition-all duration-200 cursor-grab active:cursor-grabbing hover:shadow-md ${
        isDragging ? 'opacity-40 scale-95 border-primary ring-2 ring-primary/30' : 'border-border'
      } ${
        isLockedByOther ? 'cursor-not-allowed opacity-75 ring-1 ring-amber-500/50 bg-amber-500/5' : ''
      }`}
    >
      {/* Active Remote Presence Lock Overlay */}
      {isLockedByOther && (
        <div className="absolute -top-2.5 -right-1 z-10 flex items-center gap-1.5 px-2 py-0.5 bg-amber-500 text-white text-[10px] font-semibold rounded-full shadow-sm animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-white" />
          <span>Locked by {lock.userName}</span>
        </div>
      )}

      {/* Card Header & Deal Title */}
      <div className="flex items-start justify-between gap-2">
        <h4 className="text-sm font-medium text-foreground tracking-tight line-clamp-2">
          {opportunity.title}
        </h4>
        <span className="text-xs font-bold text-foreground font-mono shrink-0">
          {formattedValue}
        </span>
      </div>

      {/* Contact Profile Link & Info */}
      <div className="mt-2.5 flex items-center justify-between text-xs text-muted-foreground border-t border-border/40 pt-2">
        <div className="flex items-center gap-1.5 truncate max-w-[170px]">
          <span className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-[10px] shrink-0">
            {contactName.charAt(0) || 'C'}
          </span>
          <span className="truncate">{contactName}</span>
        </div>

        {/* OCC Version indicator tag */}
        <span
          title={`OCC Revision v${opportunity.version}`}
          className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border/50 shrink-0"
        >
          v{opportunity.version}
        </span>
      </div>
    </div>
  );
}
'use client';

import React, { useState, useTransition } from 'react';
import Link from 'next/link';
import { Contact, ContactFilterParams } from '@/types/crm';
import { getContacts } from '@/server/actions/contacts';

interface ContactTableProps {
  initialContacts: Contact[];
  totalCount: number;
  subaccountId: string;
  subaccountSlug: string;
  locale: string;
}

export function ContactTable({
  initialContacts,
  totalCount: initialTotalCount,
  subaccountId,
  subaccountSlug,
  locale,
}: ContactTableProps) {
  const [contacts, setContacts] = useState<Contact[]>(initialContacts);
  const [totalCount, setTotalCount] = useState(initialTotalCount);
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const [isPending, startTransition] = useTransition();

  const pageSize = 20;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));

  const fetchFilteredContacts = (query: string, newPage: number) => {
    startTransition(async () => {
      const filterParams: ContactFilterParams = {
        search: query || undefined,
        page: newPage,
        pageSize,
        sortBy: 'lifetime_value',
        sortOrder: 'desc',
      };

      const res = await getContacts(subaccountId, filterParams);
      if (res.success && res.data) {
        setContacts(res.data.contacts);
        setTotalCount(res.data.totalCount);
        setPage(newPage);
      }
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchFilteredContacts(searchTerm, 1);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-4">
      {/* Search Header Controls */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name, phone, or email..."
            className="w-full px-3.5 py-2 text-sm bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          {isPending && (
            <span className="absolute right-3 top-2.5 text-xs text-muted-foreground animate-spin">
              ⟳
            </span>
          )}
        </form>

        <span className="text-xs text-muted-foreground self-end sm:self-center font-mono">
          Showing {contacts.length} of {totalCount} contacts
        </span>
      </div>

      {/* Responsive Table Container */}
      <div className="border border-border rounded-lg overflow-x-auto bg-card shadow-sm">
        <table className="w-full text-left border-collapse text-sm">
          <thead>
            <tr className="border-b border-border/80 bg-muted/30 text-xs font-semibold text-muted-foreground tracking-wider uppercase">
              <th className="py-3 px-4">Contact</th>
              <th className="py-3 px-4">Phone / City</th>
              <th className="py-3 px-4">Tags</th>
              <th className="py-3 px-4 text-center">Orders</th>
              <th className="py-3 px-4 text-right">Lifetime Value</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {contacts.length > 0 ? (
              contacts.map((contact) => {
                const fullName = `${contact.first_name ?? ''} ${contact.last_name ?? ''}`.trim() || 'Anonymous';
                const isHighValue = contact.lifetime_value > 500;

                return (
                  <tr
                    key={contact.id}
                    className="hover:bg-muted/40 transition-colors duration-150"
                  >
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs uppercase shrink-0">
                          {fullName.charAt(0)}
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-foreground truncate max-w-[180px]">
                            {fullName}
                          </p>
                          <p className="text-xs text-muted-foreground truncate max-w-[180px]">
                            {contact.email || 'No email registered'}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-muted-foreground font-mono text-xs">
                      <div>{contact.phone || '—'}</div>
                      <div className="text-[11px] text-muted-foreground/80 font-sans">
                        {contact.city || contact.country || 'Unknown location'}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap gap-1 max-w-[220px]">
                        {contact.tags && contact.tags.length > 0 ? (
                          contact.tags.map((tag) => (
                            <span
                              key={tag.id}
                              className="text-[10px] font-medium px-2 py-0.5 rounded-full border"
                              style={{
                                borderColor: `${tag.color}40`,
                                backgroundColor: `${tag.color}15`,
                                color: tag.color,
                              }}
                            >
                              {tag.name}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-muted-foreground/60">—</span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-block px-2 py-0.5 rounded bg-muted text-xs font-mono font-medium">
                        {contact.orders_count}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <span
                        className={`inline-block font-mono text-xs font-semibold px-2 py-1 rounded-md ${
                          isHighValue
                            ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                            : 'text-foreground'
                        }`}
                      >
                        {formatCurrency(contact.lifetime_value)}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <Link
                        href={`/${subaccountSlug}/${locale}/admin/contacts/${contact.id}`}
                        className="text-xs font-medium text-primary hover:underline"
                      >
                        View 360°
                      </Link>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6} className="py-12 text-center text-muted-foreground text-sm">
                  No contacts found matching criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={() => fetchFilteredContacts(searchTerm, page - 1)}
            disabled={page <= 1 || isPending}
            className="px-3 py-1.5 text-xs font-medium bg-card border border-border rounded-md hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          <span className="text-xs font-mono text-muted-foreground">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => fetchFilteredContacts(searchTerm, page + 1)}
            disabled={page >= totalPages || isPending}
            className="px-3 py-1.5 text-xs font-medium bg-card border border-border rounded-md hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
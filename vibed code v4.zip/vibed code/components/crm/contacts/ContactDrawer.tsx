'use client';

import React, { useEffect, useState, useTransition } from 'react';
import { Contact, Tag } from '@/types/crm';
import {
  attachTagToContact,
  removeTagFromContact,
  updateContact,
} from '@/server/actions/contacts';
import { getTags } from '@/server/actions/tags';

interface ContactDrawerProps {
  contact: Contact | null;
  subaccountId: string;
  isOpen: boolean;
  onClose: () => void;
  onContactUpdated?: (updated: Contact) => void;
}

export function ContactDrawer({
  contact,
  subaccountId,
  isOpen,
  onClose,
  onContactUpdated,
}: ContactDrawerProps) {
  const [currentContact, setCurrentContact] = useState<Contact | null>(contact);
  const [availableTags, setAvailableTags] = useState<Tag[]>([]);
  const [selectedTagId, setSelectedTagId] = useState('');
  const [newNote, setNewNote] = useState('');
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    setCurrentContact(contact);
  }, [contact]);

  useEffect(() => {
    if (isOpen && subaccountId) {
      getTags(subaccountId).then((res) => {
        if (res.success && res.data) {
          setAvailableTags(res.data);
        }
      });
    }
  }, [isOpen, subaccountId]);

  // Handle escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !currentContact) return null;

  const handleAttachTag = () => {
    if (!selectedTagId) return;
    startTransition(async () => {
      const res = await attachTagToContact(subaccountId, currentContact.id, selectedTagId);
      if (res.success) {
        const addedTag = availableTags.find((t) => t.id === selectedTagId);
        if (addedTag) {
          const updatedTags = [...(currentContact.tags || []), addedTag];
          const updated = { ...currentContact, tags: updatedTags };
          setCurrentContact(updated);
          onContactUpdated?.(updated);
          setSelectedTagId('');
        }
      }
    });
  };

  const handleRemoveTag = (tagId: string) => {
    startTransition(async () => {
      const res = await removeTagFromContact(subaccountId, currentContact.id, tagId);
      if (res.success) {
        const updatedTags = (currentContact.tags || []).filter((t) => t.id !== tagId);
        const updated = { ...currentContact, tags: updatedTags };
        setCurrentContact(updated);
        onContactUpdated?.(updated);
      }
    });
  };

  const fullName = `${currentContact.first_name ?? ''} ${currentContact.last_name ?? ''}`.trim() || 'Anonymous';
  const unattachedTags = availableTags.filter(
    (at) => !currentContact.tags?.some((ct) => ct.id === at.id)
  );

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-background/80 backdrop-blur-sm transition-opacity"
      />

      {/* Slide-over panel */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-card border-l border-border shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-6 border-b border-border flex items-start justify-between bg-muted/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-base shrink-0">
                {fullName.charAt(0)}
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">{fullName}</h2>
                <p className="text-xs text-muted-foreground font-mono">
                  ID: {currentContact.id.slice(0, 8)}...
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground p-1 text-sm font-semibold rounded-md"
            >
              ✕
            </button>
          </div>

          {/* Drawer Body */}
          <div className="p-6 overflow-y-auto flex-1 space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-muted/40 border border-border rounded-lg">
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider block">
                  Lifetime Value
                </span>
                <span className="text-lg font-bold font-mono text-foreground mt-0.5 block">
                  ${currentContact.lifetime_value.toLocaleString()}
                </span>
              </div>
              <div className="p-3 bg-muted/40 border border-border rounded-lg">
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider block">
                  Total Orders
                </span>
                <span className="text-lg font-bold font-mono text-foreground mt-0.5 block">
                  {currentContact.orders_count}
                </span>
              </div>
            </div>

            {/* Contact Details */}
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Communication Channels
              </h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between p-2.5 rounded-md bg-background border border-border">
                  <span className="text-muted-foreground">Phone</span>
                  <span className="font-mono font-medium text-foreground">
                    {currentContact.phone || 'Not recorded'}
                  </span>
                </div>
                <div className="flex justify-between p-2.5 rounded-md bg-background border border-border">
                  <span className="text-muted-foreground">Email</span>
                  <span className="font-medium text-foreground">
                    {currentContact.email || 'Not recorded'}
                  </span>
                </div>
                <div className="p-2.5 rounded-md bg-background border border-border">
                  <span className="text-muted-foreground block mb-1">Shipping Address</span>
                  <p className="font-medium text-foreground">
                    {currentContact.address_line1 || 'No address registered'}
                    {currentContact.address_line2 ? `, ${currentContact.address_line2}` : ''}
                  </p>
                  <p className="text-muted-foreground">
                    {[currentContact.city, currentContact.province, currentContact.country]
                      .filter(Boolean)
                      .join(', ')}
                  </p>
                </div>
              </div>
            </div>

            {/* CRM Tags Section */}
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Customer Tags
              </h3>
              <div className="flex flex-wrap gap-1.5 min-h-6">
                {currentContact.tags && currentContact.tags.length > 0 ? (
                  currentContact.tags.map((tag) => (
                    <span
                      key={tag.id}
                      className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full border"
                      style={{
                        borderColor: `${tag.color}40`,
                        backgroundColor: `${tag.color}15`,
                        color: tag.color,
                      }}
                    >
                      {tag.name}
                      <button
                        onClick={() => handleRemoveTag(tag.id)}
                        disabled={isPending}
                        className="hover:opacity-75 font-bold"
                      >
                        ×
                      </button>
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-muted-foreground italic">No tags attached</span>
                )}
              </div>

              {/* Tag Selector */}
              {unattachedTags.length > 0 && (
                <div className="flex gap-2 pt-1">
                  <select
                    value={selectedTagId}
                    onChange={(e) => setSelectedTagId(e.target.value)}
                    className="flex-1 px-2.5 py-1.5 text-xs bg-background border border-input rounded-md focus:outline-none"
                  >
                    <option value="">Select a tag to attach...</option>
                    {unattachedTags.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleAttachTag}
                    disabled={!selectedTagId || isPending}
                    className="px-3 py-1.5 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:bg-primary/90 disabled:opacity-50"
                  >
                    Add
                  </button>
                </div>
              )}
            </div>

            {/* Activity History Timeline */}
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Activity Timeline
              </h3>
              <div className="space-y-3 border-l-2 border-border ml-2 pl-3">
                <div className="text-xs relative">
                  <span className="w-2 h-2 rounded-full bg-primary absolute -left-[17px] top-1" />
                  <p className="font-medium text-foreground">Contact Created</p>
                  <span className="text-[10px] text-muted-foreground font-mono">
                    {new Date(currentContact.created_at).toLocaleDateString()}
                  </span>
                </div>
                {currentContact.orders_count > 0 && (
                  <div className="text-xs relative">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 absolute -left-[17px] top-1" />
                    <p className="font-medium text-foreground">Completed Orders</p>
                    <span className="text-[10px] text-muted-foreground">
                      {currentContact.orders_count} orders successfully recorded
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-border bg-muted/20 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/90 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
'use client';

import React, { useState } from 'react';
import { Tag } from '@/types/crm';

interface TagBadgeListProps {
  tags: Tag[];
  onTagClick?: (tag: Tag) => void;
  onRemoveTag?: (tagId: string) => void;
  maxVisible?: number;
  size?: 'sm' | 'md';
  interactive?: boolean;
}

export function TagBadgeList({
  tags,
  onTagClick,
  onRemoveTag,
  maxVisible,
  size = 'sm',
  interactive = false,
}: TagBadgeListProps) {
  const [showAll, setShowAll] = useState(false);

  if (!tags || tags.length === 0) {
    return <span className="text-xs text-muted-foreground/60 italic">—</span>;
  }

  const visibleTags = maxVisible && !showAll ? tags.slice(0, maxVisible) : tags;
  const hiddenCount = maxVisible ? Math.max(0, tags.length - maxVisible) : 0;

  const sizeClasses =
    size === 'sm'
      ? 'text-[10px] px-2 py-0.5 gap-1'
      : 'text-xs px-2.5 py-1 gap-1.5 font-medium';

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {visibleTags.map((tag) => {
        const isClickable = interactive && Boolean(onTagClick);

        return (
          <span
            key={tag.id}
            onClick={() => {
              if (isClickable) onTagClick?.(tag);
            }}
            className={`inline-flex items-center rounded-full border transition-all select-none ${sizeClasses} ${
              isClickable ? 'cursor-pointer hover:opacity-85 hover:scale-105' : ''
            }`}
            style={{
              borderColor: `${tag.color}40`,
              backgroundColor: `${tag.color}15`,
              color: tag.color,
            }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full shrink-0"
              style={{ backgroundColor: tag.color }}
            />
            <span className="truncate max-w-[120px] font-semibold">{tag.name}</span>

            {onRemoveTag && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveTag(tag.id);
                }}
                className="hover:opacity-75 p-0.5 font-bold leading-none shrink-0"
                title={`Remove ${tag.name}`}
              >
                ×
              </button>
            )}
          </span>
        );
      })}

      {hiddenCount > 0 && !showAll && (
        <button
          type="button"
          onClick={() => setShowAll(true)}
          className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded-full bg-muted border border-border text-muted-foreground hover:text-foreground transition-colors"
        >
          +{hiddenCount} more
        </button>
      )}

      {showAll && maxVisible && tags.length > maxVisible && (
        <button
          type="button"
          onClick={() => setShowAll(false)}
          className="text-[10px] font-mono text-muted-foreground hover:underline"
        >
          Show less
        </button>
      )}
    </div>
  );
}
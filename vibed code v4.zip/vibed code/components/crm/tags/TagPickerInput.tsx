'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Tag } from '@/types/crm';

interface TagPickerInputProps {
  availableTags: Tag[];
  selectedTagIds: string[];
  onChange: (tagIds: string[]) => void;
  placeholder?: string;
  disabled?: boolean;
}

export function TagPickerInput({
  availableTags,
  selectedTagIds,
  onChange,
  placeholder = 'Add or filter tags...',
  disabled = false,
}: TagPickerInputProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Filter out already selected tags and apply search
  const unselectedTags = availableTags.filter(
    (tag) => !selectedTagIds.includes(tag.id)
  );

  const filteredTags = unselectedTags.filter((tag) =>
    tag.name.toLowerCase().includes(searchTerm.toLowerCase().trim())
  );

  const selectedTags = availableTags.filter((tag) =>
    selectedTagIds.includes(tag.id)
  );

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectTag = (tagId: string) => {
    onChange([...selectedTagIds, tagId]);
    setSearchTerm('');
    inputRef.current?.focus();
  };

  const handleRemoveTag = (tagId: string) => {
    onChange(selectedTagIds.filter((id) => id !== tagId));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !searchTerm && selectedTagIds.length > 0) {
      // Remove last tag when backspace is pressed on empty input
      handleRemoveTag(selectedTagIds[selectedTagIds.length - 1]);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    } else if (e.key === 'Enter' && filteredTags.length > 0) {
      e.preventDefault();
      handleSelectTag(filteredTags[0].id);
    }
  };

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Input container holding active chips and text field */}
      <div
        onClick={() => {
          if (!disabled) {
            setIsOpen(true);
            inputRef.current?.focus();
          }
        }}
        className={`min-h-[38px] p-1.5 flex flex-wrap items-center gap-1.5 bg-background border border-input rounded-md text-xs transition-colors cursor-text ${
          isOpen ? 'ring-2 ring-primary/40 border-primary/60' : ''
        } ${disabled ? 'opacity-50 cursor-not-allowed bg-muted/40' : ''}`}
      >
        {selectedTags.map((tag) => (
          <span
            key={tag.id}
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[11px] font-medium"
            style={{
              borderColor: `${tag.color}40`,
              backgroundColor: `${tag.color}15`,
              color: tag.color,
            }}
          >
            {tag.name}
            {!disabled && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemoveTag(tag.id);
                }}
                className="hover:opacity-75 font-bold leading-none"
              >
                ×
              </button>
            )}
          </span>
        ))}

        <input
          ref={inputRef}
          type="text"
          value={searchTerm}
          disabled={disabled}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            if (!isOpen) setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={selectedTags.length === 0 ? placeholder : ''}
          className="flex-1 min-w-[100px] bg-transparent border-none outline-none text-xs text-foreground placeholder:text-muted-foreground p-0.5"
        />
      </div>

      {/* Autocomplete Dropdown */}
      {isOpen && !disabled && (
        <div className="absolute z-50 left-0 right-0 mt-1 max-h-52 overflow-y-auto bg-card border border-border rounded-md shadow-lg py-1 text-xs">
          {filteredTags.length > 0 ? (
            filteredTags.map((tag) => (
              <button
                key={tag.id}
                type="button"
                onClick={() => handleSelectTag(tag.id)}
                className="w-full text-left px-3 py-1.5 hover:bg-muted/60 transition-colors flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: tag.color }}
                  />
                  <span className="font-medium text-foreground">{tag.name}</span>
                </div>
                {tag.contacts_count !== undefined && (
                  <span className="text-[10px] text-muted-foreground font-mono">
                    {tag.contacts_count} contacts
                  </span>
                )}
              </button>
            ))
          ) : (
            <div className="px-3 py-2 text-center text-muted-foreground italic text-xs">
              {searchTerm ? 'No matching tags found' : 'All available tags selected'}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
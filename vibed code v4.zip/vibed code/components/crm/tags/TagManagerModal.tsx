'use client';

import React, { useEffect, useState, useTransition } from 'react';
import { Tag } from '@/types/crm';
import { createTag, deleteTag, getTags, updateTag } from '@/server/actions/tags';

interface TagManagerModalProps {
  subaccountId: string;
  isOpen: boolean;
  onClose: () => void;
  onTagChanged?: () => void;
}

const PRESET_COLORS = [
  '#3b82f6', // Blue
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ef4444', // Red
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#06b6d4', // Cyan
  '#64748b', // Slate
];

export function TagManagerModal({
  subaccountId,
  isOpen,
  onClose,
  onTagChanged,
}: TagManagerModalProps) {
  const [tags, setTags] = useState<Tag[]>([]);
  const [newTagName, setNewTagName] = useState('');
  const [selectedColor, setSelectedColor] = useState(PRESET_COLORS[0]);
  const [editingTagId, setEditingTagId] = useState<string | null>(null);
  const [editingTagName, setEditingTagName] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const loadTags = () => {
    startTransition(async () => {
      const res = await getTags(subaccountId);
      if (res.success && res.data) {
        setTags(res.data);
      }
    });
  };

  useEffect(() => {
    if (isOpen && subaccountId) {
      loadTags();
    }
  }, [isOpen, subaccountId]);

  if (!isOpen) return null;

  const handleCreateTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;

    setErrorMsg(null);
    startTransition(async () => {
      const res = await createTag(subaccountId, {
        name: newTagName,
        color: selectedColor,
      });

      if (res.success && res.data) {
        setTags((prev) => [...prev, res.data!]);
        setNewTagName('');
        onTagChanged?.();
      } else {
        setErrorMsg(res.error || 'Failed to create tag');
      }
    });
  };

  const handleUpdateTag = (tagId: string) => {
    if (!editingTagName.trim()) return;

    setErrorMsg(null);
    startTransition(async () => {
      const res = await updateTag(subaccountId, tagId, {
        name: editingTagName,
      });

      if (res.success && res.data) {
        setTags((prev) =>
          prev.map((t) => (t.id === tagId ? { ...t, name: editingTagName } : t))
        );
        setEditingTagId(null);
        setEditingTagName('');
        onTagChanged?.();
      } else {
        setErrorMsg(res.error || 'Failed to update tag');
      }
    });
  };

  const handleDeleteTag = (tagId: string) => {
    if (!confirm('Are you sure you want to delete this tag? It will be removed from all contacts.')) return;

    setErrorMsg(null);
    startTransition(async () => {
      const res = await deleteTag(subaccountId, tagId);
      if (res.success) {
        setTags((prev) => prev.filter((t) => t.id !== tagId));
        onTagChanged?.();
      } else {
        setErrorMsg(res.error || 'Failed to delete tag');
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
      />

      {/* Dialog Shell */}
      <div className="relative w-full max-w-lg bg-card border border-border rounded-lg shadow-xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-muted/20">
          <div>
            <h3 className="text-sm font-semibold text-foreground">CRM Tag Manager</h3>
            <p className="text-xs text-muted-foreground">
              Create, color-code, and organize tags for lead categorization.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1 text-sm font-semibold rounded-md"
          >
            ✕
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 mx-4 mt-3 bg-destructive/10 text-destructive text-xs rounded-md border border-destructive/20">
            {errorMsg}
          </div>
        )}

        {/* Modal Body */}
        <div className="p-4 space-y-5 overflow-y-auto flex-1">
          {/* Create New Tag Form */}
          <form onSubmit={handleCreateTag} className="space-y-3 p-3 bg-muted/30 rounded-lg border border-border">
            <span className="text-xs font-semibold text-foreground block">
              Create New Tag
            </span>

            <div className="flex gap-2">
              <input
                type="text"
                value={newTagName}
                onChange={(e) => setNewTagName(e.target.value)}
                placeholder="e.g. VIP Customer, Lead Lost..."
                className="flex-1 px-3 py-1.5 text-xs bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
              <button
                type="submit"
                disabled={isPending || !newTagName.trim()}
                className="px-3.5 py-1.5 bg-primary text-primary-foreground text-xs font-medium rounded-md hover:bg-primary/90 disabled:opacity-50 transition-colors"
              >
                Add Tag
              </button>
            </div>

            {/* Color Palette Selector */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-[11px] text-muted-foreground">Color:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {PRESET_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setSelectedColor(color)}
                    className={`w-5 h-5 rounded-full transition-transform ${
                      selectedColor === color
                        ? 'ring-2 ring-primary ring-offset-2 scale-110'
                        : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </form>

          {/* Existing Tags Directory */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block">
              Existing Tags ({tags.length})
            </span>

            <div className="divide-y divide-border/60 border border-border rounded-md overflow-hidden bg-background">
              {tags.length > 0 ? (
                tags.map((tag) => (
                  <div
                    key={tag.id}
                    className="flex items-center justify-between p-2.5 text-xs hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 flex-1 min-w-0 mr-2">
                      <span
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: tag.color }}
                      />

                      {editingTagId === tag.id ? (
                        <div className="flex items-center gap-1 flex-1">
                          <input
                            type="text"
                            value={editingTagName}
                            onChange={(e) => setEditingTagName(e.target.value)}
                            className="px-2 py-1 text-xs bg-card border border-input rounded font-medium flex-1 focus:outline-none"
                          />
                          <button
                            onClick={() => handleUpdateTag(tag.id)}
                            disabled={isPending}
                            className="text-primary hover:underline font-medium px-1"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingTagId(null)}
                            className="text-muted-foreground hover:underline px-1"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <span className="font-medium text-foreground truncate">
                          {tag.name}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-[11px] text-muted-foreground font-mono">
                        {tag.contacts_count ?? 0} contacts
                      </span>

                      {editingTagId !== tag.id && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingTagId(tag.id);
                              setEditingTagName(tag.name);
                            }}
                            className="text-[11px] text-muted-foreground hover:text-foreground"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDeleteTag(tag.id)}
                            disabled={isPending}
                            className="text-[11px] text-destructive hover:underline"
                          >
                            Delete
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-xs text-muted-foreground italic">
                  No tags created yet.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-border bg-muted/20 flex justify-end">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 bg-secondary text-secondary-foreground text-xs font-medium rounded-md hover:bg-secondary/90 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
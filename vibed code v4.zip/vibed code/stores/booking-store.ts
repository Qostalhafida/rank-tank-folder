import { create } from 'zustand';
import { AvailableSlot, Calendar } from '@/types/booking';

export type BookingStep = 'DATE_SELECT' | 'SLOT_SELECT' | 'DETAILS_FORM' | 'CONFIRMED';

export interface BookingAttendeeInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  notes: string;
}

interface BookingState {
  calendar: Calendar | null;
  selectedDate: string | null; // ISO Date string (YYYY-MM-DD)
  selectedSlot: AvailableSlot | null;
  currentStep: BookingStep;
  attendee: BookingAttendeeInfo;
  isSubmitting: boolean;

  // Actions
  setCalendar: (calendar: Calendar) => void;
  selectDate: (date: string | null) => void;
  selectSlot: (slot: AvailableSlot | null) => void;
  setStep: (step: BookingStep) => void;
  updateAttendee: (info: Partial<BookingAttendeeInfo>) => void;
  setIsSubmitting: (isSubmitting: boolean) => void;
  resetBooking: () => void;
}

const initialAttendeeState: BookingAttendeeInfo = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  notes: '',
};

export const useBookingStore = create<BookingState>((set) => ({
  calendar: null,
  selectedDate: null,
  selectedSlot: null,
  currentStep: 'DATE_SELECT',
  attendee: initialAttendeeState,
  isSubmitting: false,

  setCalendar: (calendar) => set({ calendar }),

  selectDate: (selectedDate) =>
    set({
      selectedDate,
      selectedSlot: null,
      currentStep: selectedDate ? 'SLOT_SELECT' : 'DATE_SELECT',
    }),

  selectSlot: (selectedSlot) =>
    set({
      selectedSlot,
      currentStep: selectedSlot ? 'DETAILS_FORM' : 'SLOT_SELECT',
    }),

  setStep: (currentStep) => set({ currentStep }),

  updateAttendee: (info) =>
    set((state) => ({
      attendee: { ...state.attendee, ...info },
    })),

  setIsSubmitting: (isSubmitting) => set({ isSubmitting }),

  resetBooking: () =>
    set({
      selectedDate: null,
      selectedSlot: null,
      currentStep: 'DATE_SELECT',
      attendee: initialAttendeeState,
      isSubmitting: false,
    }),
}));
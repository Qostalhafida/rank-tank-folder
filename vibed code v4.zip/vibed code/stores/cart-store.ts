import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface CartItem {
  id: string; // Product or variant identifier
  productId: string;
  title: string;
  price: number;
  compareAtPrice?: number | null;
  quantity: number;
  image?: string;
  type: 'PHYSICAL' | 'DIGITAL';
  sku?: string | null;
  metadata?: Record<string, unknown>;
}

interface CartState {
  subaccountId: string | null;
  items: CartItem[];
  isOpen: boolean;

  // Actions
  setSubaccount: (subaccountId: string) => void;
  addItem: (item: Omit<CartItem, 'quantity'> & { quantity?: number }) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;

  // Computed Selectors
  getTotalCount: () => number;
  getSubtotal: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      subaccountId: null,
      items: [],
      isOpen: false,

      setSubaccount: (subaccountId) => {
        const currentSubaccount = get().subaccountId;
        // If switching between different subaccount storefronts, reset items to prevent cross-tenant contamination
        if (currentSubaccount && currentSubaccount !== subaccountId) {
          set({ subaccountId, items: [], isOpen: false });
        } else {
          set({ subaccountId });
        }
      },

      addItem: (newItem) => {
        const { items } = get();
        const quantityToAdd = newItem.quantity && newItem.quantity > 0 ? newItem.quantity : 1;
        const existingIndex = items.findIndex((i) => i.id === newItem.id);

        if (existingIndex > -1) {
          const updatedItems = [...items];
          updatedItems[existingIndex] = {
            ...updatedItems[existingIndex],
            quantity: updatedItems[existingIndex].quantity + quantityToAdd,
          };
          set({ items: updatedItems, isOpen: true });
        } else {
          set({
            items: [...items, { ...newItem, quantity: quantityToAdd }],
            isOpen: true,
          });
        }
      },

      removeItem: (id) => {
        set((state) => ({
          items: state.items.filter((item) => item.id !== id),
        }));
      },

      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id);
          return;
        }

        set((state) => ({
          items: state.items.map((item) =>
            item.id === id ? { ...item, quantity } : item
          ),
        }));
      },

      clearCart: () => set({ items: [] }),

      openCart: () => set({ isOpen: true }),

      closeCart: () => set({ isOpen: false }),

      toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),

      getTotalCount: () => {
        return get().items.reduce((total, item) => total + item.quantity, 0);
      },

      getSubtotal: () => {
        return get().items.reduce(
          (total, item) => total + item.price * item.quantity,
          0
        );
      },
    }),
    {
      name: 'tenant-cart-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        subaccountId: state.subaccountId,
        items: state.items,
      }),
    }
  )
);
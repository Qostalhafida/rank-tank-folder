import { create } from 'zustand';
import { Opportunity, Pipeline, PipelineStage } from '@/types/crm';

interface PresenceLockInfo {
  userId: string;
  userName: string;
  lockedAt: string;
}

interface CrmState {
  pipeline: Pipeline | null;
  activeOpportunityId: string | null;
  /** Presence locks mapped by opportunityId */
  presenceLocks: Record<string, PresenceLockInfo>;
  /** Backup snapshot for rolling back optimistic drag-and-drop actions on server failure */
  stagesSnapshot: PipelineStage[] | null;

  // Actions
  setPipeline: (pipeline: Pipeline) => void;
  setActiveOpportunity: (id: string | null) => void;
  setPresenceLock: (opportunityId: string, lock: PresenceLockInfo | null) => void;
  
  /**
   * Optimistically moves an opportunity card to a target stage and index.
   * Caches current stages snapshot for instant rollback on concurrency conflict.
   */
  optimisticMoveOpportunity: (
    opportunityId: string,
    targetStageId: string,
    newPosition: number
  ) => { expectedVersion: number; rollbackSnapshot: PipelineStage[] } | null;

  rollbackStages: () => void;
  confirmOptimisticMove: (opportunityId: string, nextVersion: number) => void;
  applyRemoteOpportunityUpdate: (updated: Opportunity) => void;
}

export const useCrmStore = create<CrmState>((set, get) => ({
  pipeline: null,
  activeOpportunityId: null,
  presenceLocks: {},
  stagesSnapshot: null,

  setPipeline: (pipeline) => set({ pipeline, stagesSnapshot: null }),

  setActiveOpportunity: (id) => set({ activeOpportunityId: id }),

  setPresenceLock: (opportunityId, lock) =>
    set((state) => {
      const updatedLocks = { ...state.presenceLocks };
      if (!lock) {
        delete updatedLocks[opportunityId];
      } else {
        updatedLocks[opportunityId] = lock;
      }
      return { presenceLocks: updatedLocks };
    }),

  optimisticMoveOpportunity: (opportunityId, targetStageId, newPosition) => {
    const { pipeline } = get();
    if (!pipeline) return null;

    // Deep clone stages snapshot for rollback
    const rollbackSnapshot: PipelineStage[] = JSON.parse(JSON.stringify(pipeline.stages));

    let movedDeal: Opportunity | null = null;
    let expectedVersion = 0;

    // 1. Remove opportunity from its current stage
    const updatedStages = rollbackSnapshot.map((stage) => {
      const dealIndex = stage.opportunities?.findIndex((d) => d.id === opportunityId) ?? -1;
      if (dealIndex !== -1 && stage.opportunities) {
        movedDeal = { ...stage.opportunities[dealIndex] };
        expectedVersion = movedDeal.version;
        const newOpportunities = [...stage.opportunities];
        newOpportunities.splice(dealIndex, 1);
        return {
          ...stage,
          opportunities: newOpportunities,
          opportunities_count: (stage.opportunities_count ?? 1) - 1,
        };
      }
      return stage;
    });

    if (!movedDeal) return null;

    // 2. Insert opportunity into target stage at specified position
    const finalStages = updatedStages.map((stage) => {
      if (stage.id === targetStageId) {
        const currentOpportunities = [...(stage.opportunities ?? [])];
        const updatedDeal: Opportunity = {
          ...movedDeal!,
          stage_id: targetStageId,
          position: newPosition,
          version: expectedVersion + 1, // Pre-increment version optimistically
        };

        currentOpportunities.splice(newPosition, 0, updatedDeal);

        // Recalculate order index positions
        const reindexedOpportunities = currentOpportunities.map((deal, idx) => ({
          ...deal,
          position: idx,
        }));

        return {
          ...stage,
          opportunities: reindexedOpportunities,
          opportunities_count: (stage.opportunities_count ?? 0) + 1,
        };
      }
      return stage;
    });

    set({
      pipeline: { ...pipeline, stages: finalStages },
      stagesSnapshot: rollbackSnapshot,
    });

    return { expectedVersion, rollbackSnapshot };
  },

  rollbackStages: () => {
    const { pipeline, stagesSnapshot } = get();
    if (!pipeline || !stagesSnapshot) return;

    set({
      pipeline: { ...pipeline, stages: stagesSnapshot },
      stagesSnapshot: null,
    });
  },

  confirmOptimisticMove: (opportunityId, nextVersion) => {
    const { pipeline } = get();
    if (!pipeline) return;

    const stages = pipeline.stages.map((stage) => ({
      ...stage,
      opportunities: stage.opportunities?.map((deal) =>
        deal.id === opportunityId ? { ...deal, version: nextVersion } : deal
      ),
    }));

    set({
      pipeline: { ...pipeline, stages },
      stagesSnapshot: null,
    });
  },

  applyRemoteOpportunityUpdate: (updated) => {
    const { pipeline } = get();
    if (!pipeline) return;

    const stages = pipeline.stages.map((stage) => {
      // If stage contains this deal, update it or remove if moved elsewhere
      const existsInThisStage = stage.id === updated.stage_id;
      let deals = [...(stage.opportunities ?? [])];

      const dealIdx = deals.findIndex((d) => d.id === updated.id);

      if (existsInThisStage) {
        if (dealIdx !== -1) {
          deals[dealIdx] = { ...deals[dealIdx], ...updated };
        } else {
          deals.push(updated);
        }
        deals.sort((a, b) => a.position - b.position);
      } else if (dealIdx !== -1) {
        deals.splice(dealIdx, 1);
      }

      return {
        ...stage,
        opportunities: deals,
        opportunities_count: deals.length,
      };
    });

    set({ pipeline: { ...pipeline, stages } });
  },
}));
import { create } from 'zustand';
import {
  Workflow,
  WorkflowCanvasEdge,
  WorkflowCanvasNode,
  WorkflowNodeData,
} from '@/types/workflows';

interface WorkflowState {
  workflowId: string | null;
  subaccountId: string | null;
  name: string;
  isActive: boolean;
  nodes: WorkflowCanvasNode[];
  edges: WorkflowCanvasEdge[];
  selectedNodeId: string | null;
  isDirty: boolean;

  // Actions
  setWorkflow: (workflow: Workflow) => void;
  setName: (name: string) => void;
  setIsActive: (isActive: boolean) => void;
  setNodes: (nodes: WorkflowCanvasNode[]) => void;
  setEdges: (edges: WorkflowCanvasEdge[]) => void;
  addNode: (node: WorkflowCanvasNode) => void;
  updateNodePosition: (id: string, position: { x: number; y: number }) => void;
  updateNodeData: (id: string, data: Partial<WorkflowNodeData>) => void;
  removeNode: (id: string) => void;
  addEdge: (edge: WorkflowCanvasEdge) => void;
  removeEdge: (edgeId: string) => void;
  selectNode: (id: string | null) => void;
  resetWorkflow: () => void;
}

const initialState = {
  workflowId: null,
  subaccountId: null,
  name: 'Untitled Automation',
  isActive: false,
  nodes: [],
  edges: [],
  selectedNodeId: null,
  isDirty: false,
};

export const useWorkflowStore = create<WorkflowState>((set, get) => ({
  ...initialState,

  setWorkflow: (workflow) =>
    set({
      workflowId: workflow.id,
      subaccountId: workflow.subaccount_id,
      name: workflow.name,
      isActive: workflow.is_active,
      nodes: workflow.nodes,
      edges: workflow.edges,
      selectedNodeId: null,
      isDirty: false,
    }),

  setName: (name) => set({ name, isDirty: true }),

  setIsActive: (isActive) => set({ isActive, isDirty: true }),

  setNodes: (nodes) => set({ nodes, isDirty: true }),

  setEdges: (edges) => set({ edges, isDirty: true }),

  addNode: (node) =>
    set((state) => ({
      nodes: [...state.nodes, node],
      selectedNodeId: node.id,
      isDirty: true,
    })),

  updateNodePosition: (id, position) =>
    set((state) => ({
      nodes: state.nodes.map((node) =>
        node.id === id ? { ...node, position } : node
      ),
      isDirty: true,
    })),

  updateNodeData: (id, data) =>
    set((state) => ({
      nodes: state.nodes.map((node) =>
        node.id === id
          ? { ...node, data: { ...node.data, ...data } }
          : node
      ),
      isDirty: true,
    })),

  removeNode: (id) =>
    set((state) => ({
      nodes: state.nodes.filter((node) => node.id !== id),
      // Automatically prune orphan edges connected to this node
      edges: state.edges.filter(
        (edge) => edge.source !== id && edge.target !== id
      ),
      selectedNodeId: state.selectedNodeId === id ? null : state.selectedNodeId,
      isDirty: true,
    })),

  addEdge: (edge) => {
    const { edges } = get();
    // Prevent duplicate edges between the same source and target
    const exists = edges.some(
      (e) => e.source === edge.source && e.target === edge.target
    );
    if (exists) return;

    set({
      edges: [...edges, edge],
      isDirty: true,
    });
  },

  removeEdge: (edgeId) =>
    set((state) => ({
      edges: state.edges.filter((e) => e.id !== edgeId),
      isDirty: true,
    })),

  selectNode: (selectedNodeId) => set({ selectedNodeId }),

  resetWorkflow: () => set(initialState),
}));